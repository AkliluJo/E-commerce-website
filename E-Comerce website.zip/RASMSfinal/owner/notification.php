<?php
session_start();
error_reporting(0);
include('includes/config.php');


if(isset($_REQUEST['check']))
	{
$check=intval($_GET['check']);
$status=1;
$sql = "UPDATE notification SET notification_status=:status WHERE  notification_id=:check";
$query = $dbh->prepare($sql);
$query -> bindParam(':status',$status, PDO::PARAM_STR);
$query-> bindParam(':check',$check, PDO::PARAM_STR);
$query -> execute();

$msg="notification  has been seen";
}


if(isset($_REQUEST['del']))
	{
$delid=intval($_GET['del']);
$sql = "delete from notification WHERE  notification_id=:delid";
$query = $dbh->prepare($sql);
$query -> bindParam(':delid',$delid, PDO::PARAM_STR);
$query -> execute();
$msg="one notification is removed  successfully";
}


 ?>

<!doctype html>
<html lang="en" class="no-js">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<meta name="theme-color" content="#3e454c">
	
	<title>RASMS |Owners Notification   </title>

<?php
include('includes/csslink.php');
?>
  <style>
		.errorWrap {
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #dd3d36;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
.succWrap{
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #5cb85c;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}

		</style>
		<script src="bootstrap/vendors/jquery-1.9.1.min.js"></script>
		<script src="bootstrap/js/bootstrap.min.js"></script>

<style>



#search_class {
    width: 225px !important;
}
.post {
    border: 1px solid;
    border-radius: 10px 10px 10px 10px;
    margin-bottom: 32px;
    padding: 20px;
}
.row-fluid [class*="span"]:nth-child(5) {
    margin-left: 0;
}





.btn-info{
	background-color: #3B5998 !important; 
    background-image: linear-gradient(to bottom, #3B5998, #3B5998) !important;
    background-repeat: repeat-x !important;
    border-color: rgba(0, 0, 0, 0.1) rgba(0, 0, 0, 0.1) rgba(0, 0, 0, 0.25) !important;
    color: #FFFFFF !important;
    text-shadow: 0 -1px 0 rgba(0, 0, 0, 0.25) !important;
}




</style>
<style>




/* The popup form - hidden by default */
.form-popup {
  display: none;
  position: fixed;
  bottom: 0;
  right: 15px;
  border: 3px solid #f1f1f1;
  z-index: 9;
}

/* Add styles to the form container */
.form-container {
  max-width: 300px;
  padding: 5px;
  background-color: white;
}

/* Full-width input fields */
.form-container input[type=text], .form-container input[type=password] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  border: none;
  background: #f1f1f1;
}

/* When the inputs get focus, do something */
.form-container input[type=text]:focus, .form-container input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}

/* Set a style for the submit/login button */
.form-container .btn {
  background-color: #4CAF50;
  color: white;
  padding: 16px 20px;
  border: none;
  cursor: pointer;
  width: 100%;
  margin-bottom:10px;
  opacity: 0.8;
}

/* Add a red background color to the cancel button */
.form-container .cancel {
  background-color: red;
}

/* Add some hover effects to buttons */
.form-container .btn:hover, .open-button:hover {
  opacity: 1;
}
</style>
<script>
function openForm() {
  document.getElementById("myForm").style.display = "block";
}

function closeForm() {
  document.getElementById("myForm").style.display = "none";
}
</script>
</head>

<body>
	<?php include('includes/header.php');?>
       
	<div class="ts-main-content">
		<?php include('includes/leftbar.php');?>
		<div class="content-wrapper">
			<div class="container-fluid">

				<div class="row">
					<div class="col-md-12">
					<center><h3 class="page-title">Notification </h3></center>
						<!-- Zero Configuration Table -->
						<div class="panel panel-default">
							<div class="panel-heading">Notification details</div>
							<div class="panel-body">
							<?php if($error){?><div class="errorWrap"><strong>ERROR</strong>:<?php echo htmlentities($error); ?> </div><?php } 
				else if($msg){?>
				<div class="succWrap"><strong>SUCCESS</strong>:<?php echo htmlentities($msg); ?> </div><?php }?>
							
           
                        <!-- block -->
                        <div id="block_bg" class="block">
                          
							
							<div class="pull-right">
							<button class="btn btn-info" type= "submit" name="read"><i class="fa fa-check"></i> Read</button>
													
							Check All <input type="checkbox"  name="selectAll" id="checkAll" />
								<script>
								$("#checkAll").click(function () {
									$('input:checkbox').not(this).prop('checked', this.checked);
								});
								</script>					
							
							</div>
										
							<ul class="nav nav-pills">
							
							<li class="active"></li>
							<li class="active"></li>
							</ul>		
		<?php 
		
		$session_email = $_SESSION["email"];
		$ret="select * from notification LEFT JOIN user_info ON user_info.email = notification.user_email where  notification.user_email = '$session_email' order by date_added DESC";
         $query= $dbh -> prepare($ret);
         //$query->bindParam(':id',$id, PDO::PARAM_STR);
         $query-> execute();
         $results = $query -> fetchAll(PDO::FETCH_OBJ);
         if($query -> rowCount() > 0)
         {
         foreach($results as $result)
         {
		
         ?>						

								 
						<div class="post" id="del<?php echo htmlentities($result->notification_id);?>">
											
								<div class="message_content">
										
									<?php echo htmlentities($result->content);?>
									</div>
											
											<div class="pull-right">
											<?php if (htmlentities($result->notification_status) == 1){
											}else{ ?>
											<a href="notification.php?check=<?php echo $result->notification_id;?>" onclick="return confirm('Do you want to check it?');">
                                           <i class="fa fa-check"></i></a>
											<input id="" class="" name=""  type="checkbox" value="<?php echo htmlentities($result->notification_status);?>">
											<?php } ?>
											</div>
													<hr>
											Send by: <strong><Font color ="red"><?php echo htmlentities($result->user_fname);?>&nbsp;  <?php echo htmlentities($result->user_lname);?></font></strong>
											&nbsp;<i  class="fa fa-calendar"></i><?php echo htmlentities($result->date_added);?> 
											<br>
											
													
<div class="pull-right">
<button>
<a href="notification.php?del=<?php echo $result->notification_id;?>" onclick="return confirm('Do you want to remove');">
<i class="fa fa-remove"></i>Remove</a>	</button>						
</div>
     </div>
											
								<?php }}else{ ?>
								  
								<div class="alert alert-info"><i class="icon-info-sign"></i> notification empty</div>
								<?php } ?>		
							




								
                                </div>
                           
                       
                        <!-- /block -->
                  
					

	

                </div>
						

							</div>
						</div>
                     </div>
					</div>

					</div>
				</div>

			</div>
		</div>
	</div>
<?php
include('includes/jslink.php');
?>

</body>
</html>

