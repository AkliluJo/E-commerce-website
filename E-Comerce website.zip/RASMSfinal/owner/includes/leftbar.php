	<nav class="ts-sidebar">
		<ul class="ts-sidebar-menu">
			
		<li class="ts-label">Main</li>
		<li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Dashboad</a></li>
		<li><a href="../index.php"><i class="fa fa-fast-backward"></i> Back to Home</a></li>

		<li><a href="#"><i class="fa fa-users"></i> Profile</a>
		   <ul>
			 <li><a href="change-password.php">Change Password</a></li>
			 <li><a href="profile.php">add details</a></li>

		   </ul>
        </li>
               <li><a href="massages.php"><i class="fa fa-mail-reply"></i> Message</a></li>
                 <li><a href="notification.php"><i class="fa fa-wechat"></i> Notification</a>
				<li><a href="orderhistory.php"><i class="fa fa-mail-reply"></i> Order History</a>
				<li><a href="manage_items.php"><i class="fa fa-mail-reply"></i> Manage Items</a>
				<li><a href="reservehistory.php"><i class="fa fa-mail-reply"></i> Reseved History</a>
				<li><a href="#"><i class="fa fa-sitemap"></i> Add Items</a>
					<ul>
						<li><a href="option.php">Add Vehicles</a></li>
						<li><a href="post_computers.php">Add Computers</a></li>

						<li><a href="option_items.php">add other product</a></li>

					</ul>
                   </li>
				     
                     

			</ul>
		</nav>