<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(isset($_POST['submit']))
  {	  
$action = "online rental and sale system would like to add products to the system this
may produce fee!!";
$session_email = $_SESSION["email"];												
$sql1 ="SELECT product_id from products where owner_email= '$session_email' AND status = '1'  ";
$query1 = $dbh -> prepare($sql1);;
$query1->execute();
$results1=$query1->fetchAll(PDO::FETCH_OBJ);

if($query1->rowCount() > 1)
{
$sql="INSERT INTO `notification` (`user_email`,`content`) VALUES
(:session_email,:action)";

$query = $dbh->prepare($sql);
$query->bindParam(':session_email',$session_email,PDO::PARAM_STR);
$query->bindParam(':action',$action,PDO::PARAM_STR);
$query->execute();
$lastInsertId = $dbh->lastInsertId();
$error="online rental and sale system would like to add products to the system this
may produce fee!!";
 } else{

$email=$_SESSION['email'];
$vehicletitle=$_POST['vehicletitle'];
$hidden=$_POST['hidden'];
$brand=$_POST['brandname'];
$category=$_POST['catname'];
$location=$_POST['location'];
$keyword=$_POST['keyword'];
$condition=$_POST['condition'];
$vehicleoverview=$_POST['vehicalorcview'];
$Preconceives=$_POST['Preconceives'];
$priceperday=$_POST['priceperday'];
$fueltype=$_POST['fueltype'];
$modelyear=$_POST['modelyear'];
$seatingcapacity=$_POST['seatingcapacity'];
$vimage1=$_FILES["img1"]["name"];
$vimage2=$_FILES["img2"]["name"];
$vimage3=$_FILES["img3"]["name"];
$vimage4=$_FILES["img4"]["name"];
$airconditioner=$_POST['airconditioner'];
$powerdoorlocks=$_POST['powerdoorlocks'];
$antilockbrakingsys=$_POST['antilockbrakingsys'];
$brakeassist=$_POST['brakeassist'];
$powersteering=$_POST['powersteering'];
$driverairbag=$_POST['driverairbag'];
$passengerairbag=$_POST['passengerairbag'];
$powerwindow=$_POST['powerwindow'];
$cdplayer=$_POST['cdplayer'];
$centrallocking=$_POST['centrallocking'];
$crashcensor=$_POST['crashcensor'];
$leatherseats=$_POST['leatherseats'];
move_uploaded_file($_FILES["img1"]["tmp_name"],"../product_images/".$_FILES["img1"]["name"]);
move_uploaded_file($_FILES["img2"]["tmp_name"],"../product_images/".$_FILES["img2"]["name"]);
move_uploaded_file($_FILES["img3"]["tmp_name"],"../product_images/".$_FILES["img3"]["name"]);
move_uploaded_file($_FILES["img4"]["tmp_name"],"../product_images/".$_FILES["img4"]["name"]);
$sql="INSERT INTO `products` (`owner_email`,`product_cat`,`item_for`, `product_location`, `product_title`, `product_price`, `product_desc`,  `product_image`, `product_image1`, `product_image2`, `product_image3`, `product_keywords`,  `brand`, `condition`,  `FuelType`, `ModelYear`, `SeatingCapacity`, `AirConditioner`, `PowerDoorLocks`, `AntiLockBrakingSystem`, `BrakeAssist`, `PowerSteering`, `DriverAirbag`, `PassengerAirbag`, `PowerWindows`, `CDPlayer`, `CentralLocking`, `CrashSensor`, `LeatherSeats`) VALUES
(:email,:category,:hidden,:brand,:vehicletitle,:priceperday,:vehicleoverview,:vimage1,:vimage2,:vimage3,:vimage4,:keyword,:location,:condition,:fueltype,:modelyear,:seatingcapacity,:airconditioner,:powerdoorlocks,:antilockbrakingsys,:brakeassist,:powersteering,:driverairbag,:passengerairbag,:powerwindow,:cdplayer,:centrallocking,:crashcensor,:leatherseats)";

$query = $dbh->prepare($sql);
$query->bindParam(':email',$email,PDO::PARAM_STR);
$query->bindParam(':category',$category,PDO::PARAM_STR);
$query->bindParam(':hidden',$hidden,PDO::PARAM_STR);
$query->bindParam(':brand',$brand,PDO::PARAM_STR);
$query->bindParam(':vehicletitle',$vehicletitle,PDO::PARAM_STR);

$query->bindParam(':priceperday',$priceperday,PDO::PARAM_STR);
$query->bindParam(':vehicleoverview',$vehicleoverview,PDO::PARAM_STR);
$query->bindParam(':vimage1',$vimage1,PDO::PARAM_STR);
$query->bindParam(':vimage2',$vimage2,PDO::PARAM_STR);
$query->bindParam(':vimage3',$vimage3,PDO::PARAM_STR);
$query->bindParam(':vimage4',$vimage4,PDO::PARAM_STR);
$query->bindParam(':keyword',$keyword,PDO::PARAM_STR);
$query->bindParam(':location',$location,PDO::PARAM_STR);
$query->bindParam(':condition',$condition,PDO::PARAM_STR);
$query->bindParam(':fueltype',$fueltype,PDO::PARAM_STR);
$query->bindParam(':modelyear',$modelyear,PDO::PARAM_STR);
$query->bindParam(':seatingcapacity',$seatingcapacity,PDO::PARAM_STR);
$query->bindParam(':airconditioner',$airconditioner,PDO::PARAM_STR);
$query->bindParam(':powerdoorlocks',$powerdoorlocks,PDO::PARAM_STR);
$query->bindParam(':antilockbrakingsys',$antilockbrakingsys,PDO::PARAM_STR);
$query->bindParam(':brakeassist',$brakeassist,PDO::PARAM_STR);
$query->bindParam(':powersteering',$powersteering,PDO::PARAM_STR);
$query->bindParam(':driverairbag',$driverairbag,PDO::PARAM_STR);
$query->bindParam(':passengerairbag',$passengerairbag,PDO::PARAM_STR);
$query->bindParam(':powerwindow',$powerwindow,PDO::PARAM_STR);
$query->bindParam(':cdplayer',$cdplayer,PDO::PARAM_STR);
$query->bindParam(':centrallocking',$centrallocking,PDO::PARAM_STR);
$query->bindParam(':crashcensor',$crashcensor,PDO::PARAM_STR);
$query->bindParam(':leatherseats',$leatherseats,PDO::PARAM_STR);
$query->execute();
$lastInsertId = $dbh->lastInsertId();
if($lastInsertId)
{
  $ret = "SELECT * FROM user_info WHERE email='$_SESSION[email]'";
         $query= $dbh -> prepare($ret);
         $query-> execute();
         $results = $query -> fetchAll(PDO::FETCH_OBJ);
         if($query -> rowCount() > 0)
         {
         foreach($results as $result)
         {
		$name = $_SESSION["name"];
		$email = $_SESSION["email"];
		$action = "Add $vehicletitle vehicle ";
  $sq = "INSERT INTO `activity_logs` 
(`first_name`, `email`, `action`) VALUES ( :name,:email,:action )";
$query = $dbh->prepare($sq);
$query->bindParam(':name',$name,PDO::PARAM_STR);
$query->bindParam(':email',$email,PDO::PARAM_STR);
$query->bindParam(':action',$action,PDO::PARAM_STR);
$query->execute();
$lastInsertId = $dbh->lastInsertId();
	
		 }} 
$msg="Vehicle posted successfully";
}
else 
{
	$error="Something went wrong. Please try again";

}
 }
}


	?>

<!doctype html>
<html lang="en" class="no-js">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<meta name="theme-color" content="#3e454c">
	
	<title>RASMS| Admin Add Vehicles</title>
<?php
include('includes/csslink.php');
?>
<style>
		.errorWrap {
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #dd3d36;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
.succWrap{
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #5cb85c;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
	

	</style>
<style>
:root {
  --radius: 2px;
  --baseFg: dimgray;
  --baseBg: white;
  --accentFg: #006fc2;
  --accentBg: #bae1ff;
}

.theme-pink {
  --radius: 6em;
  --baseFg: #c70062;
  --baseBg: #ffe3f1;
  --accentFg: #c70062;
  --accentBg: #ffaad4;
}

.theme-construction {
  --radius: 10;
  --baseFg: white;
  --baseBg: black;
  --accentFg: black;
  --accentBg: orange;
}

select {
  font: 400 12px/1.3 sans-serif;
  -webkit-appearance: none;
  appearance: none;
  color: var(--baseFg);
  border: 1px solid var(--baseFg);
  line-height: 1;
  outline: 0;
  padding: 0.65em 2.5em 0.55em 0.75em;
  border-radius: var(--radius);
  background-color: var(--baseBg);
  background-image: linear-gradient(var(--baseFg), var(--baseFg)),
    linear-gradient(-135deg, transparent 50%, var(--accentBg) 50%),
    linear-gradient(-225deg, transparent 50%, var(--accentBg) 50%),
    linear-gradient(var(--accentBg) 42%, var(--accentFg) 42%);
  background-repeat: no-repeat, no-repeat, no-repeat, no-repeat;
  background-size: 1px 100%, 20px 22px, 20px 22px, 20px 100%;
  background-position: right 20px center, right bottom, right bottom, right bottom;   
}

select:hover {
  background-image: linear-gradient(var(--accentFg), var(--accentFg)),
    linear-gradient(-135deg, transparent 50%, var(--accentFg) 50%),
    linear-gradient(-225deg, transparent 50%, var(--accentFg) 50%),
    linear-gradient(var(--accentFg) 42%, var(--accentBg) 42%);
}

select:active {
  background-image: linear-gradient(var(--accentFg), var(--accentFg)),
    linear-gradient(-135deg, transparent 50%, var(--accentFg) 50%),
    linear-gradient(-225deg, transparent 50%, var(--accentFg) 50%),
    linear-gradient(var(--accentFg) 42%, var(--accentBg) 42%);
  color: var(--accentBg);
  border-color: var(--accentFg);
  background-color: var(--accentFg);
}
</style>

</head>

<body>
	<?php include('includes/header.php');?>
	<div class="ts-main-content">
	<?php include('includes/leftbar.php');?>
		<div class="content-wrapper">
			<div class="container-fluid">

				<div class="row">
					<div class="col-md-12">
					<center><h3 class="page-title">Post A Vehicles</h3></center>

						<div class="row">
							<div class="col-md-12">
								<div class="panel panel-default">
									<div class="panel-heading">Basic Info</div>
<?php if($error){
	?><div class="errorWrap"><strong>ERROR</strong>:
	<?php echo htmlentities($error); ?> </div>
	<?php } else if($msg){?><div class="succWrap"><strong>SUCCESS</strong>:<?php echo htmlentities($msg); ?> </div><?php }?>

<div class="panel-body">
   <form method="post" class="form-horizontal" enctype="multipart/form-data">
  
  <div class="form-group">
   <label class="col-sm-2 control-label">Vehicle Name<span style="color:red">*</span></label>
     <div class="col-sm-4">
            <input type="text" pattern="(^[a-zA-Z ]{4,32})+$"    required title="please add 4 characters minimum"  name="vehicletitle" class="form-control" required>
     </div>
	 	 <input type="hidden" name="hidden" value="3" class="form-control" >
		 <input type="hidden" name="catname" value="2" class="form-control" >
<label class="col-sm-2 control-label">Select Location<span style="color:red">*</span></label>
<div class="col-sm-4" style="width:200px;">

<select class="theme-construction" name="brandname" required>
<div  style="width:500px;">
<option value=""> Select </option>

<?php $ret="select location_id,location_title from location";
$query= $dbh -> prepare($ret);
//$query->bindParam(':id',$id, PDO::PARAM_STR);
$query-> execute();
$results = $query -> fetchAll(PDO::FETCH_OBJ);
if($query -> rowCount() > 0)
{
foreach($results as $result)
{
?>
<option value="<?php echo htmlentities($result->location_id);?>" ><?php echo htmlentities($result->location_title);?> </option>
<?php }} ?>

</div>

</select>
</div>

</div>
<div class="form-group">
<label class="col-sm-2 control-label">Vehicle Overview<span style="color:red">*</span></label>
<div class="col-sm-10">
<textarea class="form-control"  pattern=".{5,}"  required title="5 characters minimum"name="vehicalorcview" rows="3" required></textarea>
</div>
</div>

<div class="form-group">

<label class="col-sm-2 control-label">Seating Capacity<span style="color:red">*</span></label>
<div class="col-sm-4">
<input type="number" name="seatingcapacity"  min="1" step="1" class="form-control" required>
</div>

</div>
								



<div class="form-group">
<label class="col-sm-2 control-label">Price(in Birr)<span style="color:red">*</span></label>
<div class="col-sm-4">
<input type="number"  min="1" step="1" name="priceperday" class="form-control" required>
</div>

<label class="col-sm-2 control-label">Condition<span style="color:red">*</span></label>
<div class="col-sm-4">
<select class="theme-construction" name="condition" required>
<option value=""> Select </option>
<option value="New"> New </option>
<option value="Used"> Used </option>
<option value="Refurbished"> Refurbished </option>
<option value="Used Abroad"> Used Abroad </option>

</select>
</div>

</div>

<div class="hr-dashed"></div>

<div class="form-group">
<label class="col-sm-2 control-label">Select Fuel Type<span style="color:red">*</span></label>
<div class="col-sm-4">
<select class="theme-construction" name="fueltype" required>
<option value=""> Select </option>

<option value="Petrol">Petrol</option>
<option value="Diesel">Diesel</option>
<option value="CNG">CNG</option>
</select>
</div>


   <label class="col-sm-2 control-label">Model Year<span style="color:red">*</span></label>
   <div class="col-sm-4">
   <input type="date" name="modelyear" class="form-control" required>
   </div>



</div>


<div class="form-group">

<label class="col-sm-2 control-label">Vehicle Key Words<span style="color:red">*</span></label>
<div class="col-sm-4">
<input type="text" name="keyword" pattern=".{3,}"   required title="3 characters minimum"class="form-control" required>
</div>

<label class="col-sm-2 control-label">Select Brands<span style="color:red">*</span></label>
<div class="col-sm-4">
<select class="theme-construction" name="location" required>
<option value=""> Select </option>
<option value="MARUTI">MARUTI</option>
<option value="BMW">BMW</option>
<option value="AUDI">AUDI</option>
<option value="NISAN">NISAN</option>
<option value="TOYOTA">TOYOTA</option>
<option value="WALSOAGON">WALSOAGON</option>
</select>
</div>
</div>

</div>

<div class="hr-dashed"></div>


<div class="form-group">
<div class="col-sm-12">
<h4><b>Upload  Item here Images</b></h4>
</div>
</div>


<div class="form-group">
<div class="col-sm-4">
Image 1 <span style="color:red">*</span><input type="file" name="img1" required>
</div>
<div class="col-sm-4">
Image 2<span style="color:red">*</span><input type="file" name="img2" required>
</div>
<div class="col-sm-4">
Image 3<span style="color:red">*</span><input type="file" name="img3" required>
</div>
</div>

<div class="form-group">
<div class="col-sm-4">
Image 4<span style="color:red">*</span><input type="file" name="img4" required>
</div>

</div>
<div class="row">
<div class="col-md-12">
<div class="panel panel-default">
<div class="panel-heading">Accessories</div>
<div class="panel-body">


<div class="form-group">
<div class="col-sm-3">
<div class="checkbox checkbox-inline">
<input type="checkbox" id="airconditioner" name="airconditioner" value="1">
<label for="airconditioner"> Air Conditioner </label>
</div>
</div>
<div class="col-sm-3">
<div class="checkbox checkbox-inline">
<input type="checkbox" id="powerdoorlocks" name="powerdoorlocks" value="1">
<label for="powerdoorlocks"> Power Door Locks </label>
</div></div>
<div class="col-sm-3">
<div class="checkbox checkbox-inline">
<input type="checkbox" id="antilockbrakingsys" name="antilockbrakingsys" value="1">
<label for="antilockbrakingsys"> AntiLock Braking System </label>
</div></div>
<div class="checkbox checkbox-inline">
<input type="checkbox" id="brakeassist" name="brakeassist" value="1">
<label for="brakeassist"> Brake Assist </label>
</div>
</div>



<div class="form-group">
<div class="col-sm-3">
<div class="checkbox checkbox-inline">
<input type="checkbox" id="powersteering" name="powersteering" value="1">
<input type="checkbox" id="powersteering" name="powersteering" value="1">
<label for="inlineCheckbox5"> Power Steering </label>
</div>
</div>
<div class="col-sm-3">
<div class="checkbox checkbox-inline">
<input type="checkbox" id="driverairbag" name="driverairbag" value="1">
<label for="driverairbag">Driver Airbag</label>
</div>
</div>
<div class="col-sm-3">
<div class="checkbox checkbox-inline">
<input type="checkbox" id="passengerairbag" name="passengerairbag" value="1">
<label for="passengerairbag"> Passenger Airbag </label>
</div></div>
<div class="checkbox checkbox-inline">
<input type="checkbox" id="powerwindow" name="powerwindow" value="1">
<label for="powerwindow"> Power Windows </label>
</div>
</div>


<div class="form-group">
<div class="col-sm-3">
<div class="checkbox checkbox-inline">
<input type="checkbox" id="cdplayer" name="cdplayer" value="1">
<label for="cdplayer"> CD Player </label>
</div>
</div>
<div class="col-sm-3">
<div class="checkbox h checkbox-inline">
<input type="checkbox" id="centrallocking" name="centrallocking" value="1">
<label for="centrallocking">Central Locking</label>
</div></div>
<div class="col-sm-3">
<div class="checkbox checkbox-inline">
<input type="checkbox" id="crashcensor" name="crashcensor" value="1">
<label for="crashcensor"> Crash Sensor </label>
</div></div>
<div class="col-sm-3">
<div class="checkbox checkbox-inline">
<input type="checkbox" id="leatherseats" name="leatherseats" value="1">
<label for="leatherseats"> Leather Seats </label>
</div>
</div>
</div>
									</div>
								</div>
							</div>
						</div>

<div class="hr-dashed"></div>								
</div>
</div>
</div>
</div>
							

<div class="row">
<div class="col-md-12">
<div class="panel panel-default">

<div class="panel-body">

	<div class="form-group">
	<div class="col-sm-8 col-sm-offset-2">
	<button class="btn btn-default" type="reset">Cancel</button>
	<button class="btn btn-primary" name="submit" type="submit">Add Action</button>
	</div>
	</div>

										</form>
									</div>
								</div>
							</div>
						</div>
						
					

					</div>
				</div>
				
			

			</div>
		</div>
	</div>

<?php
include('includes/jslink.php');
?>
</body>
</html>
