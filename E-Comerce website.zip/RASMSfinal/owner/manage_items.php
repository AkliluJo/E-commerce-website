<?php
session_start();
error_reporting(0);
include('includes/config.php');


if(isset($_REQUEST['del']))
	{
$delid=intval($_GET['del']);
$sql = "delete from products WHERE  product_id=:delid";
$query = $dbh->prepare($sql);
$query -> bindParam(':delid',$delid, PDO::PARAM_STR);
$query -> execute();
$msg="Item  record deleted successfully";
}


 ?>

<!doctype html>
<html lang="en" class="no-js">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<meta name="theme-color" content="#3e454c">
	
	<title>RASMS |Owners Manage Items   </title>

<?php
include('includes/csslink.php');
?>
  <style>
		.errorWrap {
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #dd3d36;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
.succWrap{
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #5cb85c;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
		</style>
</head>

<body>
	<?php include('includes/header.php');?>

	<div class="ts-main-content">
		<?php include('includes/leftbar.php');?>
		<div class="content-wrapper">
			<div class="container-fluid">

				<div class="row">
					<div class="col-md-12">
					<center><h3 class="page-title">Manage Items </h3></center>
						<!-- Zero Configuration Table -->
						<div class="panel panel-default">
							<div class="panel-heading">Item Details</div>
							<div class="panel-body">
							<?php if($error){?><div class="errorWrap"><strong>ERROR</strong>:<?php echo htmlentities($error); ?> </div><?php } 
				else if($msg){?><div class="succWrap"><strong>SUCCESS</strong>:<?php echo htmlentities($msg); ?> </div><?php }?>
								<table id="zctb" class="display table table-striped table-bordered table-hover" cellspacing="0" width="100%">
									<thead>
										<tr>
										<th>#</th>
											
											<th>Item Name</th>
											<th>Location </th>
										
											<th>Reg date</th>
											<th>Action</th>
											
										</tr>
									</thead>
									<tfoot>
										<tr>
										<th>#</th>
									
										<th>Item Name</th>
											<th>Location </th>
											
											<th>Reg date</th>
											<th>Action</th>
										</tr>
										</tr>
									</tfoot>
									<tbody>

<?php $sql = "SELECT products.product_title,products.product_location,products.RegDate,location.location_title,products.product_id from products join location on location.location_id=products.product_location WHERE products.owner_email='$_SESSION[email]' order by RegDate DESC";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $result)
{				?>	
		<tr>
			<td><?php echo htmlentities($cnt);?></td>
		
			<td><?php echo htmlentities($result->product_title);?></td>
			<td><?php echo htmlentities($result->location_title);?></td>
			
			<td><?php echo htmlentities($result->RegDate);?></td>
	        <td>
<a href="edit_items.php?edit=<?php echo $result->product_id;?>">
   <i class="fa fa-edit"></i></a>&nbsp;&nbsp;
<a href="manage_items.php?del=<?php echo $result->product_id;?>" onclick="return confirm('Do you want to delete');">
<i class="fa fa-close"></i></a></td>
		</tr>
			<?php $cnt=$cnt+1; }} ?>
										
									</tbody>
								</table>

						

							</div>
						</div>
					</div>
				</div>

			</div>
		</div>
	</div>
<?php
include('includes/jslink.php');
?>

</body>
</html>

