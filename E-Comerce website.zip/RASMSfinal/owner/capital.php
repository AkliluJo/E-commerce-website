<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(isset($_POST['submit']))
  {
$user_id = $_SESSION["email"];
$fname=$_POST['fname'];
$lname=$_POST['lname'];
$email=$_POST['email'];
$phone=$_POST['phone'];
$address=$_POST['address'];
$city=$_POST['city'];
$road=$_POST['road'];
$offred=$_POST['offred'];
$type=$_POST['type'];

/* $vimage1=$_FILES["img1"]["name"];

move_uploaded_file($_FILES["img1"]["tmp_name"],"../profile_images/".$_FILES["img1"]["name"]);  */

$sql="update user_info set first_name=:fname,last_name=:lname,email=:email,mobile=:phone,address1=:address,address2=:city,road=:road,delivery_offered=:offred,seller_type=:type where email=:user_id ";
$query = $dbh->prepare($sql);
$query->bindParam(':fname',$fname,PDO::PARAM_STR);
$query->bindParam(':lname',$lname,PDO::PARAM_STR);
$query->bindParam(':email',$email,PDO::PARAM_STR);
$query->bindParam(':phone',$phone,PDO::PARAM_STR);
$query->bindParam(':address',$address,PDO::PARAM_STR);
$query->bindParam(':city',$city,PDO::PARAM_STR);
$query->bindParam(':road',$road,PDO::PARAM_STR);
$query->bindParam(':offred',$offred,PDO::PARAM_STR);
$query->bindParam(':type',$type,PDO::PARAM_STR);

// $query->bindParam(':vimage1',$vimage1,PDO::PARAM_STR);

$query->bindParam(':user_id',$user_id,PDO::PARAM_STR);

$query->execute();

$msg="Detail Added successfully";

}
	?>
	
	
<?php
session_start();
error_reporting(0);
include('includes/config.php');

if(isset($_POST['submit']))
{
$aname=$_POST['aname'];
$balance1=$_POST['balance1'];
$balance2=$_POST['balance2'];
$balance=$balance1+$balance2;

$fname=$_POST['fname'];
$lname=$_POST['lname'];
$email=$_POST['email'];	
$accountname=$_POST['accountname'];
$accunttype=$_POST['accunttype'];


$sql = "UPDATE customerbank SET cus_fname=:fname,cus_lname=:lname,email=:email,account_name=:accountname,account_type=:accunttype,account_number=:aname,balance=:balance WHERE  email='$_SESSION[email]'";
$query = $dbh->prepare($sql);
$query -> bindParam(':fname',$fname, PDO::PARAM_STR);
$query -> bindParam(':lname',$lname, PDO::PARAM_STR);
$query -> bindParam(':email',$email, PDO::PARAM_STR);
$query -> bindParam(':accountname',$accountname, PDO::PARAM_STR);
$query -> bindParam(':accunttype',$accunttype, PDO::PARAM_STR);
$query-> bindParam(':aname',$aname, PDO::PARAM_STR);
$query-> bindParam(':balance',$balance, PDO::PARAM_STR);
$query -> execute();

$msg="Successfully reserve states as returned";
header("Location:capital.php");
exit;


}
?>	
	

<html lang="en" class="no-js">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<meta name="theme-color" content="#3e454c">
	
	<title>RASMS | Users add details</title>

<?php
include('includes/csslink.php');
?>

<link rel="stylesheet" type="text/css" href="css/example.css">
<style>
	.errorWrap {
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #dd3d36;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
.succWrap{
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #5cb85c;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
</style>
</head>


<body>
	<?php include('includes/header.php');?>
	<div class="ts-main-content">
	<?php include('includes/leftbar.php');?>
		<div class="content-wrapper">
			<div class="container-fluid">

				<div class="row">
					<div class="col-md-12">
					
						<center><h3 class="page-title">Manage Balances</h3></center>

						<div class="row">
							<div class="col-md-10">
								<div class="panel panel-default">
									<div class="panel-heading">Form fields</div>
									<div class="panel-body">
         <?php
		
		 $ret = "SELECT * FROM customerbank WHERE email='$_SESSION[email]'";
         $query= $dbh -> prepare($ret);
         //$query->bindParam(':id',$id, PDO::PARAM_STR);
         $query-> execute();
         $results = $query -> fetchAll(PDO::FETCH_OBJ);
         if($query -> rowCount() > 0)
         {
         foreach($results as $result)
         {
         ?>
		 
<form method="post" class="form-horizontal" enctype="multipart/form-data">
  	        	  <?php if($error){?><div class="errorWrap"><strong>ERROR</strong>:<?php echo htmlentities($error); ?> </div><?php } 
				else if($msg){?><div class="succWrap"><strong>SUCCESS</strong>:<?php echo htmlentities($msg); ?> </div><?php }?>
	
                <div class="col-lg-8 col-sm-10 center-block">
				
		
	
	
			   	<label><font  SIZE = "+1"><i class="fa fa-user" ></i>
				&nbsp;First Name</font></label><span class="status" id="name-status"></span>
                    
				<input type="text" id="fname" required pattern="(^[a-zA-Z ]{4,32})+$" value="<?php echo htmlentities($result->cus_fname);?>" maxlength=32 name="fname" >
			   <label><font  SIZE = "+1"><i class="fa fa-user" ></i>
				&nbsp;Last Name</font></label><span class="status" id="name-status"></span>
                    
				<input type="text" id="lname" required pattern="(^[a-zA-Z ]{4,32})+$" value="<?php echo htmlentities($result->cus_lname);?>" maxlength=32 name="lname"readonly >
				
				<label><font SIZE = "+1"><i class="fa fa-envelope"></i>&nbsp; Email </font></label><span class="status" id="name-status"></span>
                <input type="text"  required pattern="^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9]+(\.[a-z]{2,4})$" value="<?php echo htmlentities($result->email);?>" name="email" readonly> 
				
				<label><font SIZE = "+1"><i class="fa fa-mobile-phone"></i>&nbsp;&nbsp;Acount Name </font></label><span class="status" id="name-status"></span>
                <input type="text" pattern="(^[a-zA-Z ]{4,32})+$" required pattern ="please insert account name  only charactor" value="<?php echo htmlentities($result->account_name);?>" name="accountname" >

             <label><font SIZE = "+1"><i class="fa fa-mail-forward"></i> Account Number</font></label><span class="status" id="name-status"></span>
			 
		     <input type="number"  required  value="<?php echo htmlentities($result->account_number);?>" maxlength=13 name="aname" >	

	 
		<?php }} ?>
        <label><font SIZE = "+1"> Account Type</font></label><span class="status" id="state-status"></span>
                    <select name="accunttype" required>
						<option value="Saving" >Saving</option>
						<option value="Deposit" >Deposit</option> 

                    </select>

		     <input type="number"  required  value="<?php echo htmlentities($result->account_number);?>" maxlength=16 name="aname" >	
        <label><font SIZE = "+1"><i class="fa fa-road"></i>  Balance</font></label><span class="status" id="name-status"></span>

<input type="hidden"  value="<?php echo htmlentities($result->balance);?>" name="balance1" id="contactno" readonly>
<input type="number" class="form-control" pattern ="[0-9]{}"  name="balance2" id="contactno" required>       

                  <div class="hr-dashed"></div>
                          
                    <div class="center">
                        <button class="submit" type="submit" id="register-submit" name="submit" onclick="return validForm()" >Submit</button>
					
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						 <button class="submit" type="reset" id="register-submit">Reset</button>
                    </div>
                </div>
            </form>
			
        </div>
			
	
									</div>
								</div>
							</div>
							
						</div>
						
					

					</div>
				</div>
				
			
			</div>
		</div>


<?php
include('includes/jslink.php');
?>


</body>

</html>
