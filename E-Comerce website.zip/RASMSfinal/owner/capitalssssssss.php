<?php
session_start();
error_reporting(0);
include('includes/config.php');

if(isset($_POST['submit']))
{
$aname=$_POST['aname'];
$balance1=$_POST['balance1'];
$balance2=$_POST['balance2'];
$balance=$balance1+$balance2;

$fname=$_POST['fname'];
$lname=$_POST['lname'];
$email=$_POST['email'];	
$accountname=$_POST['accountname'];
$accunttype=$_POST['accunttype'];


$sql = "UPDATE customerbank SET cus_fname=:fname,cus_lname=:lname,email=:email,account_name=:accountname,account_type=:accunttype,account_number=:aname,balance=:balance WHERE  email='$_SESSION[email]'";
$query = $dbh->prepare($sql);
$query -> bindParam(':fname',$fname, PDO::PARAM_STR);
$query -> bindParam(':lname',$lname, PDO::PARAM_STR);
$query -> bindParam(':email',$email, PDO::PARAM_STR);
$query -> bindParam(':accountname',$accountname, PDO::PARAM_STR);
$query -> bindParam(':accunttype',$accunttype, PDO::PARAM_STR);
$query-> bindParam(':aname',$aname, PDO::PARAM_STR);
$query-> bindParam(':balance',$balance, PDO::PARAM_STR);
$query -> execute();

$msg="Successfully reserve states as returned";
header("Location:capital.php");
exit;


}
?>

<!doctype html>
<html lang="en" class="no-js">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<meta name="theme-color" content="#3e454c">
	
	<title>RASMS| Owners manage balance</title>

   <?php
include('includes/csslink.php');
	?>
  <style>
		.errorWrap {
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #dd3d36;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
.succWrap{
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #5cb85c;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
		</style>


</head>

<body>
	<?php include('includes/header.php');?>
	<div class="ts-main-content">
	<?php include('includes/leftbar.php');?>
		<div class="content-wrapper">
			<div class="container-fluid">

				<div class="row">
					<div class="col-md-12">
					
						<h2 class="page-title">Manage Balance</h2>

						<div class="row">
							<div class="col-md-10">
								<div class="panel panel-default">
									<div class="panel-heading">Form fields</div>
									<div class="panel-body">
										<form method="post" name="chngpwd" class="form-horizontal" onSubmit="return valid();">
										
											
  	        	  <?php if($error){?><div class="errorWrap"><strong>ERROR</strong>:<?php echo htmlentities($error); ?> </div><?php } 
			else if($msg){?>
				<div class="succWrap"><strong>SUCCESS</strong>:<?php echo htmlentities($msg); ?> 
				</div><?php } 
				?>
<?php $sql = "SELECT * from customerbank where email='$_SESSION[email]'";  
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $result)
{			

 }} ?>	

	
										<div class="form-group">
												<label class="col-sm-4 control-label"> First Name</label>
												<div class="col-sm-8">
													<input type="text" class="form-control" value="<?php echo htmlentities($result->cus_fname);?>" name="fname" id="contactno" readonly>
												</div>
											</div>
                                         <div class="form-group">
												<label class="col-sm-4 control-label"> Last Name</label>
												<div class="col-sm-8">
													<input type="text" class="form-control" value="<?php echo htmlentities($result->cus_lname);?>" name="lname" id="contactno" readonly>
												</div>
											</div>											
												   											   
											<div class="form-group">
										<label class="col-sm-4 control-label"> Email id</label>
												<div class="col-sm-8">
													<input type="email" class="form-control" name="email" id="email" value="<?php echo htmlentities($result->email);?>" readonly>
												</div>
											</div>
                                         <div class="form-group">
												<label class="col-sm-4 control-label"> Acount Name</label>
												<div class="col-sm-8">
													<input type="text" class="form-control" value="<?php echo htmlentities($result->account_name);?>" pattern="(^[a-zA-Z ]{4,32})+$" name="accountname" id="contactno" >
												</div>
											</div>
								
											<div class="form-group">
												<label class="col-sm-4 control-label"> Account Number </label>
												<div class="col-sm-8">
													<input type="number" value="<?php echo htmlentities($result->account_number);?>" class="form-control" pattern="(^[a-zA-Z ]{4,32})+$"  name="aname" id="contactno" required>
												</div>
											</div>
											
											
											<div class="form-group">
												<label class="col-sm-4 control-label"> Account Type </label>
												<div class="col-sm-8">
													<input type="text" class="form-control" pattern="(^[a-zA-Z ]{4,32})+$"  name="accunttype" id="contactno" required>
												</div>
											</div>
											
										
												<div class="form-group">
												<label class="col-sm-4 control-label"> Balance</label>
												<div class="col-sm-8">
										<input type="hidden" class="form-control" value="<?php echo htmlentities($result->balance);?>" name="balance1" id="contactno" readonly>
										
										<input type="number" class="form-control" pattern ="[0-9]{}" name="balance2" id="contactno" required>
										
												</div>
											</div>

											<div class="hr-dashed"></div>
	
											<div class="form-group">
												<div class="col-sm-8 col-sm-offset-4">
								<button class="btn btn-default" type="reset">Cancel</button>
													<button class="btn btn-primary" name="submit" type="submit" >Deposit</button>
												</div>
											</div>
<script type=" text/javascript">
function mass(){
	alert("Successfully deposited");
	return true;
}

</script>
										</form>

									</div>
								</div>
							</div>
							
						</div>
						
					

					</div>
				</div>
				
			
			</div>
		</div>
	</div>

   <?php
include('includes/jslink.php');
	?>
</body>

</html>
