<?php
session_start();
error_reporting(0);
include('includes/config.php');


	?>

<!doctype html>
<html lang="en" class="no-js">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<meta name="theme-color" content="#3e454c">
	
	<title>RASMS| Owners Add Items Option</title>
<?php
include('includes/csslink.php');
?>
<style>
		.errorWrap {
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #dd3d36;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
.succWrap{
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #5cb85c;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
		</style>
<style>
:root {
  --radius: 2px;
  --baseFg: dimgray;
  --baseBg: white;
  --accentFg: #006fc2;
  --accentBg: #bae1ff;
}

.theme-pink {
  --radius: 6em;
  --baseFg: #c70062;
  --baseBg: #ffe3f1;
  --accentFg: #c70062;
  --accentBg: #ffaad4;
}

.theme-construction {
  --radius: 10;
  --baseFg: white;
  --baseBg: black;
  --accentFg: black;
  --accentBg: orange;
}

select {
  font: 400 12px/1.3 sans-serif;
  -webkit-appearance: none;
  appearance: none;
  color: var(--baseFg);
  border: 1px solid var(--baseFg);
  line-height: 1;
  outline: 0;
  padding: 0.65em 2.5em 0.55em 0.75em;
  border-radius: var(--radius);
  background-color: var(--baseBg);
  background-image: linear-gradient(var(--baseFg), var(--baseFg)),
    linear-gradient(-135deg, transparent 50%, var(--accentBg) 50%),
    linear-gradient(-225deg, transparent 50%, var(--accentBg) 50%),
    linear-gradient(var(--accentBg) 42%, var(--accentFg) 42%);
  background-repeat: no-repeat, no-repeat, no-repeat, no-repeat;
  background-size: 1px 100%, 20px 22px, 20px 22px, 20px 100%;
  background-position: right 20px center, right bottom, right bottom, right bottom;   
}

select:hover {
  background-image: linear-gradient(var(--accentFg), var(--accentFg)),
    linear-gradient(-135deg, transparent 50%, var(--accentFg) 50%),
    linear-gradient(-225deg, transparent 50%, var(--accentFg) 50%),
    linear-gradient(var(--accentFg) 42%, var(--accentBg) 42%);
}

select:active {
  background-image: linear-gradient(var(--accentFg), var(--accentFg)),
    linear-gradient(-135deg, transparent 50%, var(--accentFg) 50%),
    linear-gradient(-225deg, transparent 50%, var(--accentFg) 50%),
    linear-gradient(var(--accentFg) 42%, var(--accentBg) 42%);
  color: var(--accentBg);
  border-color: var(--accentFg);
  background-color: var(--accentFg);
}
</style>
</head>

<body>
	<?php include('includes/header.php');?>
	<div class="ts-main-content">
	<?php include('includes/leftbar.php');?>
		<div class="content-wrapper">
			<div class="container-fluid">

				<div class="row">
					<div class="col-md-12">
					<center><h3 class="page-title">Post items option</h3></center>

						<div class="row">
							<div class="col-md-12">
								<div class="panel panel-default">
									<div class="panel-heading">Basic Info</div>
<?php if($error){?><div class="errorWrap"><strong>ERROR</strong>:<?php echo htmlentities($error); ?> </div><?php } 
				else if($msg){?><div class="succWrap"><strong>SUCCESS</strong>:<?php echo htmlentities($msg); ?> </div><?php }?>

<div class="panel-body">
   <form method="post" class="form-horizontal" enctype="multipart/form-data">
   <div class="form-group">
<label class="col-sm-2 control-label">Add option<span style="color:red">*</span></label>
<div class="col-sm-4">

<select class="selectpicker" name="location"  onchange="javascript:handleSelect(this)" required>
<option value="option_items"  > Select One </option>
<option value="post_items">Sale Only</option>
<option value="rentitems">Rent Only</option>
<option value="rentandsaleitems">Rent And Sale</option>

</select>
 <script type="text/javascript">

  function handleSelect(elm)
  {
     window.location = elm.value+".php";
  }
</script>

</div>
</div>
  <div class="form-group">
   <label class="col-sm-2 control-label"> Item Title<span style="color:red">*</span></label>
     <div class="col-sm-4">
            
			<input type="text" pattern="(^[a-zA-Z ]{4,32})+$"    required title="please add 4 characters minimum"  name="vehicletitle" class="form-control" disabled>
     </div>
<label class="col-sm-2 control-label">Select Location<span style="color:red">*</span></label>
<div class="col-sm-4" style="width:200px;">

<select class="theme-construction" name="brandname" disabled>
<option value=""> Select </option>

<?php $ret="select brand_id,brand_title from brands";
$query= $dbh -> prepare($ret);
//$query->bindParam(':id',$id, PDO::PARAM_STR);
$query-> execute();
$results = $query -> fetchAll(PDO::FETCH_OBJ);
if($query -> rowCount() > 0)
{
foreach($results as $result)
{
?>
<option value="<?php echo htmlentities($result->brand_id);?>"><?php echo htmlentities($result->brand_title);?></option>
<?php }} ?>



</select>
</div>

</div>

<div class="form-group">
<label class="col-sm-2 control-label">Item Overview<span style="color:red">*</span></label>
<div class="col-sm-10">

<textarea class="form-control"  pattern=".{5,}"  required title="5 characters minimum" name="vehicalorcview" rows="3" disabled></textarea>
</div>
</div>

<div class="form-group">
<label class="col-sm-2 control-label">Select Category<span style="color:red">*</span></label>
<div class="col-sm-4" style="width:200px;">

<select class="theme-construction" name="catname" disabled>
<option value=""> Select </option>

         <?php $ret="select cat_id,cat_title from categories";
         $query= $dbh -> prepare($ret);
         //$query->bindParam(':id',$id, PDO::PARAM_STR);
         $query-> execute();
         $results = $query -> fetchAll(PDO::FETCH_OBJ);
         if($query -> rowCount() > 0)
         {
         foreach($results as $result)
         {
         ?>

<option  value="<?php echo htmlentities($result->cat_id);?>">
<?php echo htmlentities($result->cat_title);?>
</option>
         <?php }} ?>


</select>


</div>

</div>
								



<div class="form-group">
<label class="col-sm-2 control-label">Price(in Birr)<span style="color:red">*</span></label>
<div class="col-sm-4">

<input type="number"  min="1" step="1" name="priceperday" class="form-control" disabled>

</div>

<label class="col-sm-2 control-label">Condition<span style="color:red">*</span></label>
<div class="col-sm-4">
<select class="theme-construction" name="condition" disabled>
<option value=""> Select </option>
<option value="New"> New </option>
<option value="Used"> Used </option>
<option value="Refurbished"> Refurbished </option>
<option value="Used Abroad"> Used Abroad </option>

</select>
</div>
</div>

<div class="hr-dashed"></div>


<label class="col-sm-2 control-label">Product Brand(if any)<span style="color:red">*</span></label>
<div class="col-sm-4">
<input type="text" name="location" pattern=".{2,}"  required title="2 characters minimum" class="form-control" disabled>
</div>

<div class="form-group">

<label class="col-sm-2 control-label">Product Key words<span style="color:red">*</span></label>
<div class="col-sm-4">

<input type="text" name="keyword" pattern=".{3,}"   required title="3 characters minimum"class="form-control" disabled>
</div>
</div>

</div>

<div class="hr-dashed"></div>


<div class="form-group">
<div class="col-sm-12">
<h4><b>Upload Images</b></h4>
</div>
</div>


<div class="form-group">
<div class="col-sm-4">
Image 1 <span style="color:red">*</span><input type="file" name="img1" disabled>
</div>
<div class="col-sm-4">
Image 2<span style="color:red">*</span><input type="file" name="img2" disabled>
</div>
<div class="col-sm-4">
Image 3<span style="color:red">*</span><input type="file" name="img3" disabled>
</div>
</div>

<div class="form-group">
<div class="col-sm-4">
Image 4<span style="color:red">*</span><input type="file" name="img4" disabled>
</div>


</div>

						</div>






<div class="hr-dashed"></div>								
</div>
</div>
</div>
</div>
							

<div class="row">
<div class="col-md-12">
<div class="panel panel-default">

<div class="panel-body">

	<div class="form-group">
	<div class="col-sm-8 col-sm-offset-2">
	<button class="btn btn-default" type="reset"disabled>Cancel</button>
	<button class="btn btn-primary" name="submit" type="submit"disabled>Save changes</button>
	</div>
	</div>

										</form>
									</div>
								</div>
							</div>
						</div>
						
					

					</div>
				</div>
				
			

			</div>
		</div>
	</div>
<?php
include('includes/jslink.php');
?>
</body>
</html>
