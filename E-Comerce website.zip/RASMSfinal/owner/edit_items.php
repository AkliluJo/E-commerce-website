<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(isset($_POST['submit']))
  {
$location=$_POST['location'];
$condition=$_POST['condition'];
$itemname=$_POST['itemname'];
$overview=$_POST['overview'];
$keyword=$_POST['keyword'];
$edit=intval($_GET['edit']);



$sql="update products set
product_location=:location,condition=:condition,product_title=:itemname,product_desc=:overview,product_keywords=:keyword where product_id=:edit ";

$query = $dbh->prepare($sql);
$query->bindParam(':location',$location,PDO::PARAM_STR);
$query->bindParam(':condition',$condition,PDO::PARAM_STR);
$query->bindParam(':itemname',$itemname,PDO::PARAM_STR);

$query->bindParam(':overview',$overview,PDO::PARAM_STR);
$query->bindParam(':keyword',$keyword,PDO::PARAM_STR);
$query->bindParam(':edit',$edit,PDO::PARAM_STR);
$query->execute();

$msg="Data updated successfully";

}
	?>
<!doctype html>
<html lang="en" class="no-js">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<meta name="theme-color" content="#3e454c">
	
	<title>RASMS | Owners Edit Items Info</title>

<?php
include('includes/csslink.php');
?>
	<style>
		.errorWrap {
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #dd3d36;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
.succWrap{
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #5cb85c;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
		</style>
		<style>
:root {
  --radius: 2px;
  --baseFg: dimgray;
  --baseBg: white;
  --accentFg: #006fc2;
  --accentBg: #bae1ff;
}

.theme-pink {
  --radius: 6em;
  --baseFg: #c70062;
  --baseBg: #ffe3f1;
  --accentFg: #c70062;
  --accentBg: #ffaad4;
}

.theme-construction {
  --radius: 10;
  --baseFg: white;
  --baseBg: black;
  --accentFg: black;
  --accentBg: orange;
}

select {
  font: 400 12px/1.3 sans-serif;
  -webkit-appearance: none;
  appearance: none;
  color: var(--baseFg);
  border: 1px solid var(--baseFg);
  line-height: 1;
  outline: 0;
  padding: 0.65em 2.5em 0.55em 0.75em;
  border-radius: var(--radius);
  background-color: var(--baseBg);
  background-image: linear-gradient(var(--baseFg), var(--baseFg)),
    linear-gradient(-135deg, transparent 50%, var(--accentBg) 50%),
    linear-gradient(-225deg, transparent 50%, var(--accentBg) 50%),
    linear-gradient(var(--accentBg) 42%, var(--accentFg) 42%);
  background-repeat: no-repeat, no-repeat, no-repeat, no-repeat;
  background-size: 1px 100%, 20px 22px, 20px 22px, 20px 100%;
  background-position: right 20px center, right bottom, right bottom, right bottom;   
}

select:hover {
  background-image: linear-gradient(var(--accentFg), var(--accentFg)),
    linear-gradient(-135deg, transparent 50%, var(--accentFg) 50%),
    linear-gradient(-225deg, transparent 50%, var(--accentFg) 50%),
    linear-gradient(var(--accentFg) 42%, var(--accentBg) 42%);
}

select:active {
  background-image: linear-gradient(var(--accentFg), var(--accentFg)),
    linear-gradient(-135deg, transparent 50%, var(--accentFg) 50%),
    linear-gradient(-225deg, transparent 50%, var(--accentFg) 50%),
    linear-gradient(var(--accentFg) 42%, var(--accentBg) 42%);
  color: var(--accentBg);
  border-color: var(--accentFg);
  background-color: var(--accentFg);
}
</style>
</head>

<body>
	<?php include('includes/header.php');?>
	<div class="ts-main-content">
	<?php include('includes/leftbar.php');?>
		<div class="content-wrapper">
			<div class="container-fluid">

				<div class="row">
					<div class="col-md-12">
					<center><h3 class="page-title">Edit Items </h3></center>

						<div class="row">
							<div class="col-md-12">
								<div class="panel panel-default">
									<div class="panel-heading">Basic Info</div>
<div class="panel-body">
<?php if($msg){?><div class="succWrap"><strong>SUCCESS</strong>:<?php echo htmlentities($msg); ?> </div><?php } ?>

<?php 
$edit=intval($_GET['edit']);
$sql ="SELECT products.*,location.location_title,location.location_id as bid from products join location on location.location_id=products.product_location where products.product_id=:edit";
$query = $dbh -> prepare($sql);
$query-> bindParam(':edit', $edit, PDO::PARAM_STR);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $result)
{	?>
<form method="post" class="form-horizontal" enctype="multipart/form-data">
<div class="form-group">
   <label class="col-sm-2 control-label"> Item Name<span style="color:red">*</span></label>
     <div class="col-sm-4">
            
			<input type="text" pattern="(^[a-zA-Z ]{4,32})+$"    required title="please add 4 characters minimum"  name="itemname" value="<?php echo htmlentities($result->product_title)?>" class="form-control" required>
     </div>

</div>
<div class="form-group">
<label class="col-sm-2 control-label">Item Overview<span style="color:red">*</span></label>
<div class="col-sm-10">

<textarea class="form-control"  pattern=".{5,}"  required title="5 characters minimum" name="overview" rows="3" required><?php echo htmlentities($result->product_desc);?></textarea>
</div>

</div>
											

<div class="form-group">
<label class="col-sm-2 control-label">Select Location<span style="color:red">*</span></label>
<div class="col-sm-4" style="width:200px;">

<select class="theme-construction" name="location" required>
<option value="<?php echo htmlentities($result->bid);?>"><?php echo htmlentities($bdname=$result->location_title); ?> </option>
<?php $ret="select location_id,location_title from location";
$query= $dbh -> prepare($ret);

$query-> execute();
$resultss = $query -> fetchAll(PDO::FETCH_OBJ);
if($query -> rowCount() > 0)
{
foreach($resultss as $results)
{
if($results->location_title==$bdname)
{
continue;
} else{
?>
<option value="<?php echo htmlentities($results->location_id);?>"><?php echo htmlentities($results->location_title);?></option>
<?php }}} ?>

</select>
</div>
</div>

<div class="form-group">
<label class="col-sm-2 control-label">Product Key words<span style="color:red">*</span></label>
<div class="col-sm-4">

<input type="text" name="keyword" pattern=".{3,}"   required title="3 characters minimum"class="form-control" value="<?php echo htmlentities($result->product_keywords)?>" required>
</div>

<label class="col-sm-2 control-label">Condition<span style="color:red">*</span></label>
<div class="col-sm-4">
<select class="theme-construction" name="condition" required>
<option value="<?php echo htmlentities($result->bid);?>"><?php echo htmlentities($dname=$result->condition); ?> </option>

<option value="New"> New </option>
<option value="Used"> Used </option>
<option value="Refurbished"> Refurbished </option>
<option value="Used Abroad"> Used Abroad </option>

</select>
</div>
</div>




<div class="hr-dashed"></div>								
<div class="form-group">
<div class="col-sm-12">
<h4><b>Vehicle Images</b></h4>
</div>
</div>


<div class="form-group">
<div class="col-sm-4">
Image1  <img src="../product_images/<?php echo htmlentities($result->product_image);?>" width="120" height="110" style="border:solid 1px #000">
<a href="changeimage.php?imgid=<?php echo htmlentities($result->product_id)?>">Change Image</a>
</div>
<div class="col-sm-4">
Image2  <img src="../product_images/<?php echo htmlentities($result->product_image1);?>" width="120" height="110" style="border:solid 1px #000">
<a href="changeimage1.php?imgid=<?php echo htmlentities($result->product_id)?>">Change Image</a>
</div>
</div>

<div class="form-group">
<div class="col-sm-4">
Image3  <img src="../product_images/<?php echo htmlentities($result->product_image2);?>" width="120" height="110" style="border:solid 1px #000">
<a href="changeimage2.php?imgid=<?php echo htmlentities($result->product_id)?>">Change Image</a>
</div>
<div class="col-sm-4">
Image4  <img src="../product_images/<?php echo htmlentities($result->product_image3);?>" width="120" height="110" style="border:solid 1px #000">
<a href="changeimage3.php?imgid=<?php echo htmlentities($result->product_id)?>">Change Image</a>
</div>
</div>

<div class="hr-dashed"></div>									
</div>
</div>
</div>
</div>						

<div class="row">
<div class="col-md-12">
<div class="panel panel-default">
<div class="panel-body">




<?php }} ?>

<div class="form-group">
<div class="col-sm-8 col-sm-offset-2" >
<div class="col-sm-4">

<button class="btn btn-default" type="reset">Cancel</button>	
</div>
<div class="col-sm-4">
<button class="btn btn-primary" name="submit" type="submit" style="margin-top:4%">
Save changes</button>
</div>
</div>

										</form>
					
				</div>	</div>
				
			

			</div>
		</div>
	</div>

<?php
include('includes/jslink.php');
?>

</body>
</html>
