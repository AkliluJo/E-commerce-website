<?php

error_reporting(0);
include('admin/includes/config.php');
if(isset($_POST['send']))
  {
$name=$_POST['fullname'];
$email=$_POST['email'];

$contactno=$_POST['contactno'];
	$append='+251-';
	$phone = $append.$contactno;
$message=$_POST['message'];
$sql="INSERT INTO  tblcontactusquery(name,EmailId,ContactNumber,Message) VALUES(:name,:email,:phone,:message)";
$query = $dbh->prepare($sql);
$query->bindParam(':name',$name,PDO::PARAM_STR);
$query->bindParam(':email',$email,PDO::PARAM_STR);
$query->bindParam(':phone',$phone,PDO::PARAM_STR);
$query->bindParam(':message',$message,PDO::PARAM_STR);
$query->execute();
$lastInsertId = $dbh->lastInsertId();
if($lastInsertId)
{
$msg="Query Sent. We will contact you shortly";
}
else 
{
$error="Something went wrong. Please try again";
}

}
?>
<head>

<title>Contact Us</title>



 <style>
    .errorWrap {
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #dd3d36;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
.succWrap{
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #5cb85c;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}


/*-----------------
	1.2. Button
-------------------------*/

.btn {
  border: medium none;
  border-radius: 3px;
  color: #ffffff;
  font-size: 16px;
  font-weight: 800;
  line-height: 30px;
  margin: auto;
  padding: 7px 36px;
  transition: all 0.3s linear 0s;
   -moz-transition: all 0.3s linear 0s;
    -o-transition: all 0.3s linear 0s;
     -webkit-transition: all 0.3s linear 0s;
      -ms-transition: all 0.3s linear 0s;
}
.btn .fa {
  font-size: 20px;
  margin-left: 5px;
  vertical-align: middle;
}
.btn.btn-lg {
	font-size: 28px;
	line-height: 35px;
	padding: 25px 83px;
}
.btn.btn-lg:hover {
	background:#c51514
}
.btn:hover, .btn:focus {
	color: #ffffff;
	outline:none;
}
.btn-link {
  font-weight: 800;
}
.btn.outline {
	background:none;
	border-style:solid;
	border-width:1px;
}
.btn.outline:hover, .btn.outline:focus {
	color:#fff;
}
.btn.btn-xs {
	font-size:12px;
	padding:0px 25px;
}
.btn.btn-xs .fa {
	margin:0 5px;
	font-size:14px;
}


.btn,
.nav-tabs > li.active > a,
.nav-tabs > li.active > a:focus,
.nav-tabs > li.active > a:hover,
.recent-tab .nav.nav-tabs li.active a,
.fun-facts-m, .featured-icon,
.owl-pagination .owl-page.active,
#testimonial-slider .owl-pagination .owl-page.active,
.social-follow.footer-social a:hover,
.back-top a,
.team_more_info ul li a:hover,
.tag_list ul li a:hover,
.pagination ul li.current,
.pagination ul li:hover,
.btn.outline:hover,
.btn.outline:focus,
.share_article ul li:hover,
.nav-tabs > li a:hover,
.nav-tabs > li a:focus,
.label-icon,
.navbar-default .navbar-toggle .icon-bar,
.navbar-default .navbar-toggle:focus, .navbar-default .navbar-toggle:hover,
.label_icon,
.navbar-nav > li > .dropdown-menu,
.add_compare .checkbox,
.search_other,
.vs,
.td_divider,
.search_other_inventory,
#other_info,
.main_bg,
.slider .slider-handle, .slider .slider-selection {
  background: #fa2837 none repeat scroll 0 0;
  fill: #fa2837;
}
.btn:hover, .btn:focus,
.search_other:hover,
#other_info:hover {
	background-color: #c60210;
	fill: #fb4d59;
}

.nav-tabs > li.active > a,
.nav-tabs > li.active > a:focus,
.nav-tabs > li.active > a:hover,
.social-follow.footer-social a:hover,
.page-header,
.tag_list ul li a:hover,
.btn.outline,
.share_article ul li,
blockquote,
.social-follow a:hover,
.radio label:before,
.navbar-default .navbar-toggle,
.owl-buttons div,
.about_info .icon_box {
	border-color: #fa2837;
}

.recent-tab .nav.nav-tabs li.active::after {
	border-color: #fa2837 rgba(0, 0, 0, 0) rgba(0, 0, 0, 0);
}
.td_divider:after {
	border-color: rgba(0, 0, 0, 0) rgba(0, 0, 0, 0 ) rgba(0, 0, 0, 0 ) #fa2837 ;
}

.navbar-nav > li > .dropdown-menu li {
  border-bottom: 1px solid #e21625;
}

@media (max-width:767px) {
.navbar-default .navbar-nav .open .dropdown-menu > li > a:focus, .navbar-default .navbar-nav .open .dropdown-menu > li > a:hover {
	color:#fa2837;
}


}

/*-----------------
	1.5. Form
---------------------------*/

.form-group {
  margin-bottom: 15px;
  position: relative;
}
.form-label {
  color: #111111;
  font-size: 14px;
  font-weight: 400;
  margin: 0 auto 8px;
}
.form-control {
  background: #eeeeee none repeat scroll 0 0;
  border: 0 none;
  border-radius: 3px;
  box-shadow: none;
  color: #888888;
  font-size: 15px;
  height: 46px;
  line-height: 30px;
  padding: 0 15px;
}
.form-control:hover, .form-control:focus {
	box-shadow:none;
	outline:none
}
.select {
	position:relative;
}
.select select {
  appearance: none;
   -moz-appearance: none;
   -o-appearance: none;
   -webkit-appearance: none;
   -ms-appearance: none;

}
.select::after {
  color: #878787;
  content: "";
  cursor: pointer;
  font-family: fontawesome;
  font-size: 15px;
  padding: 12px 0;
  pointer-events: none;
  position: absolute;
  right: 15px;
  top: 0;
}
.form-control option {
  padding: 10px;
}
.control-label {
	color:#555;
	font-size:15px;
	font-weight:700;
}
.radio label, .checkbox label {
  cursor: pointer;
  font-size: 14px;
  font-weight: 400;
  padding-left: 26px;
  position: relative;
}
.radio input[type=radio],
.checkbox input[type=checkbox] {
	display: none;
}
.radio label:before {
    background-color:transparent;
	border-style:solid;
	border-width:1px;
	border-radius:50%;
    content: "";
    display: inline-block;
    height: 15px;
    left: 0;
	top:4px;
    position: absolute;
    width: 15px;
}
.checkbox label::before {
  background-color: rgba(0, 0, 0, 0);
  border: 1px solid #111111;
  content: "";
  display: inline-block;
  height: 16px;
  left: 0;
  position: absolute;
  top: 4px;
  width: 16px;
}
.radio input[type=radio]:checked + label:before {
	content: "\2022";
	font-size: 15px;
	text-align: center;
    line-height: 11px;
}
.checkbox input[type=checkbox]:checked + label:before {
	content: "\2713";
	font-size: 12px;
	text-align: center;
    line-height: 14px;
}

.black_input .form-control {
	background:#222;
	border-radius:3px;
	color:#fff;
	border:#222 solid 1px;
	font-size:17px;
}
.checkbox, .radio {
  padding-top: 5px;
}

.form-control.white_bg {
	background:#fff;
	border:#e6e5e5 solid 1px;
}


/*-----------------------------------------------------------
	1.7. Section-background-color & sectino-heading
-------------------------------------------------------------------*/
.secondary-bg {
	background-color:#222;
	color:#fff;
}
.dark-bg {
	background-color:#111;
	color:#fff;
}
.gray-bg {
	background:#eeeeee;
}
.primary-bg {
  background: #fa2837;
  color:#fff;
}
.section-padding {
  padding: 110px 0;
}
.section-header {
  padding-bottom: 55px;
}
.section-header h2 {
  margin-bottom: 30px;
}
.section-header h2 span {
  font-weight: 300;
}
.section-header p {
  font-size: 17px;
}




/*=======================
	10. Contact-Us-Page
================================*/
.contactus_page {
	background-image:url(../images/contact-page-header-img.jpg);
}
.contact_form {
	padding:28px;
}
.contact_us h3 {
	margin-bottom:22px;
}
.contact_form .form-control {
	margin-bottom:8px;
}
.contact_form .form-group {
	margin-bottom:35px;
}
.contact_detail ul {
	padding:0px;
	margin:0px
}
.contact_detail li {
	list-style:none;
	color:#555;
	font-size:16px;
	line-height:24px;
	margin:20px 0;
	padding:0 150px 0 0;
}
.contact_detail li a {
	color:#555;
}
.icon_wrap .fa {
  background: #fff none repeat scroll 0 0;
  border: 1px solid #e6e5e5;
  border-radius: 50%;
  color: #555;
  display: inline-block;
  font-size: 22px;
  height: 44px;
  line-height: 44px;
  margin-right: 15px;
  text-align: center;
  vertical-align: middle;
  width: 44px;
}
.contact_info_m, .icon_wrap {
	display:table-cell;
	vertical-align:middle;
}
.map_wrap {
	margin:40px 0 0;
}
.map_wrap iframe {
	width:100%;
	height:420px;
}





    </style>
</head>


   <div class="main main-raised">

    
		<!-- SECTION -->
		<div class="section">
			<!-- container -->
			<div class="container">
				<!-- row -->
				<div class="row">



					<!-- Products tab & slick -->
					<div class="col-md-12 mainn mainn-raised">
						<div class="row">
							<div class="products-tabs">
								<!-- tab -->



<section class="contact_us section-padding">
  <div class="container">
  
    <div  class="row">
      <div class="col-md-6">
        <h3>Get in touch using the form below</h3>
          <?php if($error){?><div class="errorWrap"><strong>ERROR</strong>:<?php echo htmlentities($error); ?> </div><?php } 
        else if($msg){?><div class="succWrap"><strong>SUCCESS</strong>:<?php echo htmlentities($msg); ?> </div><?php }?>
        <div class="contact_form gray-bg">
          <form  method="post">
            <div class="form-group">
              <label class="control-label">Full Name </label>
              <input type="text" name="fullname" pattern="(^[a-zA-Z ]{4,32})+$" required pattern ="please insert account name  only charactor" class="form-control white_bg" id="fullname" required>
            
			</div>
            <div class="form-group">
              <label class="control-label">Email Address </label>
              <input type="email" name="email" class="form-control white_bg" id="emailaddress" required>
            </div>
            <div class="form-group">
              <label class="control-label">Phone Number </label>
              <input type="text" name="contactno" maxlength ="9" pattern="[9]{1}[0-9]{8}" title="Phone number with 9 and remaing 8 digit with 0-9" class="form-control white_bg" id="phonenumber" required>
            </div>
            <div class="form-group">
              <label class="control-label">Message </label>
              <textarea class="form-control white_bg" name="message" rows="4" required></textarea>
            </div>
            <div class="form-group">
              <button class="btn"   type="submit" name="send" type="submit">Send Message <span class="angle_arrow"><i class="fa fa-angle-right" aria-hidden="true"></i></span></button>
            </div>
          </form>
        </div>
      </div>
      <div class="col-md-6">
        <h2>Contact Info</h2>
        <div class="contact_detail">
              <?php 
$pagetype=$_GET['type'];
$sql = "SELECT Address,EmailId,ContactNo from tblcontactusinfo";
$query = $dbh -> prepare($sql);
$query->bindParam(':pagetype',$pagetype,PDO::PARAM_STR);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $result)
{ ?>
          <ul>
            <li>
              <div class="icon_wrap"><i class="fa fa-map-marker" aria-hidden="true"></i></div>
              <div class="contact_info_m"><?php   echo htmlentities($result->Address); ?></div>
            </li>
            <li>
                           <div class="icon_wrap"><i class="fa fa-envelope-o" aria-hidden="true"></i></div>

              <div class="contact_info_m"><a ><?php   echo htmlentities($result->EmailId); ?></a></div>
            </li>
            <li>
			 <div class="icon_wrap"><i class="fa fa-phone" aria-hidden="true"></i></div>
              <div class="contact_info_m"><a ><?php   echo htmlentities($result->ContactNo); ?></a></div>
            </li>
          </ul>
        <?php }} ?>
        </div>
      </div>
    </div>
  </div>
</section>




								<!-- /tab -->
							</div>
						</div>
					</div>
					<!-- /Products tab & slick -->
				</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>
		<!-- /SECTION -->

		<!-- SECTION -->

		<!-- /SECTION -->
</div>
		