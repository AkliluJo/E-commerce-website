<?php

  include 'db.php';
if (isset($_SESSION["uid"])) {
		$uid=$_SESSION['uid'];
/* 	$sqli="SELECT * FROM orders WHERE user_id='$uid'";
	$run_query=mysqli_query($con,$sqli);
	$row=mysqli_fetch_array($run_query);
	$trid=$row['trx_id']; */
		// $sql="SELECT * FROM cart WHERE user_id='$uid'";
		$sql = "SELECT p_id,qty FROM cart WHERE user_id = '$uid'";
		$query = mysqli_query($con,$sql);
		 if (mysqli_num_rows($query) > 0) {
			# code...
			$ii=rand();
			
			while ($row=mysqli_fetch_array($query)) {
			$product_id[] = $row["p_id"];
			$qty[] = $row["qty"];
			
			
			for ($i=0; $i < count($product_id); $i++) { 
			 $gg = $product_id["$i"];
             $sqln = "SELECT * FROM products WHERE product_id = '$gg'";
			$run_quer = mysqli_query($con,$sqln);
			  $row = mysqli_fetch_array($run_quer);

			  $owner_email = $row["owner_email"]; 
			
/* 			$sql = "INSERT INTO orders (user_id,o_email,product_id,qty,trx_id,p_status) VALUES ('$cm_user_id','$owner_email','$gg','".$qty[$i]."','$trx_id','$p_st')";
				mysqli_query($con,$sql);
			 */
			$sql = "INSERT INTO orders (user_id,o_email,product_id,qty,trx_id,p_status) VALUES 
			('$uid','$owner_email','$gg','".$qty[$i]."','$ii','Completed')";
			mysqli_query($con,$sql);
			$status=1;
            $sqlu = "UPDATE products SET status = '$status'  WHERE  product_id='$gg'";
			mysqli_query($con,$sqlu);
			
			$content="Dear ".$_SESSION["name"]." your order action is succusfully processed!! your transaction id is ".$ii." Thanks for ordering!!";
			$sqly="INSERT INTO `notification` (`user_email`,`content`) VALUES
            ('$_SESSION[email]','$content')";
			mysqli_query($con,$sqly);
			
			}
			}
          
          $ii++;	

			$sql = "DELETE FROM cart WHERE user_id = '$uid'";
			if (mysqli_query($con,$sql)) {
				?>


<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>RASMS|Payment process</title>

<style type="text/css">
		.content{
			display: none;
	
		}
			
.main-raised {
    margin: 0px 0px 0px;
    border-radius: 2px;
    box-shadow: 0 16px 24px 2px rgba(0, 0, 0, 0.14), 0 6px 30px 5px rgba(0, 0, 0, 0.12), 0 8px 10px -5px rgba(0, 0, 0, 0.2);

}
.main {

    background: #fff;
    position: relative;
    z-index: 3;

}
</style>
</head>
<html>
<body>
   <div class="main main-raised">

		<!-- SECTION -->
		<div class="section">
			<!-- container -->
			<div class="container">
				<!-- row -->
				<div class="row">


                    <div class='content'>

	                  
						<div class="container-fluid">
						
							<div class="row">
								<div class="col-md-2"></div>
								<div class="col-md-8">
									<div class="panel panel-default">
										<div class="panel-heading"></div>
										<div class="panel-body">
										<font color="blue" SIZE = "+2"> <b>Thankyou!!</b></font>
											
											<hr/>
											<p>Hello <font color="blue" > <?php echo "<b>".$_SESSION["name"]."</b>"; ?></font>,Your payment process is 
											successfully completed and your Transaction id is <font color="red" SIZE = "+2"> <b><?php echo $ii-1; ?></b></font><br>
											you can continue your Shopping <br/></p>
			                    
											<a href="store.php" class="btn btn-success btn-lg">BackTo Shopping</a>
										</div>
										<div class="panel-footer"></div>
									</div>
								</div>
								<div class="col-md-2"></div>
							</div>
						</div>
                      </div>

					<!-- Products tab & slick -->
					<div class="col-md-12 mainn mainn-raised">
						<div class="row">
							<div class="products-tabs">
					
							</div>
						</div>
					</div>
					<!-- /Products tab & slick -->
				</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>

</div>
   <div class="main main-raised">

		<!-- SECTION -->
		<div class="section">
			<!-- container -->
			<div class="container">
				<!-- row -->
				<div class="row">

	           <div class="preload"><img src="includes/loading.gif" style="width:400px;
                  height: 400px;
                   position: relative;
                     top: 0px;
                  left: 50px;">

					<!-- Products tab & slick -->
					<div class="col-md-12 mainn mainn-raised">
						<div class="row">
							<div class="products-tabs">
								<!-- tab -->
	
	
								<!-- /tab -->
							</div>
							</div>
						</div>
					</div>
					<!-- /Products tab & slick -->
				</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>

</div>


	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
	<script type="text/javascript">
		
    	
    	$(".preload").fadeOut(1000, function(){
        $(".content").fadeIn(100);        	
		}); 

	</script>
</body>
</html>
				<?php
		}
		}   

    
}
else{
    echo"<script>window.location.href='index.php'</script>";
}
	
?>