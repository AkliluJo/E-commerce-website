<?php
include "header.php";
include "transactionprocess.php";
include "newslettter.php";
include "footer.php";
?>
		