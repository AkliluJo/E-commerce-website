    <div class="wait overlay">
        <div class="loader"></div>
    </div>
    <style>
    .input-borders{
        border-radius:30px;
    }
    </style>
				<!-- row -->
				
                <div class="container-fluid">
						
						<!-- /Billing Details -->
						
								<form id="signup" onsubmit="return false" class="login100-form">
<form method="post" class="form-horizontal" enctype="multipart/form-data">
									<div class="billing-details jumbotron">
                                    <div class="section-title">
                                        <h2 class="login100-form-title p-b-49" >Password Recovery</h2>
                                    </div>

                                    <div class="form-group">
                                        <input class="input form-control input-borders" type="email" name="email"  placeholder="Your Email">
                                    </div>
									<div class="form-group">
                                        <input class="input form-control input-borders" type="text" name="mobile" id="mobile" placeholder="Registered mobile">
										
                                    </div>
                                    <div class="form-group">
                                        <input class="input form-control input-borders" type="password" name="password" id="password" placeholder="New password">
                                    </div>
                                    <div class="form-group">
                                        <input class="input form-control input-borders" type="password" name="repassword" id="repassword" placeholder="confirm password">
                                    </div>

                                    
                                   
                                    
                                    
                                    <div style="form-group">
                                       <input class="primary-btn btn-block"  value="Sign Up" type="submit" name="signup_button">
                                    </div>

                                
								</form>
                                <div class="login-marg">
						<!-- Billing Details -->
						<div class="row">
                            <div class="col-md-2"></div>
                            <div class="col-md-8" id="signup_msg">
                                    

                                </div>
                                <!--Alert from signup form-->
                            </div>
                            <div class="col-md-2"></div>
                        </div>

						
					</div>
                    </div> 

					
				
				<!-- /row -->

			
