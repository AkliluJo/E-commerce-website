<?php
include "header.php";
include "ratingprocessaction.php";
include "newslettter.php";
include "footer.php";
?>
		