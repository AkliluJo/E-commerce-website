<?php

  include 'db.php';

if(isset($_SESSION["uid"])){
		
if (isset($_POST["book_buton"])) {
    
	$uid=$_SESSION['uid'];
	$hidden = $_POST['hidden'];

	$fdate = $_POST['fdate'];
	$udate = $_POST['udate'];
	
	$diff = abs(strtotime($udate) - strtotime($fdate));
	$years  = floor($diff / (365 * 60 * 60 * 24));
    $months = floor(($diff - $years * 365 * 60 * 60 * 24) / (30 * 60 * 60 * 24));
	$days   = floor(($diff - $years * 365 * 60 * 60 * 24 - $months * 30 * 60 * 60 *24) / (60 * 60 * 24));
    $total = $hidden * $days;
	$message = $_POST['message'];

	if($fdate > $udate) {
		echo "
			<div class='alert alert-warning'>
				<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
				<b>Drop date is longer than pick up date!!</b>
			</div>
		";
		exit();
	}

else
{


       $ii=rand();
			$sql = "INSERT INTO reserves (user_id,o_email,product_id,duration,total,FromDate,ToDate,message,trx_id,p_status) VALUES 
			('$uid','$_SESSION[o_email]','$_SESSION[product_id]','$days','$total','$fdate','$udate','$message','$ii','Completed')";
			
			$status=1;
            $sqlu = "UPDATE products SET status = '$status'  WHERE  product_id='$_SESSION[product_id]'";
			mysqli_query($con,$sqlu);
			
			$content="Dear ".$_SESSION["name"]." your request is succusfully processed!! your transaction id is ".$ii."  and the item need te be returned on ".$udate." thanks for reserving!!";
			$sqly="INSERT INTO `notification` (`user_email`,`content`) VALUES
            ('$_SESSION[email]','$content')";
			mysqli_query($con,$sqly);

          $ii++;	
}
}
			if (mysqli_query($con,$sql)) {
				?>


<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>RASMS|Payment process</title>

<style type="text/css">
		.content{
			display: none;
	
		}
			
.main-raised {
    margin: 0px 0px 0px;
    border-radius: 2px;
    box-shadow: 0 16px 24px 2px rgba(0, 0, 0, 0.14), 0 6px 30px 5px rgba(0, 0, 0, 0.12), 0 8px 10px -5px rgba(0, 0, 0, 0.2);

}
.main {

    background: #fff;
    position: relative;
    z-index: 3;

}
</style>
</head>
<html>
<body>
   <div class="main main-raised">

		<!-- SECTION -->
		<div class="section">
			<!-- container -->
			<div class="container">
				<!-- row -->
				<div class="row">


                    <div class='content'>

	                  
						<div class="container-fluid">
						
							<div class="row">
								<div class="col-md-2"></div>
								<div class="col-md-8">
									<div class="panel panel-default">
										<div class="panel-heading"></div>
										<div class="panel-body">
										<font color="blue" SIZE = "+2"> <b>Thankyou!!</b></font>
											
											<hr/>
											<p>Hello <font color="blue" > <?php echo "<b>".$_SESSION["name"]."</b>"; ?></font>,Your Reserve process is 
											successfully completed and your Transaction id is <font color="red" SIZE = "+2"> <b><?php echo $ii-1; ?></b></font><br>
											you can Back to Reserve <br/></p>
			                    
											<a href="store.php" class="btn btn-success btn-lg">GoTo Back</a>
										</div>
										<div class="panel-footer"></div>
									</div>
								</div>
								<div class="col-md-2"></div>
							</div>
						</div>
                      </div>

					<!-- Products tab & slick -->
					<div class="col-md-12 mainn mainn-raised">
						<div class="row">
							<div class="products-tabs">
					
							</div>
						</div>
					</div>
					<!-- /Products tab & slick -->
				</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>

</div>
   <div class="main main-raised">

		<!-- SECTION -->
		<div class="section">
			<!-- container -->
			<div class="container">
				<!-- row -->
				<div class="row">

	           <div class="preload"><img src="includes/loading.gif" style="width:400px;
                  height: 400px;
                   position: relative;
                     top: 0px;
                  left: 50px;">

					<!-- Products tab & slick -->
					<div class="col-md-12 mainn mainn-raised">
						<div class="row">
							<div class="products-tabs">
								<!-- tab -->
	
	
								<!-- /tab -->
							</div>
							</div>
						</div>
					</div>
					<!-- /Products tab & slick -->
				</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>

</div>


	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
	<script type="text/javascript">
		
    	
    	$(".preload").fadeOut(5000, function(){
        $(".content").fadeIn(500);        	
		}); 

	</script>
</body>
</html>
				<?php
		}
		   

    
}
else{
    echo"<script>window.location.href='index.php'</script>";
}
	
?>