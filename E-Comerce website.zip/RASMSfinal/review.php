<?php
 include 'db.php';
 session_start();
if (isset($_POST["signup_button"])) {
	
	/* $product_id = $_GET['p']; */
	$rname = $_POST["rname"];
	$email = $_POST["email"];
	$rmassage = $_POST['rmassage'];
    $rating = $_POST['rating'];
	
	$name = "/^[a-zA-Z ]+$/";
	$emailValidation = "/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9]+(\.[a-z]{2,4})$/";
	$number = "/^[0-9]+$/";

if(empty($rname) || empty($email) || empty($rmassage) || empty($rating)){
		
		echo "
			<div class='alert alert-warning'>
				<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a><b>PLease Fill the fields..!</b>
			</div>
		";
		exit();
	} else {
		if(!preg_match($name,$rname)){
		echo "
			<div class='alert alert-warning'>
				<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
				<b>this $rname is not valid..!</b>
			</div>
		";
		exit();
	}
        $sql = "SELECT rating_id FROM rating WHERE email_id = '$email' LIMIT 1" ;
        $check_query = mysqli_query($con,$sql);
        $count_email = mysqli_num_rows($check_query);
        if($count_email > 0){
            echo "
                <div class='alert alert-danger'>
                    <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
                    <b>Email Address is already available</b>
                </div>
            ";
            exit();
        }
	if(!preg_match($emailValidation,$email)){
		echo "
			<div class='alert alert-warning'>
				<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
				<b>this $email is not valid..!</b>
			</div>
		";
		exit();
	}
else{
            
            $sql = "INSERT INTO `rating` 
            ( `name`, `email_id`, `rate`, `review`)
            VALUES ( '$rname', '$email', '$rating', '$rmassage')";
            $run_query = mysqli_query($con,$sql);
                echo "<div class='alert alert-success'>
                    <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
                    <b>Thanks for ratting</b>
                </div>";
                
                
            }
		
	
	}
	
}



?>






















































