-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 20, 2021 at 02:55 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rsms`
--

-- --------------------------------------------------------

--
-- Table structure for table `activity_logs`
--

CREATE TABLE `activity_logs` (
  `id` int(11) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `action` varchar(500) NOT NULL,
  `status` int(11) NOT NULL COMMENT '0 = pending, 1 = seen',
  `a_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `activity_logs`
--

INSERT INTO `activity_logs` (`id`, `first_name`, `email`, `action`, `status`, `a_date`) VALUES
(1, 'yekoye', 'ye@gmail.com', 'Add best house products ', 0, '2021-01-18 12:19:00'),
(2, 'yekoye', 'ye@gmail.com', 'Add best house products ', 0, '2021-01-18 12:22:48'),
(3, 'yekoye', 'ye@gmail.com', 'Add best house products ', 0, '2021-01-18 12:24:58'),
(4, 'yekoye', 'ye@gmail.com', 'Add best laptop computer ', 0, '2021-01-18 12:26:35'),
(5, 'yekoye', 'ye@gmail.com', 'Add fegegta vehicle ', 0, '2021-01-18 12:28:02'),
(6, 'yekoye', 'ye@gmail.com', 'Add funga vehicle ', 0, '2021-01-18 12:29:23'),
(7, 'yekoye', 'ye@gmail.com', 'Add laptop vehicle ', 0, '2021-01-18 12:31:08'),
(8, 'yekoye', 'ye@gmail.com', 'Add best house products ', 0, '2021-01-18 15:25:42'),
(9, 'Natnael', 'nat@gmail.com', 'Add my computer computer ', 0, '2021-01-18 18:14:14'),
(10, 'Natnael', 'nat@gmail.com', 'Add my car vehicle ', 0, '2021-01-18 18:29:52'),
(11, 'Natnael', 'nat@gmail.com', 'Add MY CAR eVR vehicle ', 0, '2021-01-18 18:38:19'),
(12, 'Natnael', 'nat@gmail.com', 'Add best house computer ', 0, '2021-01-18 18:53:39'),
(13, 'Natnael', 'nat@gmail.com', 'Add dudu computer ', 0, '2021-01-18 19:37:00'),
(14, 'Natnael', 'nat@gmail.com', 'Add dudu products ', 0, '2021-01-18 19:41:02'),
(15, 'Natnael', 'nat@gmail.com', 'Add best laptop products ', 0, '2021-01-18 19:41:56'),
(16, 'Natnael', 'nat@gmail.com', 'Add best house products ', 0, '2021-01-18 21:04:12'),
(17, 'Natnael', 'nat@gmail.com', 'Add best house products ', 0, '2021-01-18 22:24:54'),
(18, 'Natnael', 'nat@gmail.com', 'Add best house products ', 0, '2021-01-20 12:22:48');

-- --------------------------------------------------------

--
-- Table structure for table `admin_info`
--

CREATE TABLE `admin_info` (
  `admin_id` int(10) NOT NULL,
  `admin_name` varchar(100) NOT NULL,
  `admin_email` varchar(300) NOT NULL,
  `admin_password` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_info`
--

INSERT INTO `admin_info` (`admin_id`, `admin_name`, `admin_email`, `admin_password`) VALUES
(1, 'Admin', 'admin@gmail.com', '123456qwe');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(10) NOT NULL,
  `p_id` int(10) NOT NULL,
  `ip_add` varchar(250) NOT NULL,
  `user_id` int(10) DEFAULT NULL,
  `qty` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `p_id`, `ip_add`, `user_id`, `qty`) VALUES
(6, 8, '::1', 28, 1);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `cat_id` int(100) NOT NULL,
  `cat_title` text NOT NULL,
  `cat_for` text NOT NULL,
  `CreationDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`cat_id`, `cat_title`, `cat_for`, `CreationDate`, `UpdationDate`) VALUES
(1, 'Electronics', 'sale', '2020-02-18 16:24:34', '2020-02-19 06:42:23'),
(2, 'vehicle', 'rent', '2020-01-18 16:24:34', '2020-01-19 06:42:23'),
(3, 'Fashine & Beuty', 'both', '2020-02-19 16:24:34', '2020-02-20 06:42:23'),
(4, 'Property for rent & sale', 'both', '2020-06-19 06:22:13', NULL),
(5, 'Furnitures & home equipments', 'sale', '2020-02-18 16:24:34', '2020-02-19 06:44:23');

-- --------------------------------------------------------

--
-- Table structure for table `customerbank`
--

CREATE TABLE `customerbank` (
  `cus_id` int(10) NOT NULL,
  `email` varchar(300) NOT NULL,
  `password` varchar(300) NOT NULL,
  `cus_fname` varchar(100) NOT NULL,
  `cus_lname` varchar(100) NOT NULL,
  `account_name` varchar(100) NOT NULL,
  `account_type` varchar(100) NOT NULL,
  `account_number` int(13) NOT NULL,
  `balance` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customerbank`
--

INSERT INTO `customerbank` (`cus_id`, `email`, `password`, `cus_fname`, `cus_lname`, `account_name`, `account_type`, `account_number`, `balance`) VALUES
(1, 'sura@gmail.com', '123456qwe', 'Getacher', 'Desta', '', '', 0, 1000);

-- --------------------------------------------------------

--
-- Table structure for table `email_info`
--

CREATE TABLE `email_info` (
  `email_id` int(100) NOT NULL,
  `email` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `location`
--

CREATE TABLE `location` (
  `location_id` int(100) NOT NULL,
  `location_title` text NOT NULL,
  `location_for` text NOT NULL,
  `CreationDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `location`
--

INSERT INTO `location` (`location_id`, `location_title`, `location_for`, `CreationDate`, `UpdationDate`) VALUES
(1, 'dilla town', 'sale', '2020-06-18 16:24:34', '2020-06-19 06:42:23'),
(2, 'Aleta wondo', 'sale', '2020-06-18 16:25:50', NULL),
(3, 'Wondogenet', 'rent', '2020-06-18 16:25:03', NULL),
(4, 'Chiko', 'rent', '2020-06-18 16:26:13', NULL),
(5, 'Yirgalem', 'sale', '2020-06-18 16:25:24', NULL),
(6, 'Chefe', 'both', '2020-06-19 06:22:13', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

CREATE TABLE `message` (
  `message_id` int(10) NOT NULL,
  `reciever_email` varchar(300) NOT NULL,
  `content` varchar(200) NOT NULL,
  `date_sended` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `sender_email` varchar(300) NOT NULL,
  `reciever_name` varchar(50) NOT NULL,
  `sender_name` varchar(200) NOT NULL,
  `message_status` int(11) NOT NULL COMMENT '0 = pending, 1 = seen'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `message_sent`
--

CREATE TABLE `message_sent` (
  `message_sent_id` int(10) NOT NULL,
  `reciever_email` varchar(300) NOT NULL,
  `content` varchar(200) NOT NULL,
  `date_sended` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `sender_email` varchar(300) NOT NULL,
  `reciever_name` varchar(100) NOT NULL,
  `sender_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `notification`
--

CREATE TABLE `notification` (
  `notification_id` int(10) NOT NULL,
  `user_email` varchar(300) NOT NULL,
  `user_fname` varchar(50) NOT NULL,
  `user_lname` varchar(50) NOT NULL,
  `content` varchar(2000) NOT NULL,
  `date_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `notification_status` int(11) NOT NULL COMMENT '0 = pending, 1 = seen'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notification`
--

INSERT INTO `notification` (`notification_id`, `user_email`, `user_fname`, `user_lname`, `content`, `date_added`, `notification_status`) VALUES
(1, 'nat@gmail.com', '', '', 'online rental and sale system would like to add products to the system this\r\nmay produce fee!!', '2021-01-18 21:45:31', 0),
(2, 'nat@gmail.com', '', '', 'online rental and sale system would like to add products to the system this\r\nmay produce fee!!', '2021-01-18 21:48:17', 1),
(3, 'nat@gmail.com', '', '', 'Dear Natnael your request is succusfully processed!! your transaction id is 1450200048 the item need te be returned on 2021-01-03', '2021-01-18 22:04:59', 0),
(4, 'ye@gmail.com', '', '', 'Dear yekoye your request is succusfully processed!! your transaction id is 1821303533  and the item need te be returned on 2021-01-09 thanks for reserving!!', '2021-01-18 22:12:11', 0),
(5, 'nat@gmail.com', '', '', 'Dear Natnael your order action is succusfully processed!! your transaction id is 1727969636 Thanks for ordering!!', '2021-01-18 22:14:31', 0),
(6, 'nat@gmail.com', '', '', 'online rental and sale system would like to add products to the system this\r\nmay produce fee!!', '2021-01-18 22:20:21', 0),
(7, 'nat@gmail.com', '', '', 'Dear Natnael your request is succusfully processed!! your transaction id is 1533170712  and the item need te be returned on 2021-01-18 thanks for reserving!!', '2021-01-18 22:28:23', 0);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `o_email` varchar(50) NOT NULL,
  `product_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `trx_id` varchar(255) NOT NULL,
  `OnDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL COMMENT '0 = pending, 1 = Sold',
  `p_status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `user_id`, `o_email`, `product_id`, `qty`, `trx_id`, `OnDate`, `status`, `p_status`) VALUES
(2, 28, 'ye@gmail.com', 11, 1, '1166411199', '2021-01-18 12:48:08', 1, 'Completed'),
(3, 28, 'ye@gmail.com', 12, 1, '44520793', '2021-01-18 13:06:56', 0, 'Completed'),
(4, 27, 'nat@gmail.com', 20, 1, '1522154724', '2021-01-18 20:57:33', 1, 'Completed'),
(5, 27, 'nat@gmail.com', 22, 1, '414740945', '2021-01-18 21:36:09', 1, 'Completed'),
(6, 27, 'ye@gmail.com', 8, 1, '1727969636', '2021-01-18 22:14:31', 0, 'Completed');

-- --------------------------------------------------------

--
-- Table structure for table `orders_info`
--

CREATE TABLE `orders_info` (
  `order_id` int(10) NOT NULL,
  `user_id` int(11) NOT NULL,
  `f_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `zip` int(10) NOT NULL,
  `cardname` varchar(255) NOT NULL,
  `cardnumber` varchar(20) NOT NULL,
  `expdate` varchar(255) NOT NULL,
  `prod_count` int(15) DEFAULT NULL,
  `total_amt` int(15) DEFAULT NULL,
  `cvv` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders_info`
--

INSERT INTO `orders_info` (`order_id`, `user_id`, `f_name`, `email`, `address`, `city`, `state`, `zip`, `cardname`, `cardnumber`, `expdate`, `prod_count`, `total_amt`, `cvv`) VALUES
(1, 28, 'yekoye kefale', 'ye@gmail.com', 'dilla', 'addis', 'fgfhgfhgf', 345677, 'natanium', '4545454545454', '123456qwe', 1, 15000, 0),
(2, 28, 'yekoye kefale', 'ye@gmail.com', 'dilla', 'addis', 'fgfhgfhgf', 345677, 'natanium', '2355555555555', '1234', 1, 15000, 0),
(3, 27, 'Natnael Teklu', 'nat@gmail.com', 'dilla', 'dilla u', 'fgfhgfhgf', 345677, 'natanium', '3333333333333', '1234325456456', 1, 210000, 0),
(4, 27, 'Natnael Teklu', 'nat@gmail.com', 'dilla', 'dilla u', 'fgfhgfhgf', 345677, 'natanium', '4555555555555', '123456qwe', 1, 300000, 0),
(5, 27, 'Natnael Teklu', 'nat@gmail.com', 'dilla', 'dilla u', 'fgfhgfhgf', 345677, 'natanium', '5555555555555', '123456qwe', 1, 15000, 0);

-- --------------------------------------------------------

--
-- Table structure for table `order_products`
--

CREATE TABLE `order_products` (
  `order_pro_id` int(10) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `qty` int(15) DEFAULT NULL,
  `amt` int(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_products`
--

INSERT INTO `order_products` (`order_pro_id`, `order_id`, `product_id`, `qty`, `amt`) VALUES
(1, 3, 20, 1, 210000);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `owner_email` varchar(255) NOT NULL,
  `product_id` int(100) NOT NULL,
  `product_cat` int(100) NOT NULL,
  `product_location` int(110) DEFAULT NULL,
  `product_title` varchar(255) NOT NULL,
  `product_price` varchar(100) NOT NULL,
  `product_desc` text NOT NULL,
  `testimonals` longtext,
  `product_image` text NOT NULL,
  `product_image1` text NOT NULL,
  `product_image2` text NOT NULL,
  `product_image3` text NOT NULL,
  `item_for` int(11) NOT NULL,
  `brand` varchar(30) NOT NULL,
  `condition` varchar(30) NOT NULL,
  `ram` int(11) DEFAULT NULL,
  `processor` varchar(11) DEFAULT NULL,
  `hard_derive` int(11) DEFAULT NULL,
  `pc_type` varchar(30) DEFAULT NULL,
  `electricfence` int(11) DEFAULT NULL,
  `kichhen` int(11) DEFAULT NULL,
  `parkingbay` int(11) DEFAULT NULL,
  `swimmingpool` int(11) DEFAULT NULL,
  `waterincluded` int(11) DEFAULT NULL,
  `PricePerDay` int(11) DEFAULT NULL,
  `FuelType` varchar(100) DEFAULT NULL,
  `ModelYear` int(6) DEFAULT NULL,
  `SeatingCapacity` int(11) DEFAULT NULL,
  `AirConditioner` int(11) DEFAULT NULL,
  `PowerDoorLocks` int(11) DEFAULT NULL,
  `AntiLockBrakingSystem` int(11) DEFAULT NULL,
  `BrakeAssist` int(11) DEFAULT NULL,
  `PowerSteering` int(11) DEFAULT NULL,
  `DriverAirbag` int(11) DEFAULT NULL,
  `PassengerAirbag` int(11) DEFAULT NULL,
  `PowerWindows` int(11) DEFAULT NULL,
  `CDPlayer` int(11) DEFAULT NULL,
  `CentralLocking` int(11) DEFAULT NULL,
  `CrashSensor` int(11) DEFAULT NULL,
  `LeatherSeats` int(11) DEFAULT NULL,
  `RegDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL COMMENT '0 = pending, 1 = sold/rented',
  `product_keywords` varchar(70) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`owner_email`, `product_id`, `product_cat`, `product_location`, `product_title`, `product_price`, `product_desc`, `testimonals`, `product_image`, `product_image1`, `product_image2`, `product_image3`, `item_for`, `brand`, `condition`, `ram`, `processor`, `hard_derive`, `pc_type`, `electricfence`, `kichhen`, `parkingbay`, `swimmingpool`, `waterincluded`, `PricePerDay`, `FuelType`, `ModelYear`, `SeatingCapacity`, `AirConditioner`, `PowerDoorLocks`, `AntiLockBrakingSystem`, `BrakeAssist`, `PowerSteering`, `DriverAirbag`, `PassengerAirbag`, `PowerWindows`, `CDPlayer`, `CentralLocking`, `CrashSensor`, `LeatherSeats`, `RegDate`, `UpdationDate`, `status`, `product_keywords`) VALUES
('ye@gmail.com', 8, 4, 2, 'best house', '15000', 'asghavmgdsyjhdsgtuij', NULL, 'featured-img-1.jpg', 'house2.png', 'house3.png', 'car4.jpg', 3, 'no brand', 'Refurbished', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-18 12:19:00', '2021-01-18 22:14:31', 1, 'none'),
('nat@gmail.com', 20, 1, 3, 'dudu', '210000', 'B gtfsdvhjs', NULL, 'laptop_PNG5930.png', 'laptop_PNG5930.png', 'laptop_PNG5930.png', 'laptop_PNG5930.png', 4, 'LENEVO', 'Used', 8, '4.0', 700, 'studio', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-18 19:37:00', '2021-01-18 20:57:33', 1, 'camera'),
('nat@gmail.com', 25, 4, 5, 'best house', '210000', 'best house', 'asghhjtgfasdhhjdgyu', 'house4.png', 'Cool Pictures (2)000.jpg', 'bed4.png', 'looking-used-car.png', 2, 'no brand', 'Refurbished', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 45, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-20 12:22:48', NULL, 0, 'be find');

-- --------------------------------------------------------

--
-- Table structure for table `rating`
--

CREATE TABLE `rating` (
  `rating_id` int(100) NOT NULL,
  `product_id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email_id` varchar(100) NOT NULL,
  `RDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `rate` int(5) NOT NULL,
  `review` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rating`
--

INSERT INTO `rating` (`rating_id`, `product_id`, `name`, `email_id`, `RDate`, `rate`, `review`) VALUES
(2, 24, 'natanium', 'sura@gmail.com', '2021-01-20 12:05:32', 4, 'hjgf');

-- --------------------------------------------------------

--
-- Table structure for table `reserves`
--

CREATE TABLE `reserves` (
  `reserve_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `o_email` varchar(50) NOT NULL,
  `product_id` int(11) NOT NULL,
  `duration` varchar(110) NOT NULL,
  `total` varchar(110) NOT NULL,
  `FromDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ToDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `message` varchar(255) DEFAULT NULL,
  `trx_id` varchar(255) NOT NULL,
  `OnDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL COMMENT '0 = pending, 1 = Processed',
  `checkin` int(11) DEFAULT '1' COMMENT '0 = released, 1 =returned',
  `p_status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reserves`
--

INSERT INTO `reserves` (`reserve_id`, `user_id`, `o_email`, `product_id`, `duration`, `total`, `FromDate`, `ToDate`, `message`, `trx_id`, `OnDate`, `status`, `checkin`, `p_status`) VALUES
(1, 27, 'nat@gmail.com', 21, '2', '113092', '2021-01-06 08:00:00', '2021-01-08 08:00:00', 'i have no message', '644594660', '2021-01-18 20:39:09', 1, 1, 'Completed'),
(2, 27, 'nat@gmail.com', 23, '10', '100', '2021-01-07 08:00:00', '2021-01-17 08:00:00', 'fhbszghgf', '525940041', '2021-01-18 21:06:57', 1, 1, 'Completed'),
(3, 27, 'nat@gmail.com', 23, '1', '10', '2021-01-02 08:00:00', '2021-01-03 08:00:00', 'ddhzgf', '1450200048', '2021-01-18 22:04:59', 1, 1, 'Completed'),
(4, 28, 'nat@gmail.com', 23, '2', '20', '2021-01-07 08:00:00', '2021-01-09 08:00:00', 'gfbxcbvf', '1821303533', '2021-01-18 22:12:11', 0, 1, 'Completed'),
(5, 27, 'nat@gmail.com', 24, '10', '1000', '2021-01-08 08:00:00', '2021-01-18 08:00:00', 'natnael', '1533170712', '2021-01-18 22:28:24', 1, 1, 'Completed');

-- --------------------------------------------------------

--
-- Table structure for table `subcat`
--

CREATE TABLE `subcat` (
  `sub_id` int(100) NOT NULL,
  `sub_title` text NOT NULL,
  `subfor` text NOT NULL,
  `CreationDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `systembank`
--

CREATE TABLE `systembank` (
  `sys_id` int(10) NOT NULL,
  `account_name` varchar(100) NOT NULL,
  `account_type` varchar(100) NOT NULL,
  `account_number` int(13) NOT NULL,
  `balance` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `systembank`
--

INSERT INTO `systembank` (`sys_id`, `account_name`, `account_type`, `account_number`, `balance`) VALUES
(1, 'rasms', 'CBE', 2147483647, 600);

-- --------------------------------------------------------

--
-- Table structure for table `tblcontactusinfo`
--

CREATE TABLE `tblcontactusinfo` (
  `id` int(11) NOT NULL,
  `Address` tinytext,
  `EmailId` varchar(255) DEFAULT NULL,
  `ContactNo` char(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tblcontactusquery`
--

CREATE TABLE `tblcontactusquery` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `EmailId` varchar(120) DEFAULT NULL,
  `ContactNumber` char(11) DEFAULT NULL,
  `Message` longtext,
  `PostingDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tblpages`
--

CREATE TABLE `tblpages` (
  `id` int(11) NOT NULL,
  `PageName` varchar(255) DEFAULT NULL,
  `type` varchar(255) NOT NULL DEFAULT '',
  `detail` longtext NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tblsubscribers`
--

CREATE TABLE `tblsubscribers` (
  `id` int(11) NOT NULL,
  `SubscriberEmail` varchar(120) DEFAULT NULL,
  `PostingDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user_info`
--

CREATE TABLE `user_info` (
  `user_id` int(10) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` varchar(300) NOT NULL,
  `password` varchar(300) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `address1` varchar(300) NOT NULL,
  `address2` varchar(11) NOT NULL,
  `road` varchar(11) DEFAULT NULL,
  `delivery_offered` varchar(11) DEFAULT NULL,
  `seller_type` varchar(11) DEFAULT NULL,
  `user_image` varchar(120) DEFAULT NULL,
  `status` int(11) DEFAULT '1' COMMENT '0 = blocked, 1 = currently users'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_info`
--

INSERT INTO `user_info` (`user_id`, `first_name`, `last_name`, `email`, `password`, `mobile`, `address1`, `address2`, `road`, `delivery_offered`, `seller_type`, `user_image`, `status`) VALUES
(27, 'Natnael', 'Teklu', 'nat@gmail.com', '123456qwe', '0922420124', 'dilla', 'dilla u', 'mombassa', 'no', 'bussines ma', 'product07.png', 1),
(28, 'yekoye', 'kefale', 'ye@gmail.com', '123456qwe', '0987654398', 'dilla', 'addis', 'hawassa', 'yes', 'private', 'pt7.jpg', 1),
(29, 'Getacher', 'Desta', 'sura@gmail.com', '123456qwe', '0987654323', 'dilla', 'adisu gebey', NULL, NULL, NULL, NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `user_logs`
--

CREATE TABLE `user_logs` (
  `id` int(11) NOT NULL,
  `user_id` varchar(50) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `date` varchar(100) NOT NULL,
  `action` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_logs`
--

INSERT INTO `user_logs` (`id`, `user_id`, `first_name`, `email`, `date`, `action`) VALUES
(1, '27', 'Natnael', 'nat@gmail.com', '2021-01-18 10:12:22', 'login'),
(2, '27', 'Natnael', 'nat@gmail.com', '2021-01-18 14:11:13', 'login'),
(3, '28', 'yekoye', 'ye@gmail.com', '2021-01-18 14:11:50', 'login'),
(4, '27', 'Natnael', 'nat@gmail.com', '2021-01-18 14:14:08', 'login'),
(5, '27', 'Natnael', 'nat@gmail.com', '2021-01-20 04:03:52', 'login'),
(6, '27', 'Natnael', 'nat@gmail.com', '2021-01-20 04:20:03', 'login');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activity_logs`
--
ALTER TABLE `activity_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin_info`
--
ALTER TABLE `admin_info`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `customerbank`
--
ALTER TABLE `customerbank`
  ADD PRIMARY KEY (`cus_id`);

--
-- Indexes for table `email_info`
--
ALTER TABLE `email_info`
  ADD PRIMARY KEY (`email_id`);

--
-- Indexes for table `location`
--
ALTER TABLE `location`
  ADD PRIMARY KEY (`location_id`);

--
-- Indexes for table `message`
--
ALTER TABLE `message`
  ADD PRIMARY KEY (`message_id`);

--
-- Indexes for table `message_sent`
--
ALTER TABLE `message_sent`
  ADD PRIMARY KEY (`message_sent_id`);

--
-- Indexes for table `notification`
--
ALTER TABLE `notification`
  ADD PRIMARY KEY (`notification_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `orders_info`
--
ALTER TABLE `orders_info`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `order_products`
--
ALTER TABLE `order_products`
  ADD PRIMARY KEY (`order_pro_id`),
  ADD KEY `order_products` (`order_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `rating`
--
ALTER TABLE `rating`
  ADD PRIMARY KEY (`rating_id`);

--
-- Indexes for table `reserves`
--
ALTER TABLE `reserves`
  ADD PRIMARY KEY (`reserve_id`);

--
-- Indexes for table `subcat`
--
ALTER TABLE `subcat`
  ADD PRIMARY KEY (`sub_id`);

--
-- Indexes for table `systembank`
--
ALTER TABLE `systembank`
  ADD PRIMARY KEY (`sys_id`);

--
-- Indexes for table `tblcontactusinfo`
--
ALTER TABLE `tblcontactusinfo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblcontactusquery`
--
ALTER TABLE `tblcontactusquery`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblpages`
--
ALTER TABLE `tblpages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblsubscribers`
--
ALTER TABLE `tblsubscribers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_info`
--
ALTER TABLE `user_info`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `user_logs`
--
ALTER TABLE `user_logs`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activity_logs`
--
ALTER TABLE `activity_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `admin_info`
--
ALTER TABLE `admin_info`
  MODIFY `admin_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `cat_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `customerbank`
--
ALTER TABLE `customerbank`
  MODIFY `cus_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `email_info`
--
ALTER TABLE `email_info`
  MODIFY `email_id` int(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `location`
--
ALTER TABLE `location`
  MODIFY `location_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `message`
--
ALTER TABLE `message`
  MODIFY `message_id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `message_sent`
--
ALTER TABLE `message_sent`
  MODIFY `message_sent_id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `notification`
--
ALTER TABLE `notification`
  MODIFY `notification_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `orders_info`
--
ALTER TABLE `orders_info`
  MODIFY `order_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `order_products`
--
ALTER TABLE `order_products`
  MODIFY `order_pro_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `rating`
--
ALTER TABLE `rating`
  MODIFY `rating_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `reserves`
--
ALTER TABLE `reserves`
  MODIFY `reserve_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `subcat`
--
ALTER TABLE `subcat`
  MODIFY `sub_id` int(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `systembank`
--
ALTER TABLE `systembank`
  MODIFY `sys_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tblcontactusinfo`
--
ALTER TABLE `tblcontactusinfo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblcontactusquery`
--
ALTER TABLE `tblcontactusquery`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblpages`
--
ALTER TABLE `tblpages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `tblsubscribers`
--
ALTER TABLE `tblsubscribers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_info`
--
ALTER TABLE `user_info`
  MODIFY `user_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `user_logs`
--
ALTER TABLE `user_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `orders_info`
--
ALTER TABLE `orders_info`
  ADD CONSTRAINT `user_id` FOREIGN KEY (`user_id`) REFERENCES `user_info` (`user_id`);

--
-- Constraints for table `order_products`
--
ALTER TABLE `order_products`
  ADD CONSTRAINT `order_products` FOREIGN KEY (`order_id`) REFERENCES `orders_info` (`order_id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `product_id` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
