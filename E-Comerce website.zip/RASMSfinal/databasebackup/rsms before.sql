
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";
--
-- Database: `rsms`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_info`
--

CREATE TABLE `admin_info` (
  `admin_id` int(10) NOT NULL,
  `admin_name` varchar(100) NOT NULL,
  `admin_email` varchar(300) NOT NULL,
  `admin_password` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_info`
--

INSERT INTO `admin_info` (`admin_id`, `admin_name`, `admin_email`, `admin_password`) VALUES
(1, 'yekoye', 'admin@gmail.com', '123456qwe'),
(2, 'natnael', 'natan@gmail.com', '123456qwe');

-- --------------------------------------------------------
--
-- Table structure for table `admin_info`
--

CREATE TABLE `review` (
  `review_id` int(10) NOT NULL,
  `cus_name` varchar(100) NOT NULL,
  `cus_email` varchar(300) NOT NULL,
  `overview` varchar(300) NOT NULL,
  `review_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_info`
--

INSERT INTO `review` (`review_id`, `cus_name`, `cus_email`, `overview`, `review_date`) VALUES
(1, 'yekoye', 'admin@gmail.com', 'i seames good','2020-06-19 06:42:23'),
(2, 'natnael', 'natan@gmail.com', 'i like it well','2020-06-19 06:42:23');

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `brand_id` int(100) NOT NULL,
  `brand_title` text NOT NULL,
  `brand_for` text NOT NULL,
  `CreationDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`brand_id`, `brand_title`,`brand_for`, `CreationDate`, `UpdationDate`) VALUES
(1, 'HP','sale', '2020-06-18 16:24:34', '2020-06-19 06:42:23'),
(2, 'Samsung','sale', '2020-06-18 16:25:50', NULL),
(3, 'Toyota', 'rent','2020-06-18 16:25:03', NULL),
(4, 'Nissan','rent', '2020-06-18 16:26:13', NULL),
(5, 'LG','sale', '2020-06-18 16:25:24', NULL),
(6, 'Cloth Brand','both', '2020-06-19 06:22:13', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(10) NOT NULL,
  `p_id` int(10) NOT NULL,
  `ip_add` varchar(250) NOT NULL,
  `user_id` int(10) DEFAULT NULL,
  `qty` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `p_id`, `ip_add`, `user_id`, `qty`) VALUES
(6, 26, '1', 4, 1),
(9, 10, '::1', 7, 1),
(10, 11, '::1', 7, 1),
(11, 45, '::1', 7, 1),
(44, 5, '::1', 3, 0),
(46, 2, '::1', 3, 0),
(48, 72, '::1', 3, 0),
(71, 61, '127.0.0.1', -1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `cat_id` int(100) NOT NULL,
  `cat_title` text NOT NULL,
  `cat_for` text NOT NULL,
  `CreationDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`cat_id`, `cat_title`,`cat_for`, `CreationDate`, `UpdationDate`) VALUES
(1, 'Electronics','sale', '2020-02-18 16:24:34', '2020-02-19 06:42:23'),
(2, 'vehicle','rent', '2020-01-18 16:24:34', '2020-01-19 06:42:23'),
(3, 'Fashine & Beuty','both', '2020-02-19 16:24:34', '2020-02-20 06:42:23'),
(4, 'Property for rent & sale', 'both','2020-06-19 06:22:13', NULL),
(5, 'Furnitures & home equipments','sale', '2020-02-18 16:24:34', '2020-02-19 06:44:23');

-- --------------------------------------------------------
--
-- Table structure for table `subcat`
--

CREATE TABLE `subcat` (
  `sub_id` int(100) NOT NULL,
  `sub_title` text NOT NULL,
  `subfor` text NOT NULL,
  `CreationDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subcat`
--

INSERT INTO `subcat` (`sub_id`, `sub_title`,`subfor`, `CreationDate`, `UpdationDate`) VALUES
(1, 'laptop', 'sale','2020-06-18 16:24:34', '2020-06-19 06:42:23');

-- --------------------------------------------------------

--
-- Table structure for table `email_info`
--

CREATE TABLE `email_info` (
  `email_id` int(100) NOT NULL,
  `email` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `email_info`
--

INSERT INTO `email_info` (`email_id`, `email`) VALUES
(3, 'admin@gmail.com'),
(4, 'puneethreddy951@gmail.com'),
(5, 'puneethreddy@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE `logs` (
  `id` int(11) NOT NULL,
  `user_id` varchar(50) NOT NULL,
  `date` varchar(100) NOT NULL,
  `action` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `FromDate` varchar(20) DEFAULT NULL,
  `ToDate` varchar(20) DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `trx_id` varchar(255) NOT NULL,
  `p_status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `user_id`, `product_id`, `qty`,`FromDate`,`ToDate`,`message`, `trx_id`, `p_status`) VALUES
(1, 12, 7, 1,'22/06/2020', '25/06/2020', 'no massage add', '07M47684BS5725041', 'Completed'),
(2, 14, 2, 1, '22/06/2017', '25/06/2020', 'no massage add','07M47684BS5725041', 'Completed'),
(3, 27, 72, 1, '22/06/2017', '25/06/2020', 'no massage add','29590', 'Completed'),
(4, 27, 72, 1, '22/06/2017', '25/06/2020', 'no massage add','29590', 'Completed'),
(5, 27, 73, 1,'22/06/2017', '25/06/2020', 'no massage add', '29590', 'Completed'),
(6, 27, 70, 1,'22/06/2017', '25/06/2020', 'no massage add', '15792', 'Completed'),
(7, 27, 70, 1,'22/06/2017', '25/06/2020', 'no massage add', '15792', 'Completed'),
(8, 27, 71, 1, '22/06/2017', '25/06/2020', 'no massage add','15792', 'Completed'),
(9, 27, 2, 1,'22/06/2017', '25/06/2020', 'no massage add', '8538', 'Completed'),
(10, 27, 2, 1, '22/06/2017', '25/06/2020', 'no massage add','8538', 'Completed'),
(11, 27, 3, 1, '22/06/2017', '25/06/2020', 'no massage add','8538', 'Completed'),
(12, 27, 2, 1,'22/06/2017', '25/06/2020', 'no massage add', '20915', 'Completed'),
(13, 31, 71, 1,'22/06/2017', '25/06/2020', 'no massage add', '946763802', 'Completed'),
(14, 31, 71, 1,'22/06/2017', '25/06/2020', 'no massage add', '1075643942', 'Completed'),
(15, 32, 9, 1, '22/06/2017', '25/06/2020', 'no massage add','4954450', 'Completed'),
(16, 32, 9, 1, '22/06/2017', '25/06/2020', 'no massage add','4954450', 'Completed'),
(17, 32, 1, 1, '22/06/2017', '25/06/2020', 'no massage add','4954450', 'Completed'),
(18, 32, 3, 1, '22/06/2017', '25/06/2020', 'no massage add','2002781530', 'Completed'),
(19, 32, 6, 1, '22/06/2017', '25/06/2020', 'no massage add','236733806', 'Completed');

-- --------------------------------------------------------

--
-- Table structure for table `orders_info`
--

CREATE TABLE `orders_info` (
  `order_id` int(10) NOT NULL,
  `user_id` int(11) NOT NULL,
  `f_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `zip` int(10) NOT NULL,
  `cardname` varchar(255) NOT NULL,
  `cardnumber` varchar(20) NOT NULL,
  `expdate` varchar(255) NOT NULL,
  `prod_count` int(15) DEFAULT NULL,
  `total_amt` int(15) DEFAULT NULL,
  `cvv` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders_info`
--

INSERT INTO `orders_info` (`order_id`, `user_id`, `f_name`, `email`, `address`, `city`, `state`, `zip`, `cardname`, `cardnumber`, `expdate`, `prod_count`, `total_amt`, `cvv`) VALUES
(1, 27, 'Natnael Teklu', 'nat@gmail.com', 'dilla', 'bg', 'sidamo', 123456, 'natan', '3456', '12/22', 2, 8500, 1334),
(2, 27, 'Natnael Teklu', 'nat@gmail.com', 'dilla', 'Dilla', 'dds', 567890, 'natan', '4654', '12/22', 1, 25000, 5543);

-- --------------------------------------------------------

--
-- Table structure for table `order_products`
--
CREATE TABLE `order_products` (
  `order_pro_id` int(10) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `qty` int(15) DEFAULT NULL,
  `amt` int(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_products`
--

INSERT INTO `order_products` (`order_pro_id`, `order_id`, `product_id`, `qty`, `amt`) VALUES
(73, 1, 1, 1, 5000),
(74, 1, 2, 2, 64000),
(75, 1, 4, 1, 40000),
(76, 2, 5, 1, 3500),
(77, 2, 6, 1, 5000);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(100) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_cat` int(100) NOT NULL,
  `product_brand` int(110) DEFAULT NULL,
  `product_title` varchar(255) NOT NULL,
  `product_price` int(100) NOT NULL,
  `product_desc` text NOT NULL,
  `testimonals` longtext  DEFAULT NULL,
  `product_image` text NOT NULL,
  `product_image1` text NOT NULL,
  `product_image2` text NOT NULL,
  `product_image3` text NOT NULL,
  `product_keywords` text NOT NULL,
  `item_for` text NOT NULL,
  `location` text NOT NULL,
  `condition` text NOT NULL,
  `electricfence` int(11) DEFAULT NULL,
  `kichhen` int(11) DEFAULT NULL,
  `parkingbay` int(11) DEFAULT NULL,
  `swimmingpool` int(11) DEFAULT NULL,
  `waterincluded` int(11) DEFAULT NULL,
  `PricePerMonth` int(11) DEFAULT NULL,
  `PricePerDay` int(11) DEFAULT NULL,
  `FuelType` varchar(100) DEFAULT NULL,
  `ModelYear` int(6) DEFAULT NULL,
  `SeatingCapacity` int(11) DEFAULT NULL,
  `AirConditioner` int(11) DEFAULT NULL,
  `PowerDoorLocks` int(11) DEFAULT NULL,
  `AntiLockBrakingSystem` int(11) DEFAULT NULL,
  `BrakeAssist` int(11) DEFAULT NULL,
  `PowerSteering` int(11) DEFAULT NULL,
  `DriverAirbag` int(11) DEFAULT NULL,
  `PassengerAirbag` int(11) DEFAULT NULL,
  `PowerWindows` int(11) DEFAULT NULL,
  `CDPlayer` int(11) DEFAULT NULL,
  `CentralLocking` int(11) DEFAULT NULL,
  `CrashSensor` int(11) DEFAULT NULL,
  `LeatherSeats` int(11) DEFAULT NULL,
  `RegDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `checkin` int(11) NOT NULL COMMENT '0 = released, 1 =returned'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--
INSERT INTO `products` (`product_id`,`user_id`, `product_cat`, `product_brand`, `product_title`, `product_price`, `product_desc`,`testimonals`, `product_image`,`product_image1`,`product_image2`,`product_image3`, `product_keywords`, `item_for`, `location`,`condition`,`electricfence`,`kichhen`,`parkingbay`,`swimmingpool`,`waterincluded`,`PricePerMonth`, 
`PricePerDay`, `FuelType`, `ModelYear`, `SeatingCapacity`,`AirConditioner`, `PowerDoorLocks`, `AntiLockBrakingSystem`,`BrakeAssist`, `PowerSteering`, `DriverAirbag`, `PassengerAirbag`, `PowerWindows`, `CDPlayer`, `CentralLocking`, `CrashSensor`, `LeatherSeats`,`RegDate`, `UpdationDate`, `checkin`) VALUES
(1,27, 1, 1, 'hp laptop ', 5000, 'hp laptop 7 th generation', NULL,'laptop_PNG5939.png','laptop_PNG5940.png','laptop_PNG5930.png','product08.png', 'hp laptop','sale','dilla','new',NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,'2020-02-18 16:24:34', '2020-02-19 06:45:23',NULL),

(2,28, 1, 2, 'camera with 3D pixels', 2569, 'camera with 3D pixels',NULL,'camera.jpg','product09.png','camera.jpg','product09.png', 'camera','sale','molagilj','used Abroad',NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,'2020-02-18 16:24:34', '2020-02-19 06:45:23',NULL),

(3,27, 2, 4, 'vehicle ', 400000, 'Nissan made in japan','need to pay afull price depending on fault', 'car1.jpg','car2.jpg','car3.png','car4.jpg', 'Nissan car','rent','dilla','new',NULL, NULL, NULL, NULL, NULL, NULL, 1500, NULL, 1, 1, 1, 1, 1, NULL, 1, NULL, 1, NULL, 1, 1, NULL, NULL,'2020-02-18 16:24:34', '2020-02-19 06:45:23',1),

(4,28, 3, 6, 'Kids Wear', 2000, 'new kids ware', NULL,'pbb1.jpg','pbb2.jpg','pbb1.jpg','pbb3.jpg', 'best ware','sale','mazoria','new',NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,'2020-02-18 16:24:34', '2020-02-19 06:45:23',NULL),

(5,27, 4, NULL, 'house for sale', 500000, 'amaising house raady to sale', NULL,'house1.png','house2.png','house3.png','house4.png', 'house','sale','chuko','new',1, 1, 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,'2020-02-18 16:24:34', '2020-02-19 06:45:23',NULL),

(6,28, 5, NULL, 'furniture', 50000, 'bade for special comfort', NULL,'bed1.png','bad2.png','bed3.png','bed4.png', 'confort bed','sale','wondogenet','new',NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,'2020-02-18 16:24:34', '2020-02-19 06:45:23',NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tblcontactusinfo`
--

CREATE TABLE `tblcontactusinfo` (
  `id` int(11) NOT NULL,
  `Address` tinytext,
  `EmailId` varchar(255) DEFAULT NULL,
  `ContactNo` char(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblcontactusinfo`
--

INSERT INTO `tblcontactusinfo` (`id`, `Address`, `EmailId`, `ContactNo`) VALUES
(1, 'Test Demo test demo																									', 'test@test.com', '8585233222');

-- --------------------------------------------------------

--
-- Table structure for table `tblcontactusquery`
--

CREATE TABLE `tblcontactusquery` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `EmailId` varchar(120) DEFAULT NULL,
  `ContactNumber` char(11) DEFAULT NULL,
  `Message` longtext,
  `PostingDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblcontactusquery`
--

INSERT INTO `tblcontactusquery` (`id`, `name`, `EmailId`, `ContactNumber`, `Message`, `PostingDate`, `status`) VALUES
(1, 'Harry Den', 'webhostingamigo@gmail.com', '2147483647', 'Lorem Ipsum is simply','2017-06-18 10:03:07', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblpages`
--

CREATE TABLE `tblpages` (
  `id` int(11) NOT NULL,
  `PageName` varchar(255) DEFAULT NULL,
  `type` varchar(255) NOT NULL DEFAULT '',
  `detail` longtext NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblpages`
--

INSERT INTO `tblpages` (`id`, `PageName`, `type`, `detail`) VALUES
(1,'page 1','terms','no details');

-- --------------------------------------------------------

--
-- Table structure for table `tblsubscribers`
--

CREATE TABLE `tblsubscribers` (
  `id` int(11) NOT NULL,
  `SubscriberEmail` varchar(120) DEFAULT NULL,
  `PostingDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblsubscribers`
--

INSERT INTO `tblsubscribers` (`id`, `SubscriberEmail`, `PostingDate`) VALUES
(1, 'anuj.lpu1@gmail.com', '2017-06-22 16:35:32');

-- --------------------------------------------------------

--
-- Table structure for table `user_info`
--

CREATE TABLE `user_info` (
  `user_id` int(10) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` varchar(300) NOT NULL,
  `password` varchar(300) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `address1` varchar(300) NOT NULL,
  `address2` varchar(11) NOT NULL,
  `road` varchar(11) DEFAULT NULL,
 `delivery_offered` varchar(11) DEFAULT NULL,
  `seller_type` varchar(11) DEFAULT NULL,
  `user_image` text DEFAULT NULL,
  `status` int(11) DEFAULT NULL COMMENT '0 = blocked, 1 = currently users'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_info`
--

INSERT INTO `user_info` (`user_id`, `first_name`, `last_name`, `email`, `password`, `mobile`, `address1`, `address2`, `road`,`delivery_offered`,`seller_type`, `user_image`, `status`) VALUES
(27, 'Natnael', 'Teklu', 'nat@gmail.com', '123456qwe', '0922420124', 'dilla', 'dilla u','mombassa','no','bussines man','product07.png', 0),
(28, 'yekoye', 'kefale', 'ye@gmail.com', '123456qwe', '0987654398', 'dilla', 'addis','hawassa','yes','private','product08.png', 1);

-- --------------------------------------------------------
--
-- Table structure for table `user_info_backup`
--
CREATE TABLE `user_info_backup` (
  `user_id` int(10) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` varchar(300) NOT NULL,
  `password` varchar(300) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `address1` varchar(300) NOT NULL,
  `address2` varchar(11) NOT NULL,
  `road` varchar(11) DEFAULT NULL,
 `delivery_offered` varchar(11) DEFAULT NULL,
  `seller_type` varchar(11) DEFAULT NULL,
  `user_image` text DEFAULT NULL,
  `status` int(11) DEFAULT NULL COMMENT '0 = blocked, 1 = currently users'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_info_backup`
--

INSERT INTO `user_info_backup` (`user_id`, `first_name`, `last_name`, `email`, `password`, `mobile`, `address1`, `address2`, `road`,`delivery_offered`,`seller_type`, `user_image`, `status`) VALUES
(27, 'Natnael', 'Teklu', 'nat@gmail.com', '123456qwe', '0922420124', 'dilla', 'dilla u','mombassa','no','bussines man','product07.png', 0),
(28, 'yekoye', 'kefale', 'ye@gmail.com', '123456qwe', '0987654398', 'dilla', 'addis','hawassa','yes','private','product08.png', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_info`
--
ALTER TABLE `admin_info`
  ADD PRIMARY KEY (`admin_id`);
--
-- Indexes for table `review`
--
ALTER TABLE `review`
  ADD PRIMARY KEY (`review_id`);
--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`brand_id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`cat_id`);
--
-- Indexes for table `subcat`
--
ALTER TABLE `subcat`
  ADD PRIMARY KEY (`sub_id`);

--
-- Indexes for table `email_info`
--
ALTER TABLE `email_info`
  ADD PRIMARY KEY (`email_id`);

--
-- Indexes for table `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `orders_info`
--
ALTER TABLE `orders_info`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `order_products`
--
ALTER TABLE `order_products`
  ADD PRIMARY KEY (`order_pro_id`),
  ADD KEY `order_products` (`order_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `tblcontactusinfo`
--
ALTER TABLE `tblcontactusinfo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblcontactusquery`
--
ALTER TABLE `tblcontactusquery`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblpages`
--
ALTER TABLE `tblpages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblsubscribers`
--
ALTER TABLE `tblsubscribers`
  ADD PRIMARY KEY (`id`);
--
-- Indexes for table `user_info`
--
ALTER TABLE `user_info`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `user_info_backup`
--
ALTER TABLE `user_info_backup`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_info`
--
ALTER TABLE `admin_info`
  MODIFY `admin_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `review`
--
ALTER TABLE `review`
  MODIFY `review_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `brand_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `cat_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `subcat`
--
ALTER TABLE `subcat`
  MODIFY `sub_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `email_info`
--
ALTER TABLE `email_info`
  MODIFY `email_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `logs`
--
ALTER TABLE `logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `orders_info`
--
ALTER TABLE `orders_info`
  MODIFY `order_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `order_products`
--
ALTER TABLE `order_products`
  MODIFY `order_pro_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=81;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=86;

--
-- AUTO_INCREMENT for table `tblcontactusinfo`
--
ALTER TABLE `tblcontactusinfo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tblcontactusquery`
--
ALTER TABLE `tblcontactusquery`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tblpages`
--
ALTER TABLE `tblpages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `tblsubscribers`
--
ALTER TABLE `tblsubscribers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;


--
-- AUTO_INCREMENT for table `user_info`
--
ALTER TABLE `user_info`
  MODIFY `user_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `user_info_backup`
--
ALTER TABLE `user_info_backup`
  MODIFY `user_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
--
-- Constraints for dumped tables
--
--
-- Constraints for table `orders_info`
--
ALTER TABLE `orders_info`
  ADD CONSTRAINT `user_id` FOREIGN KEY (`user_id`) REFERENCES `user_info` (`user_id`);

--
-- Constraints for table `order_products`
--
ALTER TABLE `order_products`
  ADD CONSTRAINT `order_products` FOREIGN KEY (`order_id`) REFERENCES `orders_info` (`order_id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `product_id` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`);
