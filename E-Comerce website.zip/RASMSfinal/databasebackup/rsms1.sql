-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 24, 2020 at 03:34 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rsms`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_info`
--

CREATE TABLE `admin_info` (
  `admin_id` int(10) NOT NULL,
  `admin_name` varchar(100) NOT NULL,
  `admin_email` varchar(300) NOT NULL,
  `admin_password` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_info`
--

INSERT INTO `admin_info` (`admin_id`, `admin_name`, `admin_email`, `admin_password`) VALUES
(1, 'yekoye', 'admin@gmail.com', '123456qwe'),
(2, 'natnael', 'natan@gmail.com', '123456qwe');

-- --------------------------------------------------------

--
-- Table structure for table `location`
--

CREATE TABLE `brands` (
  `brand_id` int(100) NOT NULL,
  `brand_title` text NOT NULL,
  `brand_for` text NOT NULL,
  `CreationDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `location`
--

INSERT INTO `brands` (`brand_id`, `brand_title`, `brand_for`, `CreationDate`, `UpdationDate`) VALUES
(1, 'dilla town', 'sale', '2020-06-18 16:24:34', '2020-06-19 06:42:23'),
(2, 'Aleta wondo', 'sale', '2020-06-18 16:25:50', NULL),
(3, 'Wondogenet', 'rent', '2020-06-18 16:25:03', NULL),
(4, 'Chiko', 'rent', '2020-06-18 16:26:13', NULL),
(5, 'Yirgalem', 'sale', '2020-06-18 16:25:24', NULL),
(6, 'Chefe', 'both', '2020-06-19 06:22:13', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(10) NOT NULL,
  `p_id` int(10) NOT NULL,
  `ip_add` varchar(250) NOT NULL,
  `user_id` int(10) DEFAULT NULL,
  `qty` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `p_id`, `ip_add`, `user_id`, `qty`) VALUES
(6, 26, '1', 4, 1),
(9, 10, '::1', 7, 1),
(10, 11, '::1', 7, 1),
(11, 45, '::1', 7, 1),
(44, 5, '::1', 3, 0),
(46, 2, '::1', 3, 0),
(48, 72, '::1', 3, 0),
(71, 61, '127.0.0.1', -1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `cat_id` int(100) NOT NULL,
  `cat_title` text NOT NULL,
  `cat_for` text NOT NULL,
  `CreationDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`cat_id`, `cat_title`, `cat_for`, `CreationDate`, `UpdationDate`) VALUES
(1, 'Electronics', 'sale', '2020-02-18 16:24:34', '2020-02-19 06:42:23'),
(2, 'vehicle', 'rent', '2020-01-18 16:24:34', '2020-01-19 06:42:23'),
(3, 'Fashine & Beuty', 'both', '2020-02-19 16:24:34', '2020-02-20 06:42:23'),
(4, 'Property for rent & sale', 'both', '2020-06-19 06:22:13', NULL),
(5, 'Furnitures & home equipments', 'sale', '2020-02-18 16:24:34', '2020-02-19 06:44:23');

-- --------------------------------------------------------

--
-- Table structure for table `email_info`
--

CREATE TABLE `email_info` (
  `email_id` int(100) NOT NULL,
  `email` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `email_info`
--

INSERT INTO `email_info` (`email_id`, `email`) VALUES
(3, 'admin@gmail.com'),
(4, 'puneethreddy951@gmail.com'),
(5, 'puneethreddy@gmail.com');

-- --------------------------------------------------------
--
-- Table structure for table `rating`
--

CREATE TABLE `rating` (
  `rating_id` int(100) NOT NULL,
  `product_id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email_id` varchar(100) NOT NULL,
  `RDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `rate` int(5) NOT NULL,
  `review` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rating`
--

INSERT INTO `rating` (`rating_id`,`product_id`,`name`,`email_id`,`rate`, `review`, `RDate`) VALUES
(1,3,'Amsalu','admin@gmail.com',3,'what a pleasure is it!!', '2020-02-12 16:24:34'),
(2,4, 'Nesibu','nat@gmail.com',4,'i like it', '2020-03-18 16:24:34'),
(3,5,'Aklilu','ye@gmail.com',5,'what a good', '2020-02-22 16:24:34');

-- --------------------------------------------------------
--
-- Table structure for table `user_logs`
--

CREATE TABLE `user_logs` (
  `id` int(11) NOT NULL,
  `user_id` varchar(50) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `date` varchar(100) NOT NULL,
  `action` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------
--
-- Table structure for table `activity_logs`
--

CREATE TABLE `activity_logs` (
  `id` int(11) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `action` varchar(500) NOT NULL,
  `a_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
  
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `o_email` varchar(50) NOT NULL,
  `product_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `trx_id` varchar(255) NOT NULL,
  `OnDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL COMMENT '0 = pending, 1 = Sold',
 
  `p_status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `user_id`, `o_email`,`product_id`, `qty`, `OnDate`, `trx_id`,`status`, `p_status`) VALUES

(3, 27,'nat@gmail.com', 27, 1, '22/06/2017',  '29590',0, 'Completed'),
(4, 27,'nat@gmail.com', 27, 1, '22/06/2017',   '29590',1, 'Completed'),
(5, 27,'nat@gmail.com', 28, 1, '22/06/2017',  '29590', 1,'Completed'),
(6, 27, 'nat@gmail.com',27, 1, '22/06/2017',  '15792', 1,'Completed'),
(19, 32,'nat@gmail.com', 28, 1, '22/06/2017',  '236733806', 1,'Completed');

-- --------------------------------------------------------
--
-- Table structure for table `reserves`
--

CREATE TABLE `reserves` (
  `reserve_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `o_email` varchar(50) NOT NULL,
  `product_id` int(11) NOT NULL,

  `FromDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ToDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  
  `message` varchar(255) DEFAULT NULL,
  `trx_id` varchar(255) NOT NULL,
  `OnDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL COMMENT '0 = pending, 1 = Processed',
 `checkin` int(11) NOT NULL COMMENT '0 = released, 1 =returned',
  `p_status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reserves`
--

INSERT INTO `reserves` (`reserve_id`, `user_id`, `o_email`,`product_id`,  `FromDate`, `ToDate`, `OnDate`, `message`,`trx_id`,`status`,`checkin`, `p_status`) VALUES

(3, 27,'nat@gmail.com', 3,  '22/06/2017', '25/06/2020','25/06/2020', '', '29590',0,1, 'Completed'),

(19, 32,'nat@gmail.com', 4,  '22/06/2017', '25/06/2020', '25/06/2020','', '236733806', 1,1,'Completed');

-- --------------------------------------------------------
--
-- Table structure for table `orders_info`
--

CREATE TABLE `orders_info` (
  `order_id` int(10) NOT NULL,
  `user_id` int(11) NOT NULL,
  `f_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `zip` int(10) NOT NULL,
  `cardname` varchar(255) NOT NULL,
  `cardnumber` varchar(20) NOT NULL,
  `expdate` varchar(255) NOT NULL,
  `prod_count` int(15) DEFAULT NULL,
  `total_amt` int(15) DEFAULT NULL,
  `cvv` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders_info`
--

INSERT INTO `orders_info` (`order_id`, `user_id`, `f_name`, `email`, `address`, `city`, `state`, `zip`, `cardname`, `cardnumber`, `expdate`, `prod_count`, `total_amt`, `cvv`) VALUES
(1, 27, 'Natnael Teklu', 'nat@gmail.com', 'dilla', 'bg', 'sidamo', 123456, 'natan', '3456', '12/22', 2, 8500, 1334),
(2, 27, 'Natnael Teklu', 'nat@gmail.com', 'dilla', 'Dilla', 'dds', 567890, 'natan', '4654', '12/22', 1, 25000, 5543);
--
-- Table structure for table `reseve_info`
--

CREATE TABLE `reseve_info` (
  `reserve_id` int(10) NOT NULL,
  `user_id` int(11) NOT NULL,
  `f_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `zip` int(10) NOT NULL,
  `cardname` varchar(255) NOT NULL,
  `cardnumber` varchar(20) NOT NULL,
  `expdate` varchar(255) NOT NULL,
  `prod_count` int(15) DEFAULT NULL,
  `total_amt` int(15) DEFAULT NULL,
  `cvv` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reseve_info`
--

INSERT INTO `reseve_info` (`reserve_id`, `user_id`, `f_name`, `email`, `address`, `city`, `state`, `zip`, `cardname`, `cardnumber`, `expdate`, `prod_count`, `total_amt`, `cvv`) VALUES
(1, 27, 'Natnael Teklu', 'nat@gmail.com', 'dilla', 'bg', 'sidamo', 123456, 'natan', '3456', '12/22', 2, 8500, 1334),
(2, 27, 'Natnael Teklu', 'nat@gmail.com', 'dilla', 'Dilla', 'dds', 567890, 'natan', '4654', '12/22', 1, 25000, 5543);
-- --------------------------------------------------------

--
-- Table structure for table `order_products`
--

CREATE TABLE `order_products` (
  `order_pro_id` int(10) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `qty` int(15) DEFAULT NULL,
  `amt` int(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_products`
--

INSERT INTO `order_products` (`order_pro_id`, `order_id`, `product_id`, `qty`, `amt`) VALUES
(73, 1, 1, 1, 5000),
(74, 1, 2, 2, 64000),
(75, 1, 4, 1, 40000),
(76, 2, 5, 1, 3500);


-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `owner_email` varchar(255) NOT NULL,
  `product_id` int(100) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_cat` int(100) NOT NULL,
  `product_brand` int(110) DEFAULT NULL,
  `product_title` varchar(255) NOT NULL,
  `product_price` int(100) NOT NULL,
  `product_desc` text NOT NULL,
  `testimonals` longtext,
  `product_image` text NOT NULL,
  `product_image1` text NOT NULL,
  `product_image2` text NOT NULL,
  `product_image3` text NOT NULL,
  `product_keywords` text NOT NULL,
  `item_for` text NOT NULL,
  `location` text NOT NULL,
  `condition` text NOT NULL,
  
  `ram` int(11) DEFAULT NULL,
  `processor` varchar (11) DEFAULT NULL,
  `hard_derive` int(11) DEFAULT NULL,
  `pc_type` text DEFAULT NULL,
  
  `electricfence` int(11) DEFAULT NULL,
  `kichhen` int(11) DEFAULT NULL,
  `parkingbay` int(11) DEFAULT NULL,
  `swimmingpool` int(11) DEFAULT NULL,
  `waterincluded` int(11) DEFAULT NULL,
  
  `PricePerMonth` int(11) DEFAULT NULL,
  `PricePerDay` int(11) DEFAULT NULL,
  `FuelType` varchar(100) DEFAULT NULL,
  `ModelYear` int(6) DEFAULT NULL,
  `SeatingCapacity` int(11) DEFAULT NULL,
  `AirConditioner` int(11) DEFAULT NULL,
  `PowerDoorLocks` int(11) DEFAULT NULL,
  `AntiLockBrakingSystem` int(11) DEFAULT NULL,
  `BrakeAssist` int(11) DEFAULT NULL,
  `PowerSteering` int(11) DEFAULT NULL,
  `DriverAirbag` int(11) DEFAULT NULL,
  `PassengerAirbag` int(11) DEFAULT NULL,
  `PowerWindows` int(11) DEFAULT NULL,
  `CDPlayer` int(11) DEFAULT NULL,
  `CentralLocking` int(11) DEFAULT NULL,
  `CrashSensor` int(11) DEFAULT NULL,
  `LeatherSeats` int(11) DEFAULT NULL,
  `RegDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
  
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`owner_email`,`product_id`, `user_id`, `product_cat`, `product_brand`, `product_title`, `product_price`, `product_desc`, `testimonals`, `product_image`, `product_image1`, `product_image2`, `product_image3`, `product_keywords`, `item_for`, `location`, `condition`,`ram`, `hard_derive`,`pc_type`,`electricfence`, `kichhen`, `parkingbay`, `swimmingpool`, `waterincluded`, `PricePerMonth`, `PricePerDay`, `FuelType`, `ModelYear`, `SeatingCapacity`, `AirConditioner`, `PowerDoorLocks`, `AntiLockBrakingSystem`, `BrakeAssist`, `PowerSteering`, `DriverAirbag`, `PassengerAirbag`, `PowerWindows`, `CDPlayer`, `CentralLocking`, `CrashSensor`, `LeatherSeats`, `RegDate`, `UpdationDate`) VALUES
('nat@gmail.com',1, 27, 1, 1, 'hp laptop ', 15000, 'hp laptop 7 th generation', NULL, 'laptop_PNG5939.png', 'laptop_PNG5940.png', 'laptop_PNG5930.png', 'product08.png', 'hp laptop', 'sale', 'dell', 'new', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-02-18 16:24:34', '2020-03-22 15:27:36'),
('ye@gmail.com',2, 28, 1, 1, 'camera with 3D pixels', 3000, 'camera with 3D pixels', NULL, 'camera.jpg', 'product09.png', 'camera.jpg', 'product09.png', 'camera', 'sale', 'samsung', 'used Abroad', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-02-18 16:24:34', '2020-03-22 12:37:32'),
('nat@gmail.com',3, 27, 2, 4, 'vehicle ', 400000, 'Nissan made in japan', 'need to pay afull price depending on fault', 'car1.jpg', 'car2.jpg', 'car3.png', 'car4.jpg', 'Nissan car', 'rent', NULL, 'new', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1500, NULL, 1, 1, 1, 1, 1, NULL, 1, NULL, 1, NULL, 1, 1, NULL, NULL, '2020-02-18 16:24:34', '2020-02-19 06:45:23'),
('nat@gmail.com',4, 28, 3, 3, 'Kids We', 2000, 'new kids ware', NULL, 'pbb1.jpg', 'pbb2.jpg', 'pbb1.jpg', 'pbb3.jpg', 'best ware', 'sale', NULL, 'new',  NULL, NULL, NULL,NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-02-18 16:24:34', '2020-03-22 12:36:32'),
('nat@gmail.com',5, 27, 4, NULL, 'house for sale', 500000, 'amaising house raady to sale', NULL, 'house1.png', 'house2.png', 'house3.png', 'house4.png', 'house', 'sale', NULL, 'new', NULL, NULL, NULL, 1, 1, 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-02-18 16:24:34', '2020-02-19 06:45:23');

-- --------------------------------------------------------

--
-- Table structure for table `review`
--

CREATE TABLE `review` (
  `review_id` int(10) NOT NULL,
  `cus_name` varchar(100) NOT NULL,
  `cus_email` varchar(300) NOT NULL,
  `overview` varchar(300) NOT NULL,
  `review_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `review`
--

INSERT INTO `review` (`review_id`, `cus_name`, `cus_email`, `overview`, `review_date`) VALUES
(1, 'yekoye', 'admin@gmail.com', 'i seames good', '2020-06-19 06:42:23'),
(2, 'natnael', 'natan@gmail.com', 'i like it well', '2020-06-19 06:42:23');

-- --------------------------------------------------------

--
-- Table structure for table `subcat`
--

CREATE TABLE `subcat` (
  `sub_id` int(100) NOT NULL,
  `sub_title` text NOT NULL,
  `subfor` text NOT NULL,
  `CreationDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subcat`
--

INSERT INTO `subcat` (`sub_id`, `sub_title`, `subfor`, `CreationDate`, `UpdationDate`) VALUES
(1, 'laptop', 'sale', '2020-06-18 16:24:34', '2020-06-19 06:42:23');

-- --------------------------------------------------------

--
-- Table structure for table `tblcontactusinfo`
--

CREATE TABLE `tblcontactusinfo` (
  `id` int(11) NOT NULL,
  `Address` tinytext,
  `EmailId` varchar(255) DEFAULT NULL,
  `ContactNo` char(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblcontactusinfo`
--

INSERT INTO `tblcontactusinfo` (`id`, `Address`, `EmailId`, `ContactNo`) VALUES
(1, 'Test Demo test demo																									', 'test@test.com', '8585233222');

-- --------------------------------------------------------

--
-- Table structure for table `tblcontactusquery`
--

CREATE TABLE `tblcontactusquery` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `EmailId` varchar(120) DEFAULT NULL,
  `ContactNumber` char(11) DEFAULT NULL,
  `Message` longtext,
  `PostingDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblcontactusquery`
--

INSERT INTO `tblcontactusquery` (`id`, `name`, `EmailId`, `ContactNumber`, `Message`, `PostingDate`, `status`) VALUES
(1, 'Harry Den', 'webhostingamigo@gmail.com', '2147483647', 'Lorem Ipsum is simply', '2017-06-18 10:03:07', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblpages`
--

CREATE TABLE `tblpages` (
  `id` int(11) NOT NULL,
  `PageName` varchar(255) DEFAULT NULL,
  `type` varchar(255) NOT NULL DEFAULT '',
  `detail` longtext NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblpages`
--

INSERT INTO `tblpages` (`id`, `PageName`, `type`, `detail`) VALUES
(1, 'page 1', 'terms', 'no details');

-- --------------------------------------------------------

--
-- Table structure for table `tblsubscribers`
--

CREATE TABLE `tblsubscribers` (
  `id` int(11) NOT NULL,
  `SubscriberEmail` varchar(120) DEFAULT NULL,
  `PostingDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblsubscribers`
--

INSERT INTO `tblsubscribers` (`id`, `SubscriberEmail`, `PostingDate`) VALUES
(1, 'anuj.lpu1@gmail.com', '2017-06-22 16:35:32');

-- --------------------------------------------------------

--
-- Table structure for table `user_info`
--

CREATE TABLE `user_info` (
  `user_id` int(10) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` varchar(300) NOT NULL,
  `password` varchar(300) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `address1` varchar(300) NOT NULL,
  `address2` varchar(11) NOT NULL,
  `road` varchar(11) DEFAULT NULL,
  `delivery_offered` varchar(11) DEFAULT NULL,
  `seller_type` varchar(11) DEFAULT NULL,
  `user_image` varchar(120) DEFAULT NULL,
  `status` int(11) DEFAULT 1 COMMENT '0 = blocked, 1 = currently users'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_info`
--

INSERT INTO `user_info` (`user_id`, `first_name`, `last_name`, `email`, `password`, `mobile`, `address1`, `address2`, `road`, `delivery_offered`, `seller_type`, `user_image`, `status`) VALUES
(27, 'Natnael', 'Teklu', 'nat@gmail.com', '123456qwe', '0922420124', 'dilla', 'dilla u', 'mombassa', 'no', 'bussines ma', 'product07.png', 1),
(28, 'yekoye', 'kefale', 'ye@gmail.com', '123456qwe', '0987654398', 'dilla', 'addis', 'hawassa', 'yes', 'private', 'pt7.jpg', 1),
(33, 'Sisay', 'sis magna', 'sisay@gmail.com', '123456qwe', '0976543212', 'wolayta', 'dicha', 'yelewm', 'no', 'private', NULL, 1),
(34, 'yeshgeta', 'tatek', 'yesh@gmail.com', '123456qwe', '0909090909', 'hawasa', 'minjar', 'arerty', NULL, 'bussiness', NULL, 1);





--
-- Table structure for table `user_info_backup`
--

CREATE TABLE `user_info_backup` (
  `user_id` int(10) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` varchar(300) NOT NULL,
  `password` varchar(300) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `address1` varchar(300) NOT NULL,
  `address2` varchar(11) NOT NULL,
  `road` varchar(11) DEFAULT NULL,
  `delivery_offered` varchar(11) DEFAULT NULL,
  `seller_type` varchar(11) DEFAULT NULL,
  `user_image` text,
  `status` int(11) DEFAULT NULL COMMENT '0 = blocked, 1 = currently users'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_info_backup`
--

INSERT INTO `user_info_backup` (`user_id`, `first_name`, `last_name`, `email`, `password`, `mobile`, `address1`, `address2`, `road`, `delivery_offered`, `seller_type`, `user_image`, `status`) VALUES
(27, 'Natnael', 'Teklu', 'nat@gmail.com', '123456qwe', '0922420124', 'dilla', 'dilla u', 'mombassa', 'no', 'bussines ma', 'product07.png', 0),
(28, 'yekoye', 'kefale', 'ye@gmail.com', '123456qwe', '0987654398', 'dilla', 'addis', 'hawassa', 'yes', 'private', 'product08.png', 1);

--
-- Table structure for table `message`
--

CREATE TABLE IF NOT EXISTS `message` (
  `message_id` int(11) NOT NULL,
  `reciever_email` varchar(300) NOT NULL,
  `content` varchar(200) NOT NULL,
  `date_sended` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `sender_email` varchar(300) NOT NULL,
  `reciever_name` varchar(50) NOT NULL,
  `sender_name` varchar(200) NOT NULL,
  `message_status` varchar(200) NOT NULL
  
)ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `message`
--

INSERT INTO `message` (`message_id`, `reciever_email`, `content`, `date_sended`, `sender_email`, `reciever_name`, `sender_name`, `message_status`) VALUES
(39, 'nat@gmail.com', 'hi natanium?', '2015-05-11 01:48:17', 'ye@gmail.com', 'Natnael T', 'Yekoye ', 'read'),
(44, 'ye@gmail.com', 'hi yekoye?', '2015-05-11 01:48:17', 'nat@gmail.com', 'Yekoye K', ' Natnael', ''),
(45, 'nat@gmail.com', 'hi natanium?', '2015-05-11 01:48:17', 'se@gmail.com', 'Natnael T', 'Seid ', 'read'),
(63, 'se@gmail.com', 'selam seya?', '2015-05-11 01:48:17', 'ye@gmail.com', 'Seid A', 'Yekoye ', '');


-- --------------------------------------------------------

--
-- Table structure for table `message_sent`
--

CREATE TABLE IF NOT EXISTS `message_sent` (
  `message_sent_id` int(11) NOT NULL,
  `reciever_email` varchar(300) NOT NULL,
  `content` varchar(200) NOT NULL,
  `date_sended` varchar(100) NOT NULL,
  `sender_email` varchar(300) NOT NULL,
  `reciever_name` varchar(100) NOT NULL,
  `sender_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


--
-- Dumping data for table `message_sent`
--

INSERT INTO `message_sent` (`message_sent_id`, `reciever_email`, `content`, `date_sended`, `sender_email`, `reciever_name`, `sender_name`) VALUES
(1, 'nat@gmail.com', 'sad', '2013-11-12 22:50:05', 'ye@gmail.com', 'john kevin lorayna', 'john kevin lorayna'),
(2, 'nat@gmail.com', 'fasf', '2013-11-13 13:15:47', 'ye@gmail.com', 'Aladin Cabrera', 'john kevin lorayna'),
(62, 'ye@gmail.com', 'HI MESI WE ARE ATRTACHUIN YOU  THE EXAM AND  CHECK IT', '2015-06-16 03:12:53', 'nat@gmail.com', 'Lionel Messi', 'Abita Gebrei'),
(63, 'ye@gmail.com', 'hi  Sir , activate our Grade.', '2015-06-16 05:04:42', 'nat@gmail.com', 'Geleta Kasew', 'we we');

-- --------------------------------------------------------

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_info`
--
ALTER TABLE `admin_info`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `location`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`brand_id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `email_info`
--
ALTER TABLE `email_info`
  ADD PRIMARY KEY (`email_id`);
--
-- Indexes for table `rating`
--
ALTER TABLE `rating`
  ADD PRIMARY KEY (`rating_id`);
    
--
-- Indexes for table `user_logs`
--
ALTER TABLE `user_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `activity_logs`
--
ALTER TABLE `activity_logs`
  ADD PRIMARY KEY (`id`);
--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`);
--
-- Indexes for table `reserves`
--
ALTER TABLE `reserves`
  ADD PRIMARY KEY (`reserve_id`);
--
-- Indexes for table `orders_info`
--
ALTER TABLE `orders_info`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `user_id` (`user_id`);
--
-- Indexes for table `reseve_info`
--
ALTER TABLE `reseve_info`
  ADD PRIMARY KEY (`reserve_id`),
  ADD KEY `user_id` (`user_id`);
--
-- Indexes for table `order_products`
--
ALTER TABLE `order_products`
  ADD PRIMARY KEY (`order_pro_id`),
  ADD KEY `order_products` (`order_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `review`
--
ALTER TABLE `review`
  ADD PRIMARY KEY (`review_id`);

--
-- Indexes for table `subcat`
--
ALTER TABLE `subcat`
  ADD PRIMARY KEY (`sub_id`);

--
-- Indexes for table `tblcontactusinfo`
--
ALTER TABLE `tblcontactusinfo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblcontactusquery`
--
ALTER TABLE `tblcontactusquery`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblpages`
--
ALTER TABLE `tblpages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblsubscribers`
--
ALTER TABLE `tblsubscribers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_info`
--
ALTER TABLE `user_info`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `user_info_backup`
--
ALTER TABLE `user_info_backup`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `message`
--
ALTER TABLE `message`
  ADD PRIMARY KEY (`message_id`);
--
-- Indexes for table `message_sent`
--
ALTER TABLE `message_sent`
  ADD PRIMARY KEY (`message_sent_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_info`
--
ALTER TABLE `admin_info`
  MODIFY `admin_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `location`
--
ALTER TABLE `brands`
  MODIFY `brand_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `cat_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `rating`
--
ALTER TABLE `rating`
  MODIFY `rating_id` int(100) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `email_info`
--
ALTER TABLE `email_info`
  MODIFY `email_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `user_logs`
--
ALTER TABLE `user_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `activity_logs`
--
ALTER TABLE `activity_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `reserves`
--
ALTER TABLE `reserves`
  MODIFY `reserve_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `orders_info`
--
ALTER TABLE `orders_info`
  MODIFY `order_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `reseve_info`
--
ALTER TABLE `reseve_info`
  MODIFY `reserve_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `order_products`
--
ALTER TABLE `order_products`
  MODIFY `order_pro_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=78;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `review`
--
ALTER TABLE `review`
  MODIFY `review_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `subcat`
--
ALTER TABLE `subcat`
  MODIFY `sub_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tblcontactusinfo`
--
ALTER TABLE `tblcontactusinfo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tblcontactusquery`
--
ALTER TABLE `tblcontactusquery`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tblpages`
--
ALTER TABLE `tblpages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `tblsubscribers`
--
ALTER TABLE `tblsubscribers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user_info`
--
ALTER TABLE `user_info`
  MODIFY `user_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `user_info_backup`
--
ALTER TABLE `user_info_backup`
  MODIFY `user_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;


--
-- AUTO_INCREMENT for table `message`
--
ALTER TABLE `message`
  MODIFY `message_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `message_sent`
--
ALTER TABLE `message_sent`
  MODIFY `message_sent_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- Constraints for dumped tables
--
--
-- Constraints for table `orders_info`
--
ALTER TABLE `orders_info`
  ADD CONSTRAINT `user_id` FOREIGN KEY (`user_id`) REFERENCES `user_info` (`user_id`);
--
-- Constraints for table `reseve_info`
--
ALTER TABLE `reseve_info`
  ADD CONSTRAINT `user_id` FOREIGN KEY (`user_id`) REFERENCES `user_info` (`user_id`);
--
-- Constraints for table `order_products`
--
ALTER TABLE `order_products`
  ADD CONSTRAINT `order_products` FOREIGN KEY (`order_id`) REFERENCES `orders_info` (`order_id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `product_id` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
