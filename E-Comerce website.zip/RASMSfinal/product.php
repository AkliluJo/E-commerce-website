<?php

include "header.php";
?>
<head>
<style>

button {
	outline: none;
}
button.submit {
	border-radius: 5px;
	border: 2px solid #086736;
	background: #086736;
	color: #fff;
	cursor: pointer;
	padding: 7px 15px;
	font-weight: bold;
	font-family: Arial, sans-serif;
    font-size: 15px;
}
button.submit:hover {
	background: #59993E;
	border-color: #59993E;
}
button.submit:disabled {
	background: 0;
	border: 2px solid #086736;
	color: #086736;
	cursor: not-allowed;
}


</style>

<style>

#accessories i,
.price,
.inventory_info_list ul li i,
.services_info h4 a:hover,
.about_info .icon_box,
.header_style2 .navbar-nav > li > .dropdown-menu a:hover,
.header_style2 .navbar-default .navbar-nav li:hover .dropdown-menu li a:hover,
.header_style2 .dropdown-menu > .active > a,
.header_style2 .dropdown-menu > .active > a:focus,
.header_style2 .dropdown-menu > .active > a:hover,
.header_style2 .dropdown-menu > li > a:focus,
.header_style2 .dropdown-menu > li > a:hover {
	color:#fa2837;
	fill: #fa2837;
}




/*-----------------
	1.6. Table
---------------------------*/

table {
	margin:0 0 30px;
	width:100%;
}
table th, table td {
  border: 1px solid #cccccc;
  padding: 15px;
  padding:18px;
}
table th img, table td img {
	max-width:100%;
}
table thead {
	background:#eee;
}
table thead th, table thead td {
	text-transform:uppercase;
	font-weight:900;
	color:#111;
}
<!--- for computer accesory-->
table, tr, td {
  border: 3px solid red;
}
tr.noBorder td {
  border: 0;
}
<!--- for computer accesory-->

</style>
 <!--
 <link type="text/css" rel="stylesheet" href="css/example.css"/>
<link type="text/css" rel="stylesheet" href="css/cs/slick.css"/>
<link type="text/css" rel="stylesheet" href="css/cs/style.css"/>
 -->
</head>

		<!-- /BREADCRUMB -->
<script type="text/javascript">
			jQuery(document).ready(function($) {
				$(".scroll").click(function(event){		
					event.preventDefault();
					$('html,body').animate({scrollTop:$(this.hash).offset().top},900);
				});
			});
</script>
<script>
    (function (global) {
	if(typeof (global) === "undefined")
	{
		throw new Error("window is undefined");
	}
    var _hash = "!";
    var noBackPlease = function () {
        global.location.href += "#";
		// making sure we have the fruit available for juice....
		// 50 milliseconds for just once do not cost much (^__^)
        global.setTimeout(function () {
            global.location.href += "!";
        }, 50);
    };	
	// Earlier we had setInerval here....
    global.onhashchange = function () {
        if (global.location.hash !== _hash) {
            global.location.hash = _hash;
        }
    };
    global.onload = function () {        
		noBackPlease();
		// disables backspace on page except on input fields and textarea..
		document.body.onkeydown = function (e) {
            var elm = e.target.nodeName.toLowerCase();
            if (e.which === 8 && (elm !== 'input' && elm  !== 'textarea')) {
                e.preventDefault();
            }
            // stopping event bubbling up the DOM tree..
            e.stopPropagation();
        };		
    };
})(window);
</script>

		<!-- SECTION -->
		<div class="section main main-raised">
			<!-- container -->
			<div class="container">
				<!-- row -->
				<div class="row">
					<!-- Product main img -->
					
				<?PHP
								include 'db.php';
								 $product_id = $_GET['pid'];

								 
								/*  
							  $sql = " SELECT * FROM products
								  LEFT JOIN rating ON rating.product_id= products.product_id
								  WHERE products.product_id = $product_id"; */  								 
								  $sql = " SELECT * FROM products WHERE product_id = $product_id";    
								 
								 if (!$con) {
									die("Connection failed: " . mysqli_connect_error());
								}
				
								
								$result = mysqli_query($con, $sql);
								if (mysqli_num_rows($result) > 0) 
								{
									
									
		
									while($row = mysqli_fetch_assoc($result)) 
									{
									
									echo '
							    
                                <div class="col-md-5 col-md-push-2">
                                <div id="product-main-img">
                                    <div class="product-preview">
                                        <img src="product_images/'.$row['product_image'].'" alt="">
                                    </div>

                                    <div class="product-preview">
                                        <img src="product_images/'.$row['product_image1'].'" alt="">
                                    </div>

                                    <div class="product-preview">
                                        <img src="product_images/'.$row['product_image2'].'" alt="">
                                    </div>

                                    <div class="product-preview">
                                        <img src="product_images/'.$row['product_image3'].'" alt="">
                                    </div>
                                </div>
                            </div>
                                
                                <div class="col-md-2  col-md-pull-5">
                                <div id="product-imgs">
                                    <div class="product-preview">
                                        <img src="product_images/'.$row['product_image'].'" alt="">
                                    </div>

                                    <div class="product-preview">
                                        <img src="product_images/'.$row['product_image1'].'" alt="">
                                    </div>

                                    <div class="product-preview">
                                        <img src="product_images/'.$row['product_image2'].'g" alt="">
                                    </div>

                                    <div class="product-preview">
                                        <img src="product_images/'.$row['product_image3'].'" alt="">
                                    </div>
                                </div>
                            </div>

                                 
									';
                                    
									

							
									
									 
									echo '
<!--									
<table>
<tr>
<td-->
                                   
                    <div class="col-md-5">
						<div class="product-details">
							<h2 class="product-name">'.$row['product_title'].'</h2>							
							<div>
							';
							

							
					$sqln = " SELECT * FROM rating WHERE product_id = $product_id LIMIT 1"; 
									$run_quer = mysqli_query($con,$sqln);
												 while($rows = mysqli_fetch_array($run_quer)){  
												 if($rows["rate"]==1)
															{
															echo'
															
															<div class="product-rating">
																<i class="fa fa-star"></i>
																<i class="fa fa-star-o empty"></i>
																<i class="fa fa-star-o empty"></i>
																<i class="fa fa-star-o empty"></i>
																<i class="fa fa-star-o empty"></i>
															</div>	
															';
															}
															if($rows["rate"]==2)
															{
															echo'
															<div class="product-rating">
																<i class="fa fa-star"></i>
																<i class="fa fa-star"></i>
																<i class="fa-star-o empty"></i>
																<i class="fa fa-star-o empty"></i>
																<i class="fa fa-star-o empty"></i>
															</div>	
															';
															}
															if($rows["rate"]==3)
															{
															echo'
														  <div class="product-rating">
																<i class="fa fa-star"></i>
																<i class="fa fa-star"></i>
																<i class="fa fa-star"></i>
																<i class="fa fa-star-o empty"></i>
																<i class="fa fa-star-o empty"></i>
															</div>	
															';
															}
															if($rows["rate"]==4)
															{
															echo'
															<div class="product-rating">
																<i class="fa fa-star"></i>
																<i class="fa fa-star"></i>
																<i class="fa fa-star"></i>
																<i class="fa fa-star"></i>
																<i class="fa fa-star-o empty"></i>
															</div>
															';
															}
															if($rows["rate"]==5)
															{
															echo'
															<div class="product-rating">
																<i class="fa fa-star"></i>
																<i class="fa fa-star"></i>
																<i class="fa fa-star"></i>
																<i class="fa fa-star"></i>
																<i class="fa fa-star"></i>
															</div>
															';
															}								
												 }	
		                   echo'
							</div>
							';	
							if($row["item_for"]==1)
						{}else{echo'
					
							<div>						
		<h3 class="product-price">Br&nbsp;'.$row['product_price'].'<del class="product-old-price"></del></h3><br>
		</div>
							';}echo'
								<div>
		<font color="blue" SIZE = "+2"> <b>Discription</b></font>
		<p>'.$row['product_desc'].'</p>
							</div>
							
							';
						if($row["item_for"]==1||$row["status"]==1)
						{}else{echo'							
							<div class="add-to-cart">

							<div class="btn-group" style="margin-left: 25px; margin-top: 15px">
								<button class="add-to-cart-btn" pid="'.$row['product_id'].'"  id="product" ><i class="fa fa-shopping-cart"></i> add to cart</button>
                            </div>
                              </div>
							  
						  ';}echo'

							<div class="add-to-cart">
								<div class="qty-label">
									
								</div>

								
								
							</div>




						</div>
						<h3 class="product-name">Contact Item Owner </h3>
					</div>
					                      
<!--/tr>
</td>	
<tr>
<td-->
				<!-- Review Form -->
				<hr>
									<div class="col-md-3 mainn">
									<div id="review-form">
											    <form class="review-form" action="messageprocess.php" name="form" method="post">								
			                                        ';
													 if (!isset($_SESSION["uid"])) 
                                                      {
														  echo '
												   
													<textarea class="input" name ="message" placeholder="Your Message" required></textarea>
							                     
								  

				                               <a href="" data-toggle="modal" data-target="#Modal_login" <button onclick="myFunction()" id="btnPrint" class="btn btn-primary btn-lg pull-right" ><i class="fa fa-tags"></i>Login For Chatting </button></a>

									
													';

                                                   }
												   else if(isset($_SESSION["uid"])){ 
												   echo '
												
													<textarea class="input" name ="message" placeholder="Your Message" required></textarea>
												

				                                <button id="btnPrint" class="btn btn-primary btn-lg pull-right" name="send_button" ><i class="fa fa-tags"></i>Send Message </button>

									

			
			
                                                     ';
													 }
													echo ' 
												</form>
							
							<!--Alert from signup form-->
                            </div>
						</div>
</tr>
</td>
</table>
                <!-- /Review Form -->
					<!-- /Product main img -->

					<!-- Product thumb imgs -->
					
					
					
					<!-- /Product thumb imgs -->

					<!-- Product details -->
					
					<!-- /Product details -->

					<!-- Product tab -->
					
					<div class="col-md-12">
						<div id="product-tab">
							<!-- product tab nav -->
							<ul class="tab-nav">
				<li class="active"><a data-toggle="tab" href="#tab1">Accessories</a></li>
				<li><a data-toggle="tab" href="#tab2">Testimonals</a></li>
				';
			$sql = "SELECT COUNT(*) AS count_items FROM rating WHERE product_id=$product_id";
            $query1 = mysqli_query($con,$sql);
            $rowa = mysqli_fetch_array($query1);
            $count=$rowa["count_items"];
			echo'
				<li><a data-toggle="tab" href="#tab3">Reviews ('.$count.')</a></li>
							</ul>
							<!-- /product tab nav -->

							<!-- product tab content -->
							<div class="tab-content">
							
								<!-- tab1  -->
								<div id="tab1" class="tab-pane fade in active">
									<div class="row">
										<div class="col-md-12">
';

if($row["product_cat"]==2)
{
	echo'
<table>
                  <thead>
                    <tr>
                      <th colspan="2">Accessories</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
    <td> Air Conditioner</td>
			';		  
 if($row["AirConditioner"]==1)
{
echo '
   <td><i class="fa fa-check" aria-hidden="true"></i></td>
   ';
 } else {  
 echo '
   <td><i class="fa fa-close" aria-hidden="true"></i></td>
   ';
    }  
	echo '
	</tr>

<tr>
<td>AntiLock Braking System</td>
';

if($row["AntiLockBrakingSystem"]==1)
{
echo '
<td><i class="fa fa-check" aria-hidden="true"></i></td>
';
 } else {
	 echo '
<td><i class="fa fa-close" aria-hidden="true"></i></td>
';
 }
echo ' 
 </tr>
<tr>
<td>Power Steering</td>
';

 if($row["PowerSteering"]==1)
{
echo '
<td><i class="fa fa-check" aria-hidden="true"></i></td>
';
} else { 
echo '
<td><i class="fa fa-close" aria-hidden="true"></i></td>
';
 } 
 echo '
</tr>
                   

<tr>

<td>Power Windows</td>
';
 if($row["PowerWindows"]==1)

{
echo '
<td><i class="fa fa-check" aria-hidden="true"></i></td>
';
} else {
	echo '
<td><i class="fa fa-close" aria-hidden="true"></i></td>
';
 } 
 echo '
</tr>
                   
 <tr>
<td>CD Player</td>
';
if($row["CDPlayer"]==1)
{
	 echo '
<td><i class="fa fa-check" aria-hidden="true"></i></td>
 
 ';
 } 
 
 else {
	  echo '
<td><i class="fa fa-close" aria-hidden="true"></i></td>
';
 } 
  echo '
</tr>

<tr>
<td>Leather Seats</td>
';
if($row["LeatherSeats"]==1)
{
	 echo '

<td><i class="fa fa-check" aria-hidden="true"></i></td>
';
 } 
 else { 
  echo '
<td><i class="fa fa-close" aria-hidden="true"></i></td>
';
 } 
  echo '
</tr>

<tr>
<td>Central Locking</td>
';

if($row["CentralLocking"]==1)
{
	 echo '

<td><i class="fa fa-check" aria-hidden="true"></i></td>
';
 } else {
	  echo '
<td><i class="fa fa-close" aria-hidden="true"></i></td>
';
} 
 echo '
</tr>

<tr>
<td>Power Door Locks</td>
';
 
if($row["PowerDoorLocks"]==1)
{
	 echo '

<td><i class="fa fa-check" aria-hidden="true"></i></td>
';
 } else {
	  echo '
<td><i class="fa fa-close" aria-hidden="true"></i></td>
';
 } 
  echo '
                    </tr>
                    <tr>
<td>Brake Assist</td>
';
if($row["BrakeAssist"]==1)
{
	echo'
<td><i class="fa fa-check" aria-hidden="true"></i></td>
';
  } else {
	  echo'
	  
<td><i class="fa fa-close" aria-hidden="true"></i></td>
';
 } 
 echo'
</tr>

<tr>
<td>Driver Airbag</td>
';

if($row["DriverAirbag"]==1)
{
echo'	

<td><i class="fa fa-check" aria-hidden="true"></i></td>
';
} else { 
echo'
<td><i class="fa fa-close" aria-hidden="true"></i></td>
';
 } 
 echo'
 </tr>
 
 <tr>
 <td>Passenger Airbag</td>
 ';

if($row["PassengerAirbag"]==1)
{
echo'	

<td><i class="fa fa-check" aria-hidden="true"></i></td>
';
 } else {
	 echo'
<td><i class="fa fa-close" aria-hidden="true"></i></td>
';
 } 
 echo'
</tr>

<tr>
<td>Crash Sensor</td>
';
if($row["CrashSensor"]==1)
{
echo'
<td><i class="fa fa-check" aria-hidden="true"></i></td>
';
} else {
echo'	
<td><i class="fa fa-close" aria-hidden="true"></i></td>
';
}}
if($row["item_for"]==4)
{
	echo'
	
			<div class="col-25">
				<div class="container-checkout">

					<table class="table table-condensed">
					<thead>
					<tr class="noBorder">
					<th >Brand</th>
					<th >Pc type</th>
					<th >RAM</th>
					<th >Processor	</th>
					<th >Hard Derive</th>
					</tr>
					</thead>
					<tbody>
				
					
				<tr class="noBorder">
				<td><p>'.$row['brand'].'</p></td>
				<td><p>'.$row['pc_type'].'</p></td>
				<td><p>'.$row['ram'].'GB</p></td>
				<td ><p>'.$row['processor'].'GHz</p></td>
				<td ><p>'.$row['hard_derive'].'GB</p></td>
				</tr>
				</tbody>
				</table>
				<hr>
				
				</div>
			</div>

';
}
echo' 
</tr>

  </tbody>
 </table>







										</div>
									</div>
								</div>
								<!-- /tab1  -->
';

if($row["item_for"]==1||$row["item_for"]==2)
{
echo'


						<!-- tab2  -->
								<div id="tab2" class="tab-pane fade in">
									<div class="row">
										<div class="col-md-12">
		<div class="row-checkout">

			<div class="col-75">
				<div class="container-checkout">
				<form class="was-validated" action="reserveaction.php" name="form" method="post">	
';
			/* 	
			$sqls = " SELECT * FROM rating WHERE product_id = $product_id LIMIT 3"; 
				$run_quer = mysqli_query($con,$sqls);
				 while($rows = mysqli_fetch_array($run_quer))  */ 
echo'
					<div class="row-checkout">
							<font color="blue" SIZE = "+2"> <b>Preconceive</b></font>
							<br>
		            
					 	<p>'.$row['testimonals'].'</p>
					
					  <font color="blue" SIZE = "+2"> <b>Price per day:</b></font><font color="red"><b>&nbsp;&nbsp;Br&nbsp;'.$row['PricePerDay'].'</b></font>
					  <br>		         
					 	
					  <hr>
					<div class="col-50">
						<font color="blue" SIZE = "+2"> <b>Reserve Items Here</b></font><br>
						<label for="fname"><i class="fa fa-user" ></i> From Date</label>
						<br>
						
						<input class="form-control" type="date"   required title="Please enter date" max="2030-12-31" min="2021-01-02" name="fdate" >
						
						<br>
						<label for="email"><i class="fa fa-envelope"></i>Upto Date</label>
						<br>
						<input class="form-control" type="date"   required title="Please enter date" max="2030-12-31" min="2021-01-02" name="udate" > 
						<br>
						<input type="hidden" name="hidden" value="'.$row['PricePerDay'].'" >
						
						<label for="adr"><i class="fa fa-address-card-o"></i> Massage</label>
						<br>
						
						<textarea class="form-control" name ="message" placeholder="type some thing here" required></textarea><br><br>
						

					</div>
					
					</div>
								             ';
										 if (!isset($_SESSION["uid"])) 
                                                      {
														  echo '
														  
														  
	                 <div class="center">
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				   <button class="submit" type="submit"  > <a href="" data-toggle="modal" data-target="#Modal_login" class="submit"><i class="fa fa-tags"></i><font color="white" > Login For Rserve</font></a></button>	
                    </div>
					';
					                                    }
												   else if(isset($_SESSION["uid"])){ 
												   echo '
					
						<div class="center">
					  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						 <button class="submit" type="reset" id="register-submit">Reset</button>
						 
                        <button class="submit" type="submit" name="book_buton"   ><i class="fa fa-tags"></i> Reserve Now</button>
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    </div>
	                                                ';
													 }
													echo ' 
							
				</form>
				</div>
			</div>
		</div>							
											
											
											
										</div>
									</div>
								</div>
								<!-- /tab2  -->	
';								

}
		
			                        
echo'

<!-- tab3  -->
								<div id="tab3" class="tab-pane fade in">
									<div class="row">
										<!-- Rating -->
										<div class="col-md-3">
											<div id="rating">
												
												
											</div>
										</div>
										<!-- /Rating -->

										<!-- Reviews -->
										<div class="col-md-6">
											<div id="reviews">
												<ul class="reviews">
												';
								$sqln = " SELECT * FROM rating WHERE product_id = $product_id LIMIT 3"; 
									$run_quer = mysqli_query($con,$sqln);
												 while($rows = mysqli_fetch_array($run_quer)){  
												echo'
												
												
													<li>
														<div class="review-heading">
															<h5 class="name">'.$rows['name'].'</h5>
															<p class="date">'.$rows['RDate'].'</p>
															';
															if($rows["rate"]==1)
															{
															echo'
															<div class="review-rating">
																<i class="fa fa-star"></i>
																<i class="fa fa-star-o empty"></i>
																<i class="fa fa-star-o empty"></i>
																<i class="fa fa-star-o empty"></i>
																<i class="fa fa-star-o empty"></i>
															</div>	
															';
															}
															if($rows["rate"]==2)
															{
															echo'
															<div class="review-rating">
																<i class="fa fa-star"></i>
																<i class="fa fa-star"></i>
																<i class="fa-star-o empty"></i>
																<i class="fa fa-star-o empty"></i>
																<i class="fa fa-star-o empty"></i>
															</div>	
															';
															}
															if($rows["rate"]==3)
															{
															echo'
														  <div class="review-rating">
																<i class="fa fa-star"></i>
																<i class="fa fa-star"></i>
																<i class="fa fa-star"></i>
																<i class="fa fa-star-o empty"></i>
																<i class="fa fa-star-o empty"></i>
															</div>	
															';
															}
															if($rows["rate"]==4)
															{
															echo'
															<div class="review-rating">
																<i class="fa fa-star"></i>
																<i class="fa fa-star"></i>
																<i class="fa fa-star"></i>
																<i class="fa fa-star"></i>
																<i class="fa fa-star-o empty"></i>
															</div>
															';
															}
															if($rows["rate"]==5)
															{
															echo'
															<div class="review-rating">
																<i class="fa fa-star"></i>
																<i class="fa fa-star"></i>
																<i class="fa fa-star"></i>
																<i class="fa fa-star"></i>
																<i class="fa fa-star"></i>
															</div>
															';
															}														
															echo'

															
														</div>
														<div class="review-body">
														<p>'.$rows['review'].'</p>
														</div>
													</li>
													';
													
												 } 
												echo'

												</ul>

											</div>
										</div>
										<!-- /Reviews -->

										<!-- Review Form -->
										<div class="col-md-3 mainn">
										
											<div id="review-form">
										<form class="review-form" action="ratingprocess.php" name="form" method="post">
											
													<input class="input" type="text" name="rname" id="name" placeholder="Your Name" required>
													<input class="input" type="email"  name="email" placeholder="Your Email" required>
													<textarea class="input" name ="rmassage" placeholder="Your Review"required></textarea>
													<div class="input-rating">
														<span>Your Rating: </span>
														<div class="stars">
															<input id="star5" name="rating" value="5" type="radio"><label for="star5"></label>
															<input id="star4" name="rating" value="4" type="radio"><label for="star4"></label>
															<input id="star3" name="rating" value="3" type="radio"><label for="star3"></label>
															<input id="star2" name="rating" value="2" type="radio"><label for="star2"></label>
															<input id="star1" name="rating" value="1" type="radio" required><label for="star1"></label>
														</div>
													</div>
													<button class="primary-btn" value="Submit" name="rating_button" type="submit"><i class="fa fa-tags"></i> Submit</button>
												</form>
							<div class="" id="offer_msg">
                                <!--Alert from signup form-->
                            </div>
							<!--Alert from signup form-->
                            </div>
											</div>
										</div>
										<!-- /Review Form -->
									</div>
								</div>
								<!-- /tab3  -->
								';
		
		echo'
								
							</div>
							<!-- /product tab content  -->
						</div>
					</div>
					<!-- /product tab -->
				</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>
		<!-- /SECTION -->

		<!-- Section -->
		
                    
					
                    ';
				$_SESSION['product_id'] = $row['product_id'];
				$_SESSION['o_email'] = $row['owner_email'];
				}
				}
				
				
                  				



						


?>
					<!-- product -->
					
					<!-- /product -->

				</div>
				<!-- /row -->
                
			</div>
			<!-- /container -->
		</div>
		<!-- /Section -->

		<!-- NEWSLETTER -->
		
		<!-- /NEWSLETTER -->

		<!-- FOOTER -->
<?php
include "newslettter.php";
include "footer.php";

?>
