<head>
<style>
<link rel="stylesheet" href="menu/index_files/mbcsmbmcp.css" type="text/css" />

</style>
</head>




<?php
session_start();
$ip_add = getenv("REMOTE_ADDR");
   include 'db.php';

if(isset($_POST["categoryhome"])){
	$category_query = "SELECT * FROM categories ";
    
	$run_query = mysqli_query($con,$category_query) or die(mysqli_error($con));
	echo "
		
            
            
				<!-- responsive-nav -->
				<div id='responsive-nav'>
					<!-- NAV -->
					<ul class='main-nav nav navbar-nav'>
                    <li class=''><a href='index.php'><b>Home</b></a></li>
                    <li ><a href='store.php'><b>All Categories</b></a></li>
					 
					
	";
	if(mysqli_num_rows($run_query) > 0){
		while($row = mysqli_fetch_array($run_query)){
			$cid = $row["cat_id"];
			$cat_name = $row["cat_title"];
            
            $sql = "SELECT COUNT(*) AS count_items FROM products,categories WHERE product_cat=cat_id";
            $query = mysqli_query($con,$sql);
            $row = mysqli_fetch_array($query);
            $count=$row["count_items"];
			echo "
			   
          <li class='categoryhome' cid='$cid'><a href='store.php'><font  ><b>$cat_name</b></font></a></li>
                    
			";
		}
        
		echo "</ul>
					<!-- /NAV -->
				</div>
				<!-- /responsive-nav -->
               
			";
	}
}


if(isset($_POST["page"])){
	$sql = "SELECT * FROM products WHERE status='0'";
	$run_query = mysqli_query($con,$sql);
	$count = mysqli_num_rows($run_query);
	$pageno = ceil($count/2);
	for($i=1;$i<=$pageno;$i++){
		echo "
			<li><a href='#product-row' page='$i' id='page'>$i</a></li>
            
            
		";
	}
}
if(isset($_POST["getProducthome"])){
	$limit = 3;
	if(isset($_POST["setPage"])){
		$pageno = $_POST["pageNumber"];
		$start = ($pageno * $limit) - $limit;
	}else{
		$start = 0;
	}
	$product_query = "SELECT * FROM products,categories WHERE status='0' AND product_cat=cat_id LIMIT $start,$limit";
	$run_query = mysqli_query($con,$product_query);
	if(mysqli_num_rows($run_query) > 0){
		while($row = mysqli_fetch_array($run_query)){
			$pro_id    = $row['product_id'];
			$pro_cat   = $row['product_cat'];
			$pro_brand = $row['product_location'];
			$pro_title = $row['product_title'];
			$pro_price = $row['product_price'];
			$pro_image = $row['product_image'];
            $ppd = $row['PricePerDay'];
            $cat_name = $row["cat_title"];
			echo "
				
                       <div class='product-widget'>
                                <a href='product.php?pid=$pro_id'> 
									<div class='product-img'>
										<img src='product_images/$pro_image' alt=''>
									</div>
									<div class='product-body'>
										<p class='product-category'>$cat_name</p>
										<h3 class='product-name'><a href='product.php?pid=$pro_id'>$pro_title</a></h3>
										<h4 class='product-price'>Br:$pro_price</h4>
									</div></a>
								</div>
                        
			";
		}
	}
}


if(isset($_POST["gethomeProduct"])){
	$limit = 9;
	if(isset($_POST["setPage"])){
		$pageno = $_POST["pageNumber"];
		$start = ($pageno * $limit) - $limit;
	}else{
		$start = 0;
	}
    $product_query = "SELECT * FROM products,categories,location WHERE product_cat=cat_id AND product_location=location_id AND status='0' AND product_id BETWEEN 1 AND 6";
	$run_query = mysqli_query($con,$product_query);
	if(mysqli_num_rows($run_query) > 0){
        
		while($row = mysqli_fetch_array($run_query)){
			$pro_id    = $row['product_id'];
			$pro_cat   = $row['product_cat'];
			$pro_brand = $row['product_location'];
			$pro_title = $row['product_title'];
			$pro_price = $row['product_price'];
			$pro_image = $row['product_image'];
			$pro_condition = $row['condition'];
			$location = $row['location_title'];
            $ppd = $row['PricePerDay'];
            $cat_name = $row["cat_title"];
            
			echo "
				
                        
                                <div class='col-md-3 col-xs-6'>
								<a href='product.php?pid=$pro_id'><div class='product'>
									<div class='product-img'>
										<img src='product_images/$pro_image' style='max-height: 170px;' alt=''>
										<div class='product-label'>
											<span class='sale'>$location</span>
											<span class='new'>$pro_condition</span>
										</div>
									</div></a>
									<div class='product-body'>
										<p class='product-category'><font color='blue' ><b>$cat_name</font></b></p>
										<h3 class='product-name header-cart-item-name'><a href='product.php?pid=$pro_id'>$pro_title</a></h3>
																				";
										if($row["product_price"]<1){
											echo"
										<h4 class='product-price header-cart-item-info'>Br:$ppd Per Day</h4>
											";
										}else{
										
										echo"
										<h4 class='product-price header-cart-item-info'>Br:$pro_price</h4>
										";}
										
										$sql1 = "SELECT COUNT(*) AS count_items FROM rating WHERE product_id=$pro_id";
            $query1 = mysqli_query($con,$sql1);
            $rowas = mysqli_fetch_array($query1);
            $count=$rowas["count_items"];
			$sql2 = "SELECT SUM(rate) AS amount FROM rating WHERE product_id=$pro_id";
			$query2 = mysqli_query($con,$sql2);
            $rowaaa = mysqli_fetch_array($query2);
			$product=$rowaaa["amount"];
			if($count==0){
				$result2=0;
			}
			else{
			$result=($product/$count);
			$result2=number_format($result,1);
			}
			


								$sqln = " SELECT * FROM rating WHERE product_id = $pro_id LIMIT 1"; 
									$run_quer = mysqli_query($con,$sqln);
												 while($rows = mysqli_fetch_array($run_quer)){  
												echo'
												
												
													
														<div class="review-heading">
															
															';
															if($rows["rate"]==1)
															{
															echo'
															<font color="red"><b>'.$result2.'<b> Of 5 Stars</font>
															<div class="product-rating">
																<i class="fa fa-star"></i>
																<i class="fa fa-star-o empty"></i>
																<i class="fa fa-star-o empty"></i>
																<i class="fa fa-star-o empty"></i>
																<i class="fa fa-star-o empty"></i>
															</div>	
															';
															}
															if($rows["rate"]==2)
															{
															echo'
														<span><b>'.$result2.'<b> Of 5 Stars</span>
															<div class="product-rating">
																<i class="fa fa-star"></i>
																<i class="fa fa-star"></i>
																<i class="fa-star-o empty"></i>
																<i class="fa fa-star-o empty"></i>
																<i class="fa fa-star-o empty"></i>
															</div>	
															';
															}
															if($rows["rate"]==3)
															{
															echo'
															
															<span ><b>'.$result2.'<b> Of 5 Stars</span>
															
														  <div class="product-rating">
																<i class="fa fa-star"></i>
																<i class="fa fa-star"></i>
																<i class="fa fa-star"></i>
																<i class="fa fa-star-o empty"></i>
																<i class="fa fa-star-o empty"></i>
															</div>	
															';
															}
															if($rows["rate"]==4)
															{
															echo'
														<span><b>'.$result2.'<b> Of 5 Stars</span>
															<div class="product-rating">
																<i class="fa fa-star"></i>
																<i class="fa fa-star"></i>
																<i class="fa fa-star"></i>
																<i class="fa fa-star"></i>
																<i class="fa fa-star-o empty"></i>
															</div>
															';
															}
															if($rows["rate"]==5)
															{
															echo'
																<span><b>'.$result2.'<b> Of 5 Stars</span>
															<div class="product-rating">
																<i class="fa fa-star"></i>
																<i class="fa fa-star"></i>
																<i class="fa fa-star"></i>
																<i class="fa fa-star"></i>
																<i class="fa fa-star"></i>
															</div>
															';
															}														
															echo'

															
														</div>
													
													</li>
													';
													
												 }
							
										
										
										
										
										echo"
									
									</div>
									<div class='add-to-cart'>
									";
										if($row["item_for"]==1)
						             {}else{echo"
										<button pid='$pro_id' id='product' class='add-to-cart-btn block2-btn-towishlist' href='#'><i class='fa fa-shopping-cart'></i> add to cart</button>
										";}
										echo"
									</div>
								</div>
                                </div>
							
                        
			";
		}
        ;
      
}
    
	}
    
if(isset($_POST["get_seleted_Category"]) ||  isset($_POST["search"])){
	if(isset($_POST["get_seleted_Category"])){
		$id = $_POST["cat_id"];
		$sql = "SELECT * FROM products,categories,location WHERE product_cat = '$id' AND product_location=location_id AND status='0'AND product_cat=cat_id";
	}else {
		$keyword = $_POST["keyword"];
		$sql = "SELECT * FROM products,categories,location WHERE product_cat=cat_id AND product_location=location_id AND status='0' AND product_keywords LIKE '%$keyword%'";
/* 		$sql = "SELECT * FROM products,categories WHERE product_cat=cat_id AND product_keywords LIKE '%$keyword%'";
 */	}
	
	$run_query = mysqli_query($con,$sql);
	while($row=mysqli_fetch_array($run_query)){
			$pro_id    = $row['product_id'];
			$pro_cat   = $row['product_cat'];
			$pro_brand = $row['product_location'];
			$pro_title = $row['product_title'];
			$pro_price = $row['product_price'];
			$pro_image = $row['product_image'];
            $cat_name = $row["cat_title"];
			$pro_condition = $row['condition'];
			$location = $row['location_title'];
			$ppd = $row['PricePerDay'];
			echo "
					
                        
                        <div class='col-md-4 col-xs-6'>
								<a href='product.php?pid=$pro_id'><div class='product'>
									<div class='product-img'>
										<img  src='product_images/$pro_image' style='max-height: 170px;' alt=''>
										<div class='product-label'>
											<span class='sale'>$location</span>
											<span class='new'>$pro_condition</span>
										</div>
									</div></a>
									<div class='product-body'>
										<p class='product-category'><font color='blue' ><b>$cat_name</font></b></p>
										<h3 class='product-name header-cart-item-name'><a href='product.php?pid=$pro_id'>$pro_title</a></h3>
																				";
										if($row["product_price"]<1){
											echo"
										<h4 class='product-price header-cart-item-info'>Br:$ppd Per Day</h4>
											";
										}else{
										
										echo"
										<h4 class='product-price header-cart-item-info'>Br:$pro_price</h4>
										";}
										
			$sql1 = "SELECT COUNT(*) AS count_items FROM rating WHERE product_id=$pro_id";
            $query1 = mysqli_query($con,$sql1);
            $rowas = mysqli_fetch_array($query1);
            $count=$rowas["count_items"];
			$sql2 = "SELECT SUM(rate) AS amount FROM rating WHERE product_id=$pro_id";
			$query2 = mysqli_query($con,$sql2);
            $rowaaa = mysqli_fetch_array($query2);
			$product=$rowaaa["amount"];
			if($count==0){
				$result2=0;
			}
			else{
			$result=($product/$count);
			$result2=number_format($result,1);
			}
			


								$sqln = " SELECT * FROM rating WHERE product_id = $pro_id LIMIT 1"; 
									$run_quer = mysqli_query($con,$sqln);
												 while($rows = mysqli_fetch_array($run_quer)){  
												echo'
												
												
													
														<div class="review-heading">
															
															';
															if($rows["rate"]==1)
															{
															echo'
															<font color="red"><b>'.$result2.'<b> Of 5 Stars</font>
															<div class="product-rating">
																<i class="fa fa-star"></i>
																<i class="fa fa-star-o empty"></i>
																<i class="fa fa-star-o empty"></i>
																<i class="fa fa-star-o empty"></i>
																<i class="fa fa-star-o empty"></i>
															</div>	
															';
															}
															if($rows["rate"]==2)
															{
															echo'
														<span><b>'.$result2.'<b> Of 5 Stars</span>
															<div class="product-rating">
																<i class="fa fa-star"></i>
																<i class="fa fa-star"></i>
																<i class="fa-star-o empty"></i>
																<i class="fa fa-star-o empty"></i>
																<i class="fa fa-star-o empty"></i>
															</div>	
															';
															}
															if($rows["rate"]==3)
															{
															echo'
															
															<span ><b>'.$result2.'<b> Of 5 Stars</span>
															
														  <div class="product-rating">
																<i class="fa fa-star"></i>
																<i class="fa fa-star"></i>
																<i class="fa fa-star"></i>
																<i class="fa fa-star-o empty"></i>
																<i class="fa fa-star-o empty"></i>
															</div>	
															';
															}
															if($rows["rate"]==4)
															{
															echo'
														<span><b>'.$result2.'<b> Of 5 Stars</span>
															<div class="product-rating">
																<i class="fa fa-star"></i>
																<i class="fa fa-star"></i>
																<i class="fa fa-star"></i>
																<i class="fa fa-star"></i>
																<i class="fa fa-star-o empty"></i>
															</div>
															';
															}
															if($rows["rate"]==5)
															{
															echo'
																<span><b>'.$result2.'<b> Of 5 Stars</span>
															<div class="product-rating">
																<i class="fa fa-star"></i>
																<i class="fa fa-star"></i>
																<i class="fa fa-star"></i>
																<i class="fa fa-star"></i>
																<i class="fa fa-star"></i>
															</div>
															';
															}														
															echo'

															
														</div>
													
													</li>
													';
													
												 }
							
										
										
										
										echo"

									</div>
									<div class='add-to-cart'>
																		";
										if($row["item_for"]==1)
						             {}else{echo"
										<button pid='$pro_id' id='product' href='#' tabindex='0' class='add-to-cart-btn'><i class='fa fa-shopping-cart'></i> add to cart</button>
										 ";}
										echo"
									</div>
								</div>
							</div>
			";
		}
	}