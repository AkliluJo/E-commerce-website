	$sql0="SELECT quantity from products WHERE product_id='$_SESSION[product_id]'";
    $runquery=mysqli_query($con,$sql0);
	$rowas = mysqli_fetch_array($runquery);
	$quantity =$rowas["quantity"];
    if ($quantity > 1 AND ) {
    $new_quantity =$quantity-$quantity_before
        $order_id=1;
    }