if($row["product_cat"]==2)
{
	echo'
<table>
                  <thead>
                    <tr>
                      <th colspan="2">Accessories</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
    <td>Elecrtonic Fence</td>
			';		  
 if($row["electricfence"]==1)
{
echo '
   <td><i class="fa fa-check" aria-hidden="true"></i></td>
   ';
 } else {  
 echo '
   <td><i class="fa fa-close" aria-hidden="true"></i></td>
   ';
    }  
	echo '
	</tr>

<tr>
<td>Kichhen</td>
';

if($row["kichhen"]==1)
{
echo '
<td><i class="fa fa-check" aria-hidden="true"></i></td>
';
 } else {
	 echo '
<td><i class="fa fa-close" aria-hidden="true"></i></td>
';
 }
echo ' 
 </tr>
 <tr>
<td>Parkingbay</td>
';

if($row["parkingbay"]==1)
{
echo '
<td><i class="fa fa-check" aria-hidden="true"></i></td>
';
 } else {
	 echo '
<td><i class="fa fa-close" aria-hidden="true"></i></td>
';
 }
echo ' 
 </tr>
 <tr>
<td>Swimmingpool</td>
';

if($row["swimmingpool"]==1)
{
echo '
<td><i class="fa fa-check" aria-hidden="true"></i></td>
';
 } else {
	 echo '
<td><i class="fa fa-close" aria-hidden="true"></i></td>
';
 }
echo ' 
 </tr>
  <tr>
<td>Water Included</td>
';

if($row["waterincluded"]==1)
{
echo '
<td><i class="fa fa-check" aria-hidden="true"></i></td>
';
 } else {
	 echo '
<td><i class="fa fa-close" aria-hidden="true"></i></td>
';
}}
echo ' 
 </tr>
 </tbody>
 </table>
 
 
 
 					<!-- section title -->
					<div class="col-md-12">
						<div class="section-title">
							<h3 class="title">New Products</h3>
							<div class="section-nav">
								<!--<ul class="section-tab-nav tab-nav">
									<li class="active"><a data-toggle="tab" href="#tab1">Laptops</a></li>
									<li><a data-toggle="tab" href="#tab1">Smartphones</a></li>
									<li><a data-toggle="tab" href="#tab1">Cameras</a></li>
									<li><a data-toggle="tab" href="#tab1">Accessories</a></li>
								</ul>-->
							</div>
						</div>
					</div>
					<!-- /section title -->