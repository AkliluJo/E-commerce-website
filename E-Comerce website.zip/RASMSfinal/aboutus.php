
<!DOCTYPE html>
<html lang="en">

<head>
		<style>
		
		
#developers{
	height: 150px;
    width: 160px;
}
body {
    font-family:'ProximaNova-Light',Helvetica,Arial,sans-serif !important;
}



		</style>
</head>




   <div class="main main-raised">

    
		<!-- SECTION -->
		<div class="section">
			<!-- container -->
			<div class="container">
				<!-- row -->
				<div class="row">



					<!-- Products tab & slick -->
					<div class="col-md-12 mainn mainn-raised">
						<div class="row">
							<div class="products-tabs">
								<!-- tab -->


        <div class="container-fluid">
            <div class="row-fluid">
                <div class="span12" id="content">
                     <div class="row-fluid">
                        <!-- block -->
                        <div class="block">
			<div class="navbar navbar-inner block-header">
			<div id="" class="muted pull-right"><a id="return" data-placement="left" title="Click to Return" href="index.php"><i class="icon-arrow-left"></i> Back</a></div>
			<script type="text/javascript">
			$(document).ready(function(){
			$( '#return').tooltip('show');
			$('#return').tooltip('hide');
			});
			</script> 
			</div>
             <div class="block-content collapse in">
			<h3></i><i class="icon-group"></i>&nbsp;
			<center>Team Web Developers</h3></center>
			<hr>
           <div class="span3">
			<center>
			<img id="developers" src="developer/developers/ake.jpg" class="img-circle">
			<hr>
			<p>Name:Aklilu Jomole</p>
				<p>Address: SNNPR,WOLAITA</p>
				<p>Email: aklilujom2@gmail.com</p>
				<p>Position: Head Programmer</p>
			</center>
			</div>
								
                                <div class="span3">
										<center>
								<img id="developers" src="developer/developers/" class="img-circle">
								        <hr>
										<p>Name: Gizachew Wondiye</p>
										<p>Address: East Gojjam, Dangila</p>
										<p>Email: gizachew55@gmail.com</p>
										<p>Position: Document Specialist </p>
								        </center>
								</div>
								
                                <div class="span3">
										<center>
								        <img id="developers" src="developer/developers/buza.jpg" class="img-circle">
								        <hr>
										<p>Name: Bizuayehu Dawit</p>
										<p>Address: SNNPR, Wolaita</p>
										<p>Email: buze9@gmail.com</p>
										<p>Position: Web Programmer </p>
								        </center>
								</div>
								
                                <div class="span3">
										<center>
								        <img id="developers" src="developer/developers/tedi.jpg" class="img-circle">
								        <hr>
										<p>Name: Tediros Taye</p>
										<p>Address: Oromia, sululta</p>
										<p>Email: tedi@gmail.com</p>
										<p>Position: System Analysis </p>
								        </center>
								</div>
								 <div class="span3">
										<center>
								        <img id="developers" src="developer/developers/" class="img-circle">
								        <hr>
										<p>Name: H/mikael Aklilu</p>
										<p>Address: South Wollo, Haik</p>
										<p>Email:hayle@gmail.com</p>
										<p>Position: System Design </p>
								        </center>
								</div>
								
                            </div>
                        </div>
                        <!-- /block -->
                    </div>
                </div>
            </div>
		
        </div>



								<!-- /tab -->
							</div>
						</div>
					</div>
					<!-- /Products tab & slick -->
				</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>
		<!-- /SECTION -->

		<!-- SECTION -->

		<!-- /SECTION -->
</div>

</html>