<?php

  include 'db.php';
if(isset($_SESSION["uid"])){
		$sql = "SELECT * FROM user_info WHERE email='$_SESSION[o_email]'";
			$query = mysqli_query($con,$sql);
			$row=mysqli_fetch_array($query);

if (isset($_POST["send_button"])) {
    $s_name = $_SESSION["name"];
	$s_email = $_SESSION["email"];
	
	$r_name = $row['first_name'];
	$message = $_POST['message'];

	
            $sqlq = "INSERT INTO `message` 
            ( `reciever_email`, `content`, `sender_email`, `reciever_name`, `sender_name`)
            VALUES ('$_SESSION[o_email]', '$message', '$s_email', '$r_name', '$s_name')";
			
			
           $sql = "INSERT INTO `message_sent` 
            ( `reciever_email`, `content`, `sender_email`, `reciever_name`, `sender_name`)
            VALUES ('$_SESSION[o_email]', '$message', '$s_email', '$r_name', '$s_name')";       
	       $query = mysqli_query($con,$sql);
			
              



			if (mysqli_query($con,$sqlq)) {
				?>


<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>RASMS|message process</title>

<style type="text/css">
		.content{
			display: none;
	
		}
			
.main-raised {
    margin: 0px 0px 0px;
    border-radius: 2px;
    box-shadow: 0 16px 24px 2px rgba(0, 0, 0, 0.14), 0 6px 30px 5px rgba(0, 0, 0, 0.12), 0 8px 10px -5px rgba(0, 0, 0, 0.2);

}
.main {

    background: #fff;
    position: relative;
    z-index: 3;

}
</style>
</head>
               <div class='alert alert-success'>
                    <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
                    <b>Massage Sended succusfully</b>
                </div>



				<?php
		}
   else{

        echo(mysqli_error($con));
        
    }
}
}   

else{
    echo"<script>window.location.href='index.php'</script>";
}
	
?>