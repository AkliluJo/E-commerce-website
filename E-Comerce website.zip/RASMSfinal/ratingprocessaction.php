<?php

  include 'db.php';

		
if (isset($_POST["rating_button"])) {
	$product_id = $_SESSION['product_id']; 
	$rname = $_POST["rname"];
	$email = $_POST["email"];
	$rmassage = $_POST['rmassage'];
    $rating = $_POST['rating'];
	
	$name = "/^[a-zA-Z ]+$/";
	$emailValidation = "/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9]+(\.[a-z]{2,4})$/";
	$number = "/^[0-9]+$/";

if(empty($rname) || empty($email) || empty($rmassage) || empty($rating)){
		
		echo "
			<div class='alert alert-warning'>
				<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a><b>PLease Fill the fields..!</b>
			</div>
		";
		exit();
	} else {
		if(!preg_match($name,$rname)){
		echo "
			<div class='alert alert-warning'>
				<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
				<b>this $rname is not valid..!</b>
			</div>
		";
		exit();
	}
        $sql = "SELECT rating_id FROM rating WHERE email_id = '$email' LIMIT 1" ;
        $check_query = mysqli_query($con,$sql);
        $count_email = mysqli_num_rows($check_query);
        if($count_email > 0){
            echo "
                <div class='alert alert-danger'>
                    <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
                    <b>Email Address is already available</b>
                </div>
            ";
            exit();
        }
	if(!preg_match($emailValidation,$email)){
		echo "
			<div class='alert alert-warning'>
				<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
				<b>this $email is not valid..!</b>
			</div>
		";
		exit();
	}
else{
            
            $sql = "INSERT INTO `rating` 
            ( `product_id`, `name`, `email_id`, `rate`, `review`)
            VALUES ('$product_id', '$rname', '$email', '$rating', '$rmassage')";
            

                
                
            }
		
	
	}
	
}

			if (mysqli_query($con,$sql)) {
				?>


<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>RASMS|Payment process</title>

<style type="text/css">
		.content{
			display: none;
	
		}
			
.main-raised {
    margin: 0px 0px 0px;
    border-radius: 2px;
    box-shadow: 0 16px 24px 2px rgba(0, 0, 0, 0.14), 0 6px 30px 5px rgba(0, 0, 0, 0.12), 0 8px 10px -5px rgba(0, 0, 0, 0.2);

}
.main {

    background: #fff;
    position: relative;
    z-index: 3;

}
</style>
</head>
               <div class='alert alert-success'>
                    <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
                    <b>Thanks for rating</b>
                </div>



				<?php
		}
		  

    

else{
    echo"<script>window.location.href='index.php'</script>";
}
	
?>