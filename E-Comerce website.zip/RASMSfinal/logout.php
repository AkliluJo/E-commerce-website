<?php
session_start();
unset($_SESSION["uid"]);
unset($_SESSION["name"]);
unset($_SESSION["email"]);
$BackToMyPage = $_SERVER['HTTP_REFERER'];
if(isset($BackToMyPage)) {
    header('Location: '.$BackToMyPage);
		 $insert = "INSERT INTO `user_logs` 
		( `date`,`user_id`, `first_name`, `email`, `action`) 
		VALUES (NOW(),".$row["user_id"].", '$_SESSION[name]', '$_SESSION[email]','logout')";
		  $run_query = mysqli_query($con,$insert);
} else {
 
    header('Location: index.php'); // default page
}

?>
